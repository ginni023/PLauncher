"""python -m crawling — 콘솔 크롤러(crawling.main)"""

from .main import main

if __name__ == "__main__":
    try:
        main()
    except EOFError:
        raise SystemExit("입력이 끝났습니다")
