"""UI 크롤러 — 로그인이 필요한 업무 웹사이트를 Playwright 로 돌아다니며 화면별 구조 스냅샷을 모은다.

Java 판(com.pefer.crawler, github.com/pefer1231/crowling)의 로직을 그대로 옮긴 파이썬 판이다.
결과 파일(index.json · states · smoke-input.json · site-map.json · inputs.json …)의 모양도 같다.

::

    from crawling import CrawlerConfig, CrawlerEngine

    config = CrawlerConfig("http://localhost:8080/", True)
    engine = CrawlerEngine(config)
    result = engine.crawl()
"""

from .config import CrawlerConfig
from .engine import CrawlResult, CrawlerEngine, ErrorCD, LoginResult, Status, to_folder_name
from .listener import CrawlListener
from .log import CrawlLog
from .repository import FileStateRepository, StateRepository, Summary
from .state_key import StateKey

__version__ = "0.1.0"

__all__ = [
    "CrawlerConfig",
    "CrawlerEngine",
    "CrawlResult",
    "ErrorCD",
    "LoginResult",
    "Status",
    "CrawlListener",
    "CrawlLog",
    "StateRepository",
    "FileStateRepository",
    "Summary",
    "StateKey",
    "to_folder_name",
]
