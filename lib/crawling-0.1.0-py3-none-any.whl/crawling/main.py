"""콘솔 실행 — CrawlerEngine 을 쓰는 예이기도 하다(Java 판 CrawlerMain). 다른 프로그램은 이것 대신 엔진을 직접 부른다.

1. 콘솔로 대상 사이트 URL 과 로그인 필요 여부를 받는다.
2. 로그인이 필요한데 저장된 쿠키가 없으면 브라우저를 띄워 사용자가 로그인하게 하고,
   로그인 정보(auth/{host}.json)를 저장한 뒤 **그대로 이어서** 크롤링한다. 쿠키가 남아 있으면 다음 실행 때는 로그인을 건너뛴다.
3. 크롤링 중 로그인 화면이 보이면(세션 만료) 다시 로그인하게 하고 이어서 크롤링한다(처리한 메뉴는 건너뛴다).

::

    python -m crawling                     (crawler.properties 가 있으면 읽는다)
    python -m crawling my.properties
"""

from __future__ import annotations

import re
import sys
import threading

from ._jutil import jtrim, parse_uri
from .config import CrawlerConfig
from .engine import CrawlerEngine, LoginResult, Status


def main(args=None) -> None:
    args = sys.argv[1:] if args is None else args
    engine = CrawlerEngine(CrawlerConfig.load(args[0] if args else None))

    strUrl = _ask_url()
    bLoginRequired = _ask_yes_no("로그인이 필요한 사이트입니까? (y/n): ")

    if bLoginRequired and not engine.has_login(strUrl) and not _login(engine, strUrl):
        return

    result = engine.crawl(strUrl, bLoginRequired)

    # 세션이 끊기면 다시 로그인하고 이어서 — 처리한 메뉴 · 상태는 건너뛴다
    while Status.SESSION_EXPIRED == result.status and _login(engine, strUrl):
        result = engine.crawl(strUrl, bLoginRequired)

    print(result.report)

    if Status.FAILED == result.status:
        print("실패 — " + result.message)


def _login(engine: CrawlerEngine, url: str) -> bool:
    """쿠키가 없을 때 — 브라우저를 띄워 사용자가 로그인하게 하고 로그인 정보를 저장한다. 저장했으면 True — 이어서 크롤링한다"""
    print("로그인이 필요합니다. 브라우저에서 로그인하세요.")
    print("로그인을 마친 뒤 이 창에서 Enter 를 누르세요 (브라우저는 닫지 마세요): ", end="", flush=True)

    # 엔진은 이 스레드를 붙잡으므로 Enter 는 다른 스레드에서 기다린다
    done = threading.Event()

    def wait_enter() -> None:
        try:
            sys.stdin.readline()
        finally:
            done.set()

    threading.Thread(target=wait_enter, name="login-enter", daemon=True).start()

    result = engine.login(url, done)

    if LoginResult.SAVED != result:
        print("로그인 정보를 저장하지 못해 끝냅니다 (" + result.value + ")")
        return False

    return True


def _ask_url() -> str:
    while True:
        strUrl = input("대상 사이트 URL (로그인 후 첫 화면): ")
        strUrl = jtrim(strUrl)

        if "" == strUrl:
            continue

        if not re.fullmatch(r"(?i)^https?://.*", strUrl, re.DOTALL):
            strUrl = "http://" + strUrl

        try:
            if parse_uri(strUrl).host is not None:
                return strUrl
        except ValueError:
            # 아래에서 다시 묻는다
            pass

        print("URL 형식이 아닙니다. 다시 입력하세요.")


def _ask_yes_no(prompt: str) -> bool:
    while True:
        strAnswer = jtrim(input(prompt)).lower()

        if strAnswer in ("y", "yes", "예", "ㅛ"):
            return True

        if strAnswer in ("n", "no", "아니오", "ㅜ"):
            return False


if __name__ == "__main__":
    try:
        main()
    except EOFError:
        raise SystemExit("입력이 끝났습니다")
