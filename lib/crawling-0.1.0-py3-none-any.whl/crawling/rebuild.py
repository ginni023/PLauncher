"""다시 크롤링하지 않고, 결과 폴더의 원본 기록(states)으로 smoke-input.json · smoke-prompt.md · site-map.json · inputs.json 을
다시 만든다 — Java 판 Rebuild. 프롬프트 틀이나 요약 · 지도 만드는 방식을 고친 뒤에 쓴다.

명령줄::

    python -m crawling.rebuild crawl-output/localhost_8080 [crawler.properties]
"""

from __future__ import annotations

import sys
from pathlib import Path

from . import input_list, site_map, smoke_input, smoke_prompt
from ._jutil import as_int, as_text, jget, write_text
from .config import CrawlerConfig
from .repository import FileStateRepository, StateRepository


def rebuild(output_dir, config: CrawlerConfig) -> None:
    oDir = Path(output_dir)
    repository = FileStateRepository(oDir)
    strSite = _get_site(repository)

    oInput = smoke_input.build(strSite, repository, {})
    smoke_input.write(oDir / "smoke-input.json", oInput)

    write_text(oDir / "smoke-prompt.md", smoke_prompt.build(oInput, config.get_danger_words(), config.get_smoke_gap_ms()))

    oMap = site_map.build(strSite, repository, {})
    site_map.write(oDir / "site-map.json", oMap)

    oInputs = oDir / "inputs.json"
    oList = input_list.build(oMap, repository, {}, input_list.read(oInputs))
    input_list.write(oInputs, oList)

    print("%s — smoke-input %d개 화면, site-map %d개 화면, inputs %d개" % (oDir, as_int(jget(oInput, "screenCount")),
                                                                    as_int(jget(oMap, "screenCount")),
                                                                    as_int(jget(oList, "inputCount"))))
    print(site_map.get_weak_report(oMap), end="")


def _get_site(repository: StateRepository) -> str:
    """시작 화면의 재현 경로 첫 goto 주소 — 없으면 첫 화면의 정규화 URL"""
    lstSummaries = repository.get_summaries()

    for s in lstSummaries:
        oState = repository.load(s.state_id)
        strUrl = "" if oState is None else as_text(jget(jget(jget(oState, "reach"), 0), "url"), "")

        if "" != strUrl:
            return strUrl

    return "" if not lstSummaries else lstSummaries[0].normalized_url


def main(args=None) -> None:
    args = sys.argv[1:] if args is None else args

    if 1 > len(args):
        print("쓰는 법: python -m crawling.rebuild 결과폴더 [crawler.properties]")
        return

    rebuild(args[0], CrawlerConfig.load(args[1] if 1 < len(args) else None))


if __name__ == "__main__":
    main()
