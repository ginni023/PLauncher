"""smoke-prompt.md — 고정 프롬프트(resources/prompt/smoke-ts.md)에 smoke-input.json 을 붙인 글 — Java 판 SmokePrompt.

서버는 이 글을 그대로 LLM 에 보내면 Playwright Test(TypeScript) 파일 하나를 받는다.
"""

from __future__ import annotations

from importlib import resources
from typing import List

from ._jutil import as_text, dumps_pretty, jget


def get_template(name: str) -> str:
    """패키지의 resources/prompt 틀"""
    oFile = resources.files("crawling").joinpath("resources", "prompt", name)

    if not oFile.is_file():
        raise RuntimeError("프롬프트 틀이 없습니다: /prompt/" + name)

    # 줄바꿈을 바꾸지 않고 그대로 읽는다(Java 의 readAllBytes 와 같다)
    return oFile.read_bytes().decode("utf-8")


_TEMPLATE = get_template("smoke-ts.md")


def build(input_node: dict, danger_words: List[str], gap_ms: int) -> str:
    strPrompt = _TEMPLATE.replace("{{SITE}}", as_text(jget(input_node, "site"), ""))
    strPrompt = strPrompt.replace("{{GAP_MS}}", str(gap_ms))
    strPrompt = strPrompt.replace("{{DANGER_WORDS}}", " · ".join(danger_words))

    return strPrompt.replace("{{INPUT}}", dumps_pretty(input_node))
