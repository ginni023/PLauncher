"""종료 리포트 — 콘솔 + report.txt(명세 §11) — Java 판 CrawlReport."""

from __future__ import annotations

import os
from typing import Dict, List

from ._jutil import java_str
from .repository import StateRepository


class CrawlReport:
    def __init__(self):
        self._diagnosis = "(진단 못 함)"
        self._menus_found = 0
        self._menus_visited = 0
        self._links_visited = 0
        self._buttons_clicked = 0
        self._new_states = 0
        self._duplicates = 0
        self._failures: List[str] = []
        self._structures: Dict[str, int] = {}

    def set_diagnosis(self, diagnosis: str) -> None:
        self._diagnosis = diagnosis

    def menu_found(self) -> None:
        self._menus_found += 1

    def menu_visited(self, structure: str) -> None:
        self._menus_visited += 1
        self._structures[structure] = self._structures.get(structure, 0) + 1

    def link_visited(self) -> None:
        self._links_visited += 1

    def button_clicked(self) -> None:
        self._buttons_clicked += 1

    def new_state(self) -> None:
        self._new_states += 1

    def duplicate(self) -> None:
        self._duplicates += 1

    def failure(self, what: str, reason: str) -> None:
        self._failures.append(what + " — " + reason)

    def render(self, repository: StateRepository, blocked_count: Dict[str, int]) -> str:
        lines = []
        lines.append("===== 크롤링 리포트 =====\n")
        lines.append("사이트 구조(첫 메뉴 진단): " + self._diagnosis + "\n")
        # TreeMap — 키 이름 차례
        lines.append("메뉴 클릭 결과 유형별: " + java_str(dict(sorted(self._structures.items()))) + "\n")
        lines.append("발견한 메뉴: %d / 방문 성공: %d / 실패: %d\n" % (self._menus_found, self._menus_visited, len(self._failures)))

        for strFailure in self._failures:
            lines.append("  실패 " + strFailure + "\n")

        lines.append("따라간 링크: %d\n" % self._links_visited)

        if 0 < self._buttons_clicked:
            lines.append("누른 화면 안 버튼 · 탭: %d\n" % self._buttons_clicked)

        lines.append("이번에 새로 모은 상태: %d / 중복으로 건너뜀: %d / 저장소 전체 상태: %d\n"
                     % (self._new_states, self._duplicates, repository.get_size()))
        lines.append("막은 요청: " + ("없음" if not blocked_count else java_str(dict(sorted(blocked_count.items())))) + "\n")
        lines.append("상태별 요소 수:\n")

        for s in repository.get_summaries():
            # String.format 의 %n — 시스템 줄바꿈(Windows 는 \r\n)
            lines.append("  %s %4d %-6s %s %s%s%s" % (s.state_id, s.element_count, s.structure, s.normalized_url,
                                                     java_str(s.menu_paths),
                                                     "  ⚠ 요소 없음" if 0 == s.element_count else "",
                                                     "  ⚠ 서버 오류 화면" if s.server_error else "") + os.linesep)

        return "".join(lines)
