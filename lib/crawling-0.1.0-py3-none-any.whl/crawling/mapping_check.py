"""업무 테스트 ② 의 결과(연결안, mapping.json)를 사이트 지도와 맞춰 본다 — Java 판 MappingCheck.

LLM 이 지어낸 화면 · 버튼 · 입력칸을 ③ 사람 확인 전에 걸러낸다.

- steps[].screen · fields[].screen 이 지도에 있는 화면 id 인가
- steps[].button 이 그 화면의 버튼인가
- fields[].field 가 그 화면의 입력칸(section › group › label)인가
- 업무의 steps 와 수가 같은가, 데이터 열이 모두 이어졌거나 질문으로 남았는가

resolve() — ③ 에서 확인된 연결안의 입력칸 · 버튼에 사이트 지도의 selector 를 붙인다. ④ 는 이 selector 를 그대로 쓴다.

명령줄::

    python -m crawling.mapping_check scenario.json site-map.json mapping.json [selector 붙인 연결안.json]
"""

from __future__ import annotations

import copy
import sys
from typing import Any, Dict, List, Optional, Set

from ._jutil import as_text, dumps_compact, has_non_null, items, jget, read_json, size, write_json


def check(scenario: Any, site_map: Any, mapping: Any) -> List[str]:
    """문제 목록 — 비면 통과"""
    problems: List[str] = []
    screens = _get_screens(site_map)

    nSteps = size(jget(scenario, "steps"))
    nMappingSteps = size(jget(mapping, "steps"))

    if nSteps != nMappingSteps:
        problems.append("단계 수가 다르다 — 업무 " + str(nSteps) + "개, 연결안 " + str(nMappingSteps) + "개")

    for step in items(jget(mapping, "steps")):
        strWhere = "steps[" + as_text(jget(step, "step")) + "]"
        screen = _get_screen(step, screens, strWhere, problems)
        strButton = as_text(jget(step, "button"))

        if screen is not None and has_non_null(step, "button") and not _contains(jget(screen, "buttons"), strButton):
            problems.append(strWhere + ": 화면 " + as_text(jget(screen, "id")) + " 에 버튼 '" + strButton + "' 이 없다")

    mapped: Set[str] = set()

    for f in items(jget(mapping, "fields")):
        strData = as_text(jget(f, "data"))
        strWhere = "fields[" + strData + "]"
        screen = _get_screen(f, screens, strWhere, problems)

        if screen is not None and has_non_null(f, "field"):
            strField = as_text(jget(f, "field"))

            if strField in get_field_paths(screen):
                mapped.add(strData)
            else:
                problems.append(strWhere + ": 화면 " + as_text(jget(screen, "id")) + " 에 입력칸 '" + strField + "' 이 없다")

    # 데이터 열은 입력칸에 이어졌거나, 질문으로 남았어야 한다
    strQuestions = dumps_compact(jget(mapping, "questions")) + dumps_compact(jget(mapping, "unknown"))

    for column in items(jget(jget(scenario, "data"), "columns")):
        strKey = as_text(jget(column, "key"))

        if strKey not in mapped and strKey not in strQuestions:
            problems.append("데이터 열 '" + strKey + "' 이 입력칸에도 이어지지 않았고 질문에도 없다")

    return problems


def resolve(site_map: Any, mapping: Any) -> Any:
    """연결안에 selector 를 붙인 사본. 입력칸은 지도의 같은 경로(section › group › label) 칸의 selector,
    버튼은 group(그 버튼이 딸린 칸 이름)의 칸 버튼 가운데 같은 글자의 selector — group 이 없으면 그 화면에 그 글자의 칸 버튼이 하나뿐일 때만.
    못 찾으면 selector 를 None 으로 둔다 — ④ 가 elements 에서 찾는다."""
    screens = _get_screens(site_map)
    out = copy.deepcopy(mapping)

    for f in items(jget(out, "fields")):
        screen = screens.get(as_text(jget(f, "screen")))
        strSelector = None

        if screen is not None and has_non_null(f, "field"):
            strField = as_text(jget(f, "field"))

            for field in items(jget(screen, "fields")):
                if strField == _get_path(field) and has_non_null(field, "selector"):
                    strSelector = as_text(field["selector"])
                    break

        f["selector"] = strSelector

    for step in items(jget(out, "steps")):
        if not has_non_null(step, "button"):
            continue

        screen = screens.get(as_text(jget(step, "screen")))
        found: List[str] = []

        if screen is not None:
            strGroup = as_text(jget(step, "group"), "")
            strButton = as_text(jget(step, "button"))

            for field in items(jget(screen, "fields")):
                if "" != strGroup:
                    if strGroup != as_text(jget(field, "label")) and not _get_path(field).endswith(strGroup):
                        continue

                for b in items(jget(field, "buttons")):
                    if strButton == as_text(jget(b, "text")) and has_non_null(b, "selector"):
                        found.append(as_text(b["selector"]))

        step["selector"] = found[0] if 1 == len(found) else None

    return out


def _get_screens(site_map: Any) -> Dict[str, Any]:
    return {as_text(jget(s, "id")): s for s in items(jget(site_map, "screens"))}


def _get_path(field: Any) -> str:
    parts = []

    for strKey in ("section", "group", "label"):
        if has_non_null(field, strKey):
            strValue = as_text(field[strKey])

            if "" != strValue:
                parts.append(strValue)

    return " › ".join(parts)


def _get_screen(item: Any, screens: Dict[str, Any], where: str, problems: List[str]) -> Optional[Any]:
    """화면 id 가 지도에 있으면 그 화면, null 이면(질문으로 남긴 것) None, 없는 id 면 문제로 적고 None"""
    if not has_non_null(item, "screen"):
        return None

    strScreenId = as_text(item["screen"])
    screen = screens.get(strScreenId)

    if screen is None:
        problems.append(where + ": 지도에 없는 화면 '" + strScreenId + "'")

    return screen


def get_field_paths(screen: Any) -> Set[str]:
    """화면의 입력칸을 section › group › label 로"""
    return {_get_path(f) for f in items(jget(screen, "fields"))}


def _contains(array: Any, value: str) -> bool:
    for n in items(array):
        if value == as_text(n):
            return True

    return False


def main(args=None) -> None:
    args = sys.argv[1:] if args is None else args

    if len(args) not in (3, 4):
        print("쓰는 법: python -m crawling.mapping_check scenario.json site-map.json mapping.json [selector 붙인 연결안.json]")
        return

    oScenario = read_json(args[0])
    oSiteMap = read_json(args[1])
    oMapping = read_json(args[2])
    problems = check(oScenario, oSiteMap, oMapping)

    print("통과 — 지도에 없는 것을 쓰지 않았다" if not problems else "문제 " + str(len(problems)) + "개")

    for p in problems:
        print("  - " + p)

    if 4 == len(args):
        resolved = resolve(read_json(args[1]), read_json(args[2]))
        write_json(args[3], resolved)

        for f in items(jget(resolved, "fields")):
            print("  칸   " + as_text(jget(f, "data")) + " → " + as_text(jget(f, "selector"), "(못 찾음)"))

        for s in items(jget(resolved, "steps")):
            if has_non_null(s, "button"):
                print("  버튼 " + as_text(jget(s, "button")) + " → " + as_text(jget(s, "selector"), "(못 찾음)"))


if __name__ == "__main__":
    main()
