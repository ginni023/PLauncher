"""사이트를 돌아다니며 상태를 모은다(명세 §5 · §6) — Java 판 SiteCrawler.

1. 시작 화면을 연다. 로그인이 필요한 사이트인데 비밀번호 입력칸이 보이면 세션 만료로 보고 멈춘다.
2. 메뉴 탐색 — 시작 화면의 클릭 후보(href 없는 JS 메뉴 포함)를 하나씩, 매번 시작 화면으로 돌아가
   글자로 다시 찾아 누른다. 누른 뒤 무엇이 바뀌었는지(IFRAME · PAGE · AJAX · POPUP)로 본문을 정한다.
   펼쳐지는 하위 메뉴는 다시 모아 "상위 > 하위" 경로로 이어서 누른다. 첫 메뉴는 진단 로그를 자세히 남긴다.
3. 링크 탐색 — 모은 화면들의 같은 호스트 링크를 maxDepth 까지 따라간다(정규화 URL 기준 한 번씩).
4. (clickButtons=true) 화면 안 버튼 탐색.
"""

from __future__ import annotations

import copy
import re
import time
from collections import deque
from dataclasses import dataclass
from enum import Enum
from typing import Callable, Deque, Dict, List, Optional, Set

from playwright.sync_api import Error as PlaywrightError

from ._jutil import as_bool, as_int, as_text, has, has_non_null, items, jblank, jget, jtrim, now_offset
from .config import CrawlerConfig
from .listener import CrawlListener
from .log import CrawlLog
from .report import CrawlReport
from .repository import StateRepository
from .safety_guard import SafetyGuard, is_logout_text
from .state_collector import Candidate, StateCollector, error_message, get_first_line
from .state_key import StateKey, get_merge_hash, get_struct_hash, normalize_url


class Result(Enum):
    COMPLETED = "COMPLETED"
    SESSION_EXPIRED = "SESSION_EXPIRED"
    MAX_STATES = "MAX_STATES"
    CANCELLED = "CANCELLED"
    HALTED = "HALTED"


_START_PATH = "(시작 화면)"
_FILE_LINK = re.compile(r"(?i).*\.(xls|xlsx|csv|pdf|zip|doc|docx|hwp|hwpx|ppt|pptx|txt|jpg|png|gif)(\?.*)?$")
# 서버 오류(5xx)가 나면 그 메뉴 · 링크를 처음부터 한 번 더 해 본다
_MAX_TRIES = 2


class _Control(Exception):
    """크롤링 흐름을 끊는 신호 — 메뉴 · 링크 하나의 실패로 삼키지 않고 run() 까지 올린다"""


class _SessionExpired(_Control):
    pass


class _MaxStatesReached(_Control):
    pass


class _Cancelled(_Control):
    pass


class _CrawlHalted(_Control):
    """기다리는 시간을 늘려 retryWaitStepsMs 만큼 다시 해도 안 됐다 — 크롤링 전체를 멈춘다"""


class _NotSettled(Exception):
    """기다리는 시간 상한까지 화면이 가라앉지 않았다 — 오류로 보고 기다리는 시간을 늘려 다시 한다"""


class _LocateError(Exception):
    """메뉴 · 버튼을 다시 찾지 못했다(Java 판 IllegalStateException) — 다시 해 볼 오류다"""


# 다시 해 볼 오류 — 요소를 못 찾음 · 못 누름 · 열기 시간 초과 · 화면이 안 가라앉음
_RETRYABLE = (PlaywrightError, _NotSettled, _LocateError)


@dataclass(frozen=True)
class _MenuItem:
    """누를 메뉴 — 시작 화면에서 차례로 거칠 단계들. hovers 는 단계마다 마우스를 올리기만 하는가(True) 누르는가(False).
    마지막 단계는 늘 누른다. hover 메뉴의 하위 항목은 [상위(올리기), 하위(누르기)] 다."""

    steps: tuple
    hovers: tuple

    @staticmethod
    def of(first: Candidate) -> "_MenuItem":
        return _MenuItem((first,), (False,))

    def is_hover(self, index: int) -> bool:
        return self.hovers[index]

    def get_path(self) -> str:
        return " > ".join(s.text for s in self.steps)

    def get_last(self) -> Candidate:
        return self.steps[-1]

    def get_child(self, c: Candidate) -> "_MenuItem":
        """이 메뉴를 누른 뒤 펼쳐진 하위 메뉴"""
        return _MenuItem(self.steps + (c,), self.hovers + (False,))

    def get_hover_child(self, c: Candidate) -> "_MenuItem":
        """이 메뉴에 마우스를 올리면 보이는 하위 메뉴 — 이 메뉴 단계는 누르지 않고 올리기만 한다"""
        return _MenuItem(self.steps + (c,), self.hovers[:-1] + (True, False))


@dataclass(frozen=True)
class _PendingLink:
    """hidden — 자리는 있지만 안 보이는 링크. 눌러서는 못 가므로 재현 경로는 주소로 열기다"""

    url: str
    text: str
    frame_name: str
    table_index: Optional[int]
    target: Optional[str]
    hidden: bool
    from_state_id: str
    depth: int


@dataclass(eq=False)
class _ClickOutcome:
    """fields_changed — 본문 frame 의 입력칸 수가 클릭 전과 다른가(AJAX 일 때만 의미가 있다)"""

    structure: str
    target: object
    body: object
    fields_changed: bool = True


def _add(s: set, value) -> bool:
    """Set.add — 새로 넣었으면 True"""
    if value in s:
        return False

    s.add(value)
    return True


def _close_quietly(page) -> None:
    try:
        page.close()
    except PlaywrightError:
        # 이미 닫힘
        pass


def _get_known_key(c: Candidate) -> str:
    return c.frame_name + "\u0001" + c.text


def _get_description(structure: str) -> str:
    return {
        "IFRAME": "IFRAME 구조 (frame URL 만 바뀜)",
        "PAGE": "일반 페이지 이동 (page URL 바뀜)",
        "AJAX": "AJAX 구조 (URL 그대로, DOM 만 바뀜)",
        "POPUP": "POPUP 구조 (새 창)",
        "EXPAND": "하위 메뉴 펼침",
    }.get(structure, "변화 없음")


def _get_selector(c: Candidate) -> str:
    return ("" if "" == c.frame_name else "frame[name=" + c.frame_name + "] >> ") + 'text="' + c.text + '"'


def _locate(frame, c: Candidate):
    """글자로 다시 찾는다(이전 핸들은 DOM 이 바뀌어 쓸 수 없다). 버튼 후보는 수집 때 확인한 selector 로 찾는다"""
    if c.selector is not None:
        return frame.locator(c.selector).first

    oAll = frame.get_by_text(c.text, exact=True)
    nCount = oAll.count()

    for i in range(nCount):
        oNth = oAll.nth(i)

        if oNth.is_visible():
            return oNth

    raise _LocateError("메뉴를 다시 찾지 못했습니다: " + c.text)


def _put_data_row(step: dict, table_index: Optional[int]) -> None:
    """표 데이터 행 안이면 — 글자는 데이터 값이므로 "그 표(tableIndex)의 첫 데이터 행" 처럼 위치로 찾게 한다"""
    if table_index is not None and 0 <= table_index:
        step["dataRow"] = True
        step["tableIndex"] = table_index


def _put_role(step: dict, tag: str) -> None:
    if "A" == tag:
        step["role"] = "link"
    elif "BUTTON" == tag:
        step["role"] = "button"


def _is_orphan(request) -> bool:
    """기다리지 않는 요청 — 닫힌 페이지 · 떨어져 나간 frame 의 요청, frame 이 없는 요청(서비스 워커 등), 서버가 열어 두는 연결(EventSource)"""
    try:
        if "eventsource" == request.resource_type:
            return True

        oFrame = request.frame

        if oFrame.is_detached():
            return True

        return oFrame.page.is_closed()
    except Exception:
        return True


class SiteCrawler:
    Result = Result

    def __init__(self, config: CrawlerConfig, start_url: str, login_required: bool, context, guard: SafetyGuard,
                 repository: StateRepository, report: CrawlReport, listener: CrawlListener,
                 cancelled: Callable[[], bool]):
        self._listener = listener
        self._cancelled = cancelled
        self._config = config
        self._collector = StateCollector(config.get_aria_timeout_ms())
        self._start_url = start_url
        self._login_required = login_required
        self._context = context
        self._guard = guard
        self._repository = repository
        self._report = report
        # HALTED 로 멈춘 이유 — 무엇(메뉴 · 링크) — 오류 첫 줄
        self._halt_reason = ""

        self._links: Deque[_PendingLink] = deque()
        self._queued_links: Set[str] = set()
        self._page = None
        self._diagnosed = False
        # 아직 응답이 오지 않은 요청 — 화면 안정 판정에 쓴다
        self._inflight: set = set()
        # 상태마다 가장 짧은 재현 경로 — 링크 화면의 경로는 부모 경로 + 링크 클릭이다
        self._reach_by_id: Dict[str, list] = {}
        # 이번 실행에서 새로 저장한 상태 — smoke-input.json 을 만들 때 다시 읽지 않으려고
        self._saved_states: Dict[str, dict] = {}
        # 지금 하는 동작(이동 · 클릭) 동안 대상 호스트가 돌려준 5xx 응답 — "500 POST http://..."
        self._server_errors: List[str] = []
        # 화면 안 버튼 탐색(clickButtons) — 버튼을 몇 번 눌러 닿은 화면인가. 메뉴 · 링크 화면은 0
        self._button_depth: Dict[str, int] = {}
        # 지금 다시 하는 중이면 기다리는 시간마다 더하는 값(처음 0, 재시도 1000, 재재시도 5000 — retryWaitStepsMs)
        self._wait_bonus_ms = 0

    def run(self) -> Result:
        # 화면 안정 판정에는 대상 사이트의 요청만 센다 — 다른 호스트의 느린 요청 하나가 판정을 막지 않게
        # Playwright 는 내장 메서드(set.discard 등)를 이벤트 처리기로 받지 못한다 — 함수로 감싼다
        self._context.on("request", self._on_request)
        self._context.on("requestfinished", self._on_request_done)
        self._context.on("requestfailed", self._on_request_done)
        self._context.on("response", self._on_response)

        self._set_wait_bonus(0)
        self._page = self._context.new_page()
        self._queued_links.add(normalize_url(self._start_url))

        try:
            nTry = 1

            while True:
                self._server_errors.clear()
                self._attempt(_START_PATH, self._go_start)

                if not self._is_retry_needed(nTry, _START_PATH):
                    break

                nTry += 1

            startId = self._save_state(self._page, self._page.main_frame, "PAGE", _START_PATH, None, None, None, 0,
                                       self._get_start_reach())

            self._explore_menus(startId)
            self._explore_links()

            if self._config.is_click_buttons():
                self._explore_buttons()

            return Result.COMPLETED
        except _SessionExpired:
            return Result.SESSION_EXPIRED
        except _MaxStatesReached:
            CrawlLog.info("최대 상태 수(%d)에 닿아 멈춥니다", self._config.get_max_states())
            return Result.MAX_STATES
        except _Cancelled:
            CrawlLog.info("중단 요청을 받아 멈춥니다")
            return Result.CANCELLED
        except _CrawlHalted as e:
            self._halt_reason = str(e)
            CrawlLog.warn("기다리는 시간을 늘려 다시 해도 안 돼 크롤링을 멈춥니다 — %s", str(e))
            return Result.HALTED
        finally:
            self._repository.flush()

    def _on_request(self, request) -> None:
        if self._guard.is_allowed_host(request.url):
            self._inflight.add(request)

    def _on_request_done(self, request) -> None:
        self._inflight.discard(request)

    def _on_response(self, response) -> None:
        if 500 <= response.status and self._guard.is_allowed_host(response.url):
            self._server_errors.append(str(response.status) + " " + response.request.method + " " + response.url)

    # ---------------------------------------------------------------- 메뉴

    def _explore_menus(self, start_id: str) -> None:
        queue: Deque[_MenuItem] = deque()
        known: Set[str] = set()

        lstTops = self._collector.get_click_candidates(self._page, self._config.get_menu_selector())

        for c in lstTops:
            self._offer(queue, known, None, c)

        # 마우스를 올려야 펼쳐지는 메뉴(onmouseover · CSS :hover) — 누르기 전에 올려 보고 새로 보이는 항목을 하위 메뉴로 넣는다
        setHoverParents: Set[str] = set()

        if self._config.is_hover_menus():
            self._probe_hover_menus(queue, known, lstTops, setHoverParents)

        CrawlLog.info("메뉴 후보 %d개", len(queue))

        while queue:
            self._check_cancelled()

            item = queue.popleft()
            strPath = item.get_path()
            bDone = self._repository.is_menu_done(strPath)
            outcome: Optional[_ClickOutcome] = None

            try:
                nTry = 1

                while True:
                    def press(item=item) -> _ClickOutcome:
                        self._go_start()
                        lstParents = item.steps[:-1]

                        for nStep, step in enumerate(lstParents):
                            oStepLocator = _locate(self._find_frame(step), step)

                            if item.is_hover(nStep):
                                self._hover(oStepLocator)
                                continue

                            oStepLocator.click(timeout=self._get_click_wait())
                            self._settle(self._page)

                        self._guard.drain_dialogs()
                        self._server_errors.clear()
                        return self._click_and_detect(item.get_last(), not self._diagnosed)

                    outcome = self._attempt("메뉴 " + strPath, press)
                    self._diagnosed = True

                    if not self._is_retry_needed(nTry, "메뉴 " + strPath):
                        break

                    if outcome.target is not self._page:
                        _close_quietly(outcome.target)

                    nTry += 1

                # 하위 메뉴 후보 — 메뉴가 있던 frame 에서 다시 모은다.
                # 같은 frame 에 입력칸이 새로 생겼으면(AJAX 본문) 본문 버튼이 섞이므로 menuSelector 가 있을 때만 본다
                menuFrame = self._find_frame(item.get_last())
                bSameFrame = "AJAX" == outcome.structure and outcome.body is menuFrame
                children: List[Candidate] = []
                strMenuSelector = self._config.get_menu_selector()

                if ("NONE" == outcome.structure or "IFRAME" == outcome.structure
                        or ("AJAX" == outcome.structure
                            and ("" != strMenuSelector or (bSameFrame and not outcome.fields_changed)))):
                    children = self._collector.get_click_candidates(menuFrame, self._config.get_menu_selector())

                strStructure = outcome.structure

                # 메뉴 frame 에서 입력칸 변화 없이 새 메뉴만 보이면 하위 메뉴가 펼쳐진 것이다 — 화면으로 저장하지 않는다
                if bSameFrame and not outcome.fields_changed:
                    if any(_get_known_key(oChild) not in known for oChild in children):
                        strStructure = "EXPAND"

                # 마우스를 올리면 하위 메뉴가 보이는 상위 메뉴 — 눌러도 주소가 그대로면(href="#") 하위 메뉴가 펼쳐질 뿐이다(CSS :hover)
                strStartKey = normalize_url(self._start_url)
                strNowKey = normalize_url(self._page.url)

                if (_get_known_key(item.get_last()) in setHoverParents and "NONE" != strStructure
                        and self._page is outcome.target and strStartKey == strNowKey):
                    strStructure = "EXPAND"

                if bDone:
                    CrawlLog.info("이미 처리한 메뉴 — %s (하위 메뉴만 확인)", strPath)
                else:
                    if "NONE" == strStructure or "EXPAND" == strStructure:
                        CrawlLog.info("메뉴 %s — %s", strPath, _get_description(strStructure))
                    else:
                        self._save_state(outcome.target, outcome.body, strStructure, strPath, start_id,
                                         "click menu: " + strPath, _get_selector(item.get_last()), 1, self._get_menu_reach(item))

                    self._report.menu_visited(strStructure)
                    self._repository.mark_menu_done(strPath)

                for c in children:
                    self._offer(queue, known, item, c)
            except _Control:
                raise
            except Exception as e:
                strReason = get_first_line(error_message(e))
                self._report.failure(strPath, strReason)
                self._listener.on_failure(strPath, strReason)
                CrawlLog.warn("메뉴 %s 실패 — %s", strPath, strReason)
            finally:
                if outcome is not None and outcome.target is not self._page:
                    _close_quietly(outcome.target)

    def _offer(self, queue: Deque[_MenuItem], known: Set[str], parent: Optional[_MenuItem], c: Candidate) -> None:
        if not _add(known, _get_known_key(c)):
            return

        item = _MenuItem.of(c) if parent is None else parent.get_child(c)

        self._enqueue(queue, item, c)

    def _offer_hover_child(self, queue: Deque[_MenuItem], known: Set[str], parent: _MenuItem, c: Candidate) -> None:
        """마우스를 올리면 보이는 하위 메뉴 — [상위(올리기), 하위(누르기)]"""
        if not _add(known, _get_known_key(c)):
            return

        self._enqueue(queue, parent.get_hover_child(c), c)

    def _enqueue(self, queue: Deque[_MenuItem], item: _MenuItem, c: Candidate) -> None:
        if self._guard.is_dangerous_text(c.text) or (c.href is not None and self._guard.is_dangerous_url(c.href)):
            CrawlLog.info("위험 메뉴라 누르지 않습니다 — %s", item.get_path())
            return

        queue.append(item)
        self._report.menu_found()

    def _click_and_detect(self, candidate: Candidate, diagnose: bool) -> _ClickOutcome:
        """후보를 누르고 무엇이 바뀌었는지 본다(명세 §5 · §6.2)"""
        page = self._page
        target = _locate(self._find_frame(candidate), candidate)

        strPageUrlBefore = page.url
        urlsBefore = {}
        shapesBefore = {}

        for f in page.frames:
            urlsBefore[f] = f.url
            shapesBefore[f] = self._collector.get_shape(f)

        if diagnose:
            CrawlLog.info("[진단] 클릭 전 page.url = %s", strPageUrlBefore)
            self._log_frames("[진단] 클릭 전")
            CrawlLog.info("[진단] 메뉴 요소 (%s) outerHTML = %s", candidate.text, candidate.outer_html)

        navigated: list = []
        popups: list = []

        def onNavigated(frame) -> None:
            navigated.append(frame)

        def onPage(popup) -> None:
            popups.append(popup)

        page.on("framenavigated", onNavigated)
        self._context.on("page", onPage)

        try:
            target.click(timeout=self._get_click_wait())
            self._settle(page)

            for popup in list(popups):
                self._settle(popup)
        finally:
            page.remove_listener("framenavigated", onNavigated)
            self._context.remove_listener("page", onPage)

        outcome = self._judge(strPageUrlBefore, urlsBefore, shapesBefore, navigated, popups)

        if diagnose:
            CrawlLog.info("[진단] 클릭 후 page.url = %s", page.url)
            self._log_frames("[진단] 클릭 후")
            CrawlLog.info("[진단] 판정 = %s (본문 frame: %s %s)", _get_description(outcome.structure), outcome.body.name,
                          outcome.body.url)
            self._report.set_diagnosis(_get_description(outcome.structure))

        if self._login_required and self._collector.is_login_screen(outcome.target):
            self._check_session()

        return outcome

    def _judge(self, page_url_before: str, urls_before: dict, shapes_before: dict, navigated: list,
               popups: list) -> _ClickOutcome:
        page = self._page

        if popups:
            popup = popups[0]

            for extra in popups[1:]:
                _close_quietly(extra)

            return _ClickOutcome("POPUP", popup, popup.main_frame)

        main = page.main_frame
        strPageUrlAfter = page.url

        if strPageUrlAfter != page_url_before or main in navigated:
            return _ClickOutcome("PAGE", page, main)

        # URL 이 바뀌었거나 새로 붙었거나 다시 읽힌 하위 frame
        for f in page.frames:
            if f is main or f.is_detached() or "about:blank" == f.url:
                continue

            if f.url != urls_before.get(f) or f in navigated:
                return _ClickOutcome("IFRAME", page, f)

        # URL 변화 없이 구조만 바뀐 frame — 하위 frame 을 먼저 본다
        changedMain = None

        for f in page.frames:
            if f.is_detached():
                continue

            before = shapes_before.get(f)
            after = self._collector.get_shape(f)

            if before is not None and after.hash == before.hash:
                continue

            outcome = _ClickOutcome("AJAX", page, f, before is None or after.field_count != before.field_count)

            if f is not main:
                return outcome

            changedMain = outcome

        return _ClickOutcome("NONE", page, main) if changedMain is None else changedMain

    def _log_frames(self, prefix: str) -> None:
        for f in self._page.frames:
            CrawlLog.info("%s frame name=%s url=%s", prefix, f.name, f.url)

    def _find_frame(self, c: Candidate):
        """후보가 있던 frame 을 다시 찾는다 — 이름, 같은 URL, 없으면 main frame"""
        if "" != c.frame_name:
            for f in self._page.frames:
                if c.frame_name == f.name:
                    return f

        for f in self._page.frames:
            if f.parent_frame is not None and c.frame_url == f.url:
                return f

        return self._page.main_frame

    # ---------------------------------------------------------------- 링크

    def _explore_links(self) -> None:
        CrawlLog.info("링크 탐색 — 대기 %d개 (최대 깊이 %d)", len(self._links), self._config.get_max_depth())

        while self._links:
            self._check_cancelled()

            link = self._links.popleft()

            try:
                nTry = 1

                while True:
                    self._guard.drain_dialogs()
                    self._server_errors.clear()

                    def open_link(link=link) -> None:
                        self._open(self._page, link.url)
                        self._settle(self._page)

                    self._attempt("링크 " + link.url, open_link)

                    if not self._is_retry_needed(nTry, "링크 " + link.url):
                        break

                    nTry += 1

                if self._login_required and self._collector.is_login_screen(self._page):
                    self._check_session()

                self._save_state(self._page, self._page.main_frame, "PAGE",
                                 "link: " + link.text + " (" + normalize_url(link.url) + ")", link.from_state_id,
                                 "open link: " + link.text, 'a[href="' + link.url + '"]', link.depth, self._get_link_reach(link))
                self._report.link_visited()
            except _Control:
                raise
            except Exception as e:
                strReason = get_first_line(error_message(e))
                self._report.failure("link " + link.url, strReason)
                self._listener.on_failure("link " + link.url, strReason)
                CrawlLog.warn("링크 %s 실패 — %s", link.url, strReason)

    def _enqueue_links(self, target, from_state_id: str, depth: int) -> None:
        if depth >= self._config.get_max_depth():
            return

        for link in self._collector.get_links(target):
            strUrl = re.sub(r"#.*$", "", link.href, count=1)
            bSkip = not strUrl.startswith("http") or not self._guard.is_allowed_host(strUrl)

            if not bSkip:
                bSkip = None is not _FILE_LINK.fullmatch(strUrl)

            if not bSkip:
                bSkip = self._guard.is_dangerous_url(strUrl) or self._guard.is_dangerous_text(link.text)

            if bSkip:
                continue

            strNormalized = normalize_url(strUrl)

            if _add(self._queued_links, strNormalized) and not self._repository.has_normalized_url(strNormalized):
                self._links.append(_PendingLink(strUrl, link.text, link.frame_name, link.table_index, link.target, link.hidden,
                                                from_state_id, depth + 1))

    # ---------------------------------------------------------------- 화면 안 버튼 (clickButtons=true, 명세 §6.4)

    def _explore_buttons(self) -> None:
        """모은 화면마다 본문의 버튼 · 탭을 하나씩 실제로 누른다. 누를 때마다 그 화면을 다시 열고,
        새 화면이 나오면 저장한다(재현 경로 = 부모 경로 + 버튼 클릭). 새 화면의 링크 · 버튼도 clickDepth 까지 이어서 본다.
        테스트 사이트에서만 켠다 — 주문 · 취소 · 담기 같은 동작이 실제로 일어난다."""
        explored: Set[str] = set()
        pressed: Set[str] = set()

        CrawlLog.info("화면 안 버튼 탐색 — 화면 %d개 (최대 단계 %d, confirm 은 수락)", len(self._saved_states),
                      self._config.get_click_depth())

        while True:
            todo = [strId for strId in list(self._saved_states.keys()) if strId not in explored]

            if not todo:
                return

            for stateId in todo:
                explored.add(stateId)
                nDepth = self._button_depth.get(stateId, 0)

                if nDepth < self._config.get_click_depth():
                    self._press_buttons(stateId, nDepth, pressed)

            # 버튼으로 연 화면의 링크
            self._explore_links()

    def _press_buttons(self, state_id: str, depth: int, pressed: Set[str]) -> None:
        state = self._saved_states[state_id]
        strPath = as_text(jget(jget(state, "menuPath"), 0), state_id)
        strRawUrl = as_text(jget(state, "rawUrl"), "")
        strUrlKey = normalize_url(strRawUrl)
        strHash = get_struct_hash(jget(state, "elements"))

        try:
            self._attempt("화면 " + state_id + " 다시 열기", lambda: self._reopen(state_id))
            candidates = self._collector.get_button_candidates(self._page)
        except _Control:
            raise
        except Exception as e:
            CrawlLog.warn("화면 %s 를 다시 열지 못했습니다 — %s", state_id, get_first_line(error_message(e)))
            return

        for c in candidates:
            self._check_cancelled()

            strWhat = strPath + " › " + c.text

            # 같은 화면(정규화 URL)의 같은 글자 버튼은 한 번만 — 중복 상태 · 같은 틀의 화면(상품 상세 여러 개)에서 되풀이하지 않는다
            if not _add(pressed, strUrlKey + "\u0001" + c.text):
                continue

            if is_logout_text(c.text):
                CrawlLog.info("로그아웃 버튼이라 누르지 않습니다 — %s", strWhat)
                continue

            if self._guard.is_dangerous_text(c.text):
                CrawlLog.info("위험 버튼이라 누르지 않습니다 — %s", strWhat)
                continue

            outcome: Optional[_ClickOutcome] = None

            try:
                nTry = 1

                while True:
                    def press(c=c) -> _ClickOutcome:
                        self._reopen(state_id)
                        self._guard.drain_dialogs()
                        self._server_errors.clear()
                        return self._click_and_detect(c, False)

                    outcome = self._attempt("버튼 " + strWhat, press)

                    if not self._is_retry_needed(nTry, "버튼 " + strWhat):
                        break

                    if outcome.target is not self._page:
                        _close_quietly(outcome.target)

                    nTry += 1

                self._report.button_clicked()

                if "NONE" == outcome.structure or self._is_same_screen(outcome, strUrlKey, strHash):
                    dialogs = self._guard.drain_dialogs()
                    CrawlLog.info("버튼 %s — 화면 그대로%s", strWhat, "" if not dialogs else " (대화상자 " + " / ".join(dialogs) + ")")
                    continue

                newId = self._save_state(outcome.target, outcome.body, outcome.structure, strWhat, state_id,
                                         "click button: " + strWhat, _get_selector(c) if c.selector is None else c.selector, 1,
                                         self._get_button_reach(state_id, c))

                self._button_depth.setdefault(newId, depth + 1)
            except _Control:
                raise
            except Exception as e:
                strReason = get_first_line(error_message(e))
                self._report.failure("button " + strWhat, strReason)
                self._listener.on_failure("button " + strWhat, strReason)
                CrawlLog.warn("버튼 %s 실패 — %s", strWhat, strReason)
            finally:
                if outcome is not None and outcome.target is not self._page:
                    _close_quietly(outcome.target)

    def _is_same_screen(self, outcome: _ClickOutcome, url_key: str, struct_hash: str) -> bool:
        """눌렀더니 같은 주소 · 같은 구조로 돌아왔다(수량 + 처럼 다시 읽기만 한 경우) — 새 화면으로 저장하지 않는다"""
        if (outcome.target is not self._page or outcome.body is not self._page.main_frame
                or url_key != normalize_url(self._page.url)):
            return False

        return struct_hash == self._collector.get_shape(self._page.main_frame).hash

    def _reopen(self, state_id: str) -> None:
        """저장한 화면을 다시 연다 — 주소로 열리는 화면은 주소로, AJAX · frame 화면은 재현 경로를 밟아서"""
        state = self._saved_states[state_id]
        strStructure = as_text(jget(state, "structure"), "PAGE")
        reach = self._reach_by_id.get(state_id)

        if "PAGE" == strStructure or "POPUP" == strStructure or reach is None:
            self._open(self._page, as_text(jget(state, "rawUrl"), self._start_url))
            self._settle(self._page)
        else:
            self._replay(reach)

        if self._login_required and self._collector.is_login_screen(self._page):
            self._check_session()

    def _replay(self, reach: list) -> None:
        """재현 경로(reach)를 처음부터 밟는다"""
        for step in items(reach):
            strAction = as_text(jget(step, "action"))

            if "goto" == strAction:
                self._open(self._page, as_text(jget(step, "url")))
                self._settle(self._page)
                continue

            frame = self._get_frame(as_text(jget(step, "frame"), ""))

            if has_non_null(step, "selector"):
                target = frame.locator(as_text(step["selector"])).first
            elif as_bool(jget(step, "dataRow"), False):
                target = frame.locator("table").nth(as_int(jget(step, "tableIndex"))).locator("a").first
            else:
                target = _locate(frame, Candidate(frame.name, frame.url, as_text(jget(step, "text")), "", None, None, "", None))

            if "hover" == strAction:
                self._hover(target)
                continue

            target.click(timeout=self._get_click_wait())
            self._settle(self._page)

    def _hover(self, target) -> None:
        """마우스를 올리고 hoverWaitMs 기다린다 — 펼쳐지는 메뉴(애니메이션 · setTimeout)를 기다리려고"""
        target.hover(timeout=self._get_click_wait())
        self._page.wait_for_timeout(self._get_hover_wait())

    def _probe_hover_menus(self, queue: Deque[_MenuItem], known: Set[str], tops: List[Candidate],
                           hover_parents: Set[str]) -> None:
        """시작 화면의 메뉴 후보마다 마우스를 올려 보고, 올리기 전에는 숨어 있다가 새로 보이는 항목을 그 메뉴의 하위 메뉴로 넣는다.
        여기서 나는 오류는 크롤링을 멈추지 않는다 — 그 메뉴만 건너뛴다."""
        setVisibleAtStart = {_get_known_key(c) for c in tops}

        for oTop in tops:
            self._check_cancelled()

            try:
                self._go_start()
                self._hover(_locate(self._find_frame(oTop), oTop))

                lstAfter = self._collector.get_click_candidates(self._page, self._config.get_menu_selector())
                oParent = _MenuItem.of(oTop)
                nFound = 0

                for oChild in lstAfter:
                    if _get_known_key(oChild) in setVisibleAtStart:
                        continue

                    nFound += 1
                    self._offer_hover_child(queue, known, oParent, oChild)

                if 0 < nFound:
                    hover_parents.add(_get_known_key(oTop))
                    CrawlLog.info("메뉴 %s — 마우스를 올리면 하위 메뉴 %d개", oTop.text, nFound)
            except _Control:
                raise
            except Exception as e:
                CrawlLog.warn("메뉴 %s 에 마우스를 올려 보지 못했습니다 — %s", oTop.text, get_first_line(error_message(e)))

    def _get_frame(self, name: str):
        if "" != name:
            for f in self._page.frames:
                if name == f.name:
                    return f

        return self._page.main_frame

    def _get_button_reach(self, parent_id: str, c: Candidate) -> list:
        """버튼 화면 — 부모 화면의 경로 + 버튼 클릭(수집 때 확인한 selector 를 함께 남긴다)"""
        parent = self._reach_by_id.get(parent_id)
        reach = self._get_start_reach() if parent is None else copy.deepcopy(parent)
        step = {"action": "click", "frame": c.frame_name}
        _put_role(step, c.tag)
        step["text"] = c.text

        if c.selector is not None:
            step["selector"] = c.selector

        reach.append(step)
        return reach

    # ---------------------------------------------------------------- 공통

    def _is_retry_needed(self, n_try: int, what: str) -> bool:
        """방금 한 동작 중에 서버 오류(5xx)가 있었으면 한 번 더 해 볼지 정한다.
        다시 해도 오류면 그대로 저장하고, 상태의 serverErrors 와 리포트에 남는다."""
        if not self._server_errors:
            return False

        if _MAX_TRIES <= n_try:
            CrawlLog.warn("%s — 다시 해도 서버 오류(%s), 오류 화면으로 남깁니다", what, self._server_errors[0])
            return False

        CrawlLog.warn("%s — 서버 오류(%s), 한 번 더 해 봅니다", what, self._server_errors[0])
        return True

    def _check_cancelled(self) -> None:
        if self._cancelled():
            raise _Cancelled()

    def _go_start(self) -> None:
        self._open(self._page, self._start_url)
        self._settle(self._page)

        if self._login_required and self._collector.is_login_screen(self._page):
            CrawlLog.warn("시작 화면에 로그인 입력칸이 보입니다 — 세션 만료")
            raise _SessionExpired()

    def _check_session(self) -> None:
        """클릭 · 링크 뒤 로그인 화면이 보였을 때 세션이 정말 끊겼는지 본다.
        로그인한 뒤에도 로그인 폼을 보여 주는 메뉴(계정 링크가 /login 인 사이트)가 있어서,
        같은 쿠키로 새 탭에 시작 화면을 열어 그것도 로그인 화면일 때만 만료로 본다."""
        probe = self._context.new_page()

        try:
            self._open(probe, self._start_url)

            try:
                self._settle(probe)
            except _NotSettled:
                # 확인용 탭 — 덜 가라앉았어도 로그인 화면인지는 볼 수 있다
                pass

            if self._collector.is_login_screen(probe):
                CrawlLog.warn("로그인 화면이 보입니다 — 시작 화면도 로그인 화면이라 세션 만료로 봅니다")
                raise _SessionExpired()
        finally:
            _close_quietly(probe)

        CrawlLog.info("로그인 화면이 보이지만 시작 화면은 로그인돼 있습니다 — 로그인 폼 화면으로 보고 계속합니다")

    # ---------------------------------------------------------------- 오류 나면 기다리는 시간을 늘려 다시

    def _attempt(self, what: str, action: Callable):
        """기다리는 시간으로 해 보고, 오류(요소를 못 찾음 · 못 누름 · 열기 시간 초과 · 화면이 안 가라앉음)면
        기다리는 시간마다 retryWaitStepsMs 만큼 더해 다시 한다 — 기본 재시도 +1초, 재재시도 +5초.
        그래도 안 되면 크롤링을 멈춘다(HALTED) — 모은 데까지는 남고 이어 하기로 다시 시작한다."""
        steps = self._config.get_retry_wait_steps_ms()
        nRetry = 0

        while True:
            self._set_wait_bonus(0 if 0 == nRetry else steps[nRetry - 1])

            try:
                return action()
            except _RETRYABLE as e:
                strReason = get_first_line(error_message(e))

                if len(steps) <= nRetry:
                    self._report.failure(what, strReason + " — 기다리는 시간 +" + "[" + ", ".join(str(s) for s in steps) + "]"
                                         + "ms 로 다시 했다")
                    self._listener.on_failure(what, strReason)
                    raise _CrawlHalted(what + " — " + strReason)

                CrawlLog.warn("%s — %s, 기다리는 시간 +%dms 로 다시 해 봅니다 (%d/%d)", what, strReason, steps[nRetry], nRetry + 1,
                              len(steps))
                self._reset_page()
            finally:
                self._set_wait_bonus(0)

            nRetry += 1

    def _open(self, target, url: str) -> None:
        """주소로 연다 — HTML 골격(DOMContentLoaded)까지만 기다린다. 나머지는 _settle 의 안정 판정에 맡긴다"""
        target.goto(url, wait_until="domcontentloaded")

    def _reset_page(self) -> None:
        """다시 하기 전에 걸려 있던 로딩을 끊는다 — 끝나지 않은 이동이 남아 있으면 같은 주소를 다시 열 때 net::ERR_ABORTED 가 난다"""
        try:
            self._page.goto("about:blank", timeout=self._config.get_click_wait_ms())
        except PlaywrightError:
            # 끊는 것만이 목적이다 — 실패해도 다시 해 본다
            pass

        # 끊긴 요청의 끝 소식이 안 오기도 한다 — 남겨 두면 다시 해도 계속 안 가라앉은 것으로 본다
        self._inflight.clear()

    def _set_wait_bonus(self, bonus_ms: int) -> None:
        """기다리는 시간마다 더할 값을 바꾼다 — 시간을 따로 주지 않은 Playwright 동작의 기본 제한도 함께"""
        self._wait_bonus_ms = bonus_ms
        self._collector.set_aria_timeout_ms(self._config.get_aria_timeout_ms() + bonus_ms)
        self._context.set_default_timeout(self._get_click_wait())
        self._context.set_default_navigation_timeout(self._config.get_navigate_timeout_ms() + bonus_ms)

    def _get_click_wait(self) -> int:
        return self._config.get_click_wait_ms() + self._wait_bonus_ms

    def _get_settle_pause(self) -> int:
        return self._config.get_settle_pause_ms() + self._wait_bonus_ms

    def _get_stable_interval(self) -> int:
        return self._config.get_stable_interval_ms() + self._wait_bonus_ms

    def _get_hover_wait(self) -> int:
        return self._config.get_hover_wait_ms() + self._wait_bonus_ms

    def _settle(self, target) -> None:
        """클릭 · 이동 뒤 화면이 가라앉기를 기다린다. 각 단계의 상한은 clickWaitMs.
        상한까지 기다려도 진행 중 요청이 남거나 구조가 계속 바뀌면 _NotSettled — _attempt 가 기다리는 시간을 늘려 다시 한다."""
        nTimeout = self._get_click_wait()

        try:
            target.wait_for_timeout(self._get_settle_pause())
            target.wait_for_load_state("load", timeout=nTimeout)
            target.wait_for_load_state("networkidle", timeout=nTimeout)
        except PlaywrightError:
            # 상한까지 기다렸으면 그대로 진행
            pass

        for f in target.frames:
            try:
                f.wait_for_load_state("load", timeout=nTimeout)
            except PlaywrightError:
                # 떨어져 나갔거나 늦는 frame — 그대로 진행
                pass

        # 데이터를 받은 뒤에 그리는 화면이 있다 — 진행 중인 요청이 없고 구조가 더 바뀌지 않을 때까지 기다린다
        dDeadline = time.time() * 1000 + self._get_click_wait()
        strPrev = self._get_shape(target)

        while time.time() * 1000 < dDeadline:
            target.wait_for_timeout(self._get_stable_interval())

            for request in [r for r in self._inflight if _is_orphan(r)]:
                self._inflight.discard(request)

            strNow = self._get_shape(target)

            if not self._inflight and strNow == strPrev:
                return

            strPrev = strNow

        if not self._inflight:
            raise _NotSettled("화면이 %dms 안에 가라앉지 않았습니다 (진행 중 요청 없음 — 화면 구조가 계속 바뀜)" % self._get_click_wait())

        pendingUrls = [r.url for r in list(self._inflight)[:3]]

        raise _NotSettled("화면이 %dms 안에 가라앉지 않았습니다 (진행 중 요청 %d개: %s)"
                          % (self._get_click_wait(), len(self._inflight), " , ".join(pendingUrls)))

    def _get_shape(self, target) -> str:
        return "".join(self._collector.get_shape(f).hash + "|" for f in target.frames if not f.is_detached())

    def _save_state(self, target, body, structure: str, menu_path: str, from_state_id: Optional[str],
                    action: Optional[str], selector: Optional[str], depth: int, reach: list) -> str:
        """상태를 모아 저장한다(명세 §7 · §8). 같은 (정규화 URL + 구조 해시)면 도달 경로만 더한다. stateId 를 돌려준다"""
        frames = []
        bodyNode = None

        for f in target.frames:
            node = self._collector.collect_frame(f, True)
            frames.append(node)

            if f is body:
                bodyNode = node

        if bodyNode is None:
            bodyNode = frames[0]

        strBodyUrl = as_text(jget(bodyNode, "frameUrl"), target.url)
        key = StateKey.of(strBodyUrl, jget(bodyNode, "elements"))
        existing = self._repository.find(key)
        strMergeHash = get_merge_hash(jget(bodyNode, "elements"))

        # 주소는 달라도 구조가 같으면 같은 코드로 그린 화면(상품 상세 여러 개 등) — 변형으로만 남기고 링크 · 버튼은 더 보지 않는다
        if existing is None and self._config.is_merge_same_structure():
            existing = self._repository.find_by_hash(strMergeHash)

            if existing is not None:
                stateId = existing
                variant = {"url": strBodyUrl, "normalizedUrl": key.normalized_url, "menuPath": menu_path, "reach": reach}

                if not self._is_known_variant(stateId, variant):
                    self._repository.add_variant(stateId, variant)

                    state = self._saved_states.get(stateId)

                    if state is not None:
                        if not isinstance(state.get("variants"), list):
                            state["variants"] = []

                        state["variants"].append(variant)

                self._guard.drain_dialogs()
                self._report.duplicate()
                self._listener.on_state(stateId, menu_path, key.normalized_url, structure, len(items(jget(bodyNode, "elements"))),
                                        False)
                CrawlLog.info("같은 구조 — %s 의 변형으로 기록 ← %s (%s)", stateId, menu_path, key.normalized_url)

                if from_state_id is not None and from_state_id != stateId:
                    self._repository.add_transition(from_state_id, stateId, action, selector)

                return stateId

        if existing is not None:
            stateId = existing
            self._repository.add_menu_path(stateId, menu_path)
            self._update_reach(stateId, reach)
            self._report.duplicate()
            self._listener.on_state(stateId, menu_path, key.normalized_url, structure, len(items(jget(bodyNode, "elements"))), False)
            CrawlLog.info("중복 상태 %s ← %s", stateId, menu_path)
        else:
            if self._repository.get_size() >= self._config.get_max_states():
                raise _MaxStatesReached()

            state = {
                "rawUrl": strBodyUrl,
                "mergeHash": strMergeHash,
                "frameName": as_text(jget(bodyNode, "frameName"), ""),
                "structure": structure,
                "menuPath": [menu_path],
                "reach": reach,
                "dialogs": list(self._guard.drain_dialogs()),
                "collectedAt": now_offset(),
                # 다시 해도 서버 오류였던 화면 — 스크립트를 만들 때 걸러낼 수 있게 남긴다
                "serverErrors": list(self._server_errors),
            }

            for strField in ("title", "heading", "forms", "elements", "gridHeaders", "iframes"):
                if has(bodyNode, strField):
                    state[strField] = copy.deepcopy(bodyNode[strField])

            nElementCount = len(items(jget(bodyNode, "elements")))
            state["elementCount"] = nElementCount
            state["frames"] = frames

            stateId = self._repository.save(key, state)
            self._reach_by_id[stateId] = reach
            self._saved_states[stateId] = state
            self._collector.screenshot(target, self._repository.get_screenshot_path(stateId))
            self._report.new_state()
            self._listener.on_state(stateId, menu_path, key.normalized_url, structure, nElementCount, True)
            CrawlLog.info("새 상태 %s [%s] 요소 %d개 — %s (%s)%s", stateId, structure, nElementCount, menu_path, key.normalized_url,
                          "" if not self._server_errors else " ⚠ 서버 오류 화면")

            self._enqueue_links(target, stateId, depth)

        if from_state_id is not None and from_state_id != stateId:
            self._repository.add_transition(from_state_id, stateId, action, selector)

        return stateId

    def get_halt_reason(self) -> str:
        """HALTED 로 멈춘 이유(무엇 — 오류 첫 줄). 멈추지 않았으면 빈 글"""
        return self._halt_reason

    def get_saved_states(self) -> Dict[str, dict]:
        """이번 실행에서 새로 저장한 상태(stateId → 상태 JSON)"""
        return self._saved_states

    # ---------------------------------------------------------------- 재현 경로

    def _get_start_reach(self) -> list:
        """시작 화면 — goto 하나"""
        return [{"action": "goto", "url": self._start_url}]

    def _get_menu_reach(self, item: _MenuItem) -> list:
        """메뉴 화면 — 시작 화면에서 차례로 누른 메뉴(상위 메뉴 펼침 포함)"""
        reach = self._get_start_reach()

        for nStep, c in enumerate(item.steps):
            step = {"action": "hover" if item.is_hover(nStep) else "click", "frame": c.frame_name}
            _put_role(step, c.tag)
            step["text"] = c.text

            if c.href is not None:
                step["href"] = c.href

            _put_data_row(step, c.table_index)
            reach.append(step)

        return reach

    def _get_link_reach(self, link: _PendingLink) -> list:
        """링크 화면 — 부모 화면의 경로 + 링크 클릭. 부모 경로를 모르거나 링크 글자가 없으면 바로 연다"""
        parent = self._reach_by_id.get(link.from_state_id)

        if parent is None or jblank(link.text) or link.hidden:
            oGotoStep = {"action": "goto", "url": link.url}

            # 안 보이는 링크 — 이 경로는 눌러서 닿는 길(메뉴 경로)을 덮어쓰지 않는다(_update_reach)
            if link.hidden:
                oGotoStep["hiddenLink"] = True

            return [oGotoStep]

        reach = copy.deepcopy(parent)
        step = {"action": "click", "frame": link.frame_name, "role": "link", "text": link.text, "href": link.url}
        _put_data_row(step, link.table_index)

        # frame 안의 링크는 target 이 없으면 그 frame 안에 열린다 — 크롤러는 주소로 바로 열어 모았지만,
        # 사람이 누르면 page URL 은 그대로고 화면은 그 frame 에 뜬다
        strTarget = "" if link.target is None else jtrim(link.target)

        if "" != link.frame_name and ("" == strTarget or "_self" == strTarget.lower()):
            step["opensIn"] = link.frame_name
        elif "" != strTarget and not strTarget.startswith("_"):
            step["opensIn"] = strTarget

        reach.append(step)
        return reach

    def _is_known_variant(self, state_id: str, variant: dict) -> bool:
        """대표 상태에 이미 있는 변형인가 — 주소 · 메뉴 경로가 같은 것, 또는 숨은 링크(주소로 열기)로 닿았는데 같은 주소의 변형이 이미 있는 것"""
        state = self._saved_states.get(state_id)

        if state is None:
            state = self._repository.load(state_id)

        if state is None:
            return False

        oReach = jget(variant, "reach")
        bHiddenLink = as_bool(jget(jget(oReach, len(items(oReach)) - 1), "hiddenLink"), False)
        strNewUrl = as_text(jget(variant, "normalizedUrl"))
        strNewPath = as_text(jget(variant, "menuPath"))

        for v in items(jget(state, "variants")):
            bSameUrl = strNewUrl == as_text(jget(v, "normalizedUrl"))

            if bSameUrl and (bHiddenLink or strNewPath == as_text(jget(v, "menuPath"))):
                return True

        return False

    def _update_reach(self, state_id: str, reach: list) -> None:
        """같은 화면에 더 짧은 경로로 닿았으면 바꾼다. 지난 실행에서 저장된 상태는 저장된 경로와 견준다"""
        known = self._reach_by_id.get(state_id)

        if known is None:
            oState = self._repository.load(state_id)

            if oState is not None and isinstance(oState.get("reach"), list):
                known = oState["reach"]

        bHiddenLink = as_bool(jget(jget(reach, len(reach) - 1), "hiddenLink"), False)

        if known is not None and (len(known) <= len(reach) or bHiddenLink):
            self._reach_by_id[state_id] = known
            return

        self._reach_by_id[state_id] = reach
        self._repository.set_reach(state_id, reach)

        state = self._saved_states.get(state_id)

        if state is not None:
            state["reach"] = reach
