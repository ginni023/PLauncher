"""smoke-input.json — LLM 에 스모크 테스트 스크립트를 만들어 달라고 넘길 묶음 — Java 판 SmokeInput.

::

    {
      "site": "http://localhost:8080/",
      "layout": "- banner: ...",          ← 절반이 넘는 화면에 똑같이 나오는 aria 덩어리(머리 · 메뉴) — 한 번만 적는다
      "layoutElements": [...],           ← 절반이 넘는 화면에 나오는 요소(메뉴 링크 등) — 한 번만 적는다
      "screens": [ { "id", "title", "url", "structure", "frame", "menuPath", "reach": [...], "aria", "gridHeaders", "elements": [...] } ],
      "skipped": [ { "id", "url", "reason" } ]   ← 서버 오류 화면 — 기대값으로 쓰면 안 된다
    }

- aria 는 본문 frame 것만, 이미 걸러진 것(입력칸 값 · 표 데이터 행 없음)이다.
- reach 는 그 화면에 닿는 가장 짧은 단계 — goto · click(frame · role · text · href).
- elements 는 본문의 입력 · 버튼 · 링크 · onclick 요소 전부. id · name 이 있으면 selector 를 적어 준다.
"""

from __future__ import annotations

import copy
import json
import re
from typing import Any, Dict, List, Optional

from ._jutil import (as_bool, as_text, dumps_compact, has, has_non_null, is_array, is_empty, items, jblank, jget, jsplit,
                     jtrim, now_offset, write_json)
from .repository import StateRepository

# 이 비율을 넘는 화면에 똑같이 나오는 맨 위 aria 덩어리는 공통 레이아웃으로 뺀다
_LAYOUT_RATIO = 0.5


def build(site: str, repository: StateRepository, this_run: Dict[str, dict]) -> dict:
    """
    :param this_run: 이번 실행에서 저장한 상태 — 없는 것은 repository.load 로 읽는다
    """
    skipped: List[dict] = []
    states: Dict[str, dict] = {}
    blocks: Dict[str, List[str]] = {}
    elements: Dict[str, List[dict]] = {}

    for s in repository.get_summaries():
        if s.server_error:
            skipped.append({"id": s.state_id, "url": s.normalized_url, "reason": "serverError"})
            continue

        state = this_run[s.state_id] if s.state_id in this_run else repository.load(s.state_id)

        if state is not None:
            states[s.state_id] = state
            blocks[s.state_id] = get_top_blocks(get_body_aria(state))
            elements[s.state_id] = compact_elements(jget(state, "elements"))

    # 무언가를 감싼 덩어리(하위 줄이 있는 것)만 — 이름 없는 "- textbox" 한 줄이 여러 화면에 있다고 레이아웃은 아니다
    lstBlockScreens = [[b for b in lstScreenBlocks if "\n" in b] for lstScreenBlocks in blocks.values()]
    layout = get_layout_blocks(lstBlockScreens)

    # 요소도 같은 기준 — JSON 글자로 견준다. 글자도 selector 도 없는 요소(이름 없는 입력칸)는 빼지 않는다
    lstElementScreens = [[dumps_compact(e) for e in lstScreenElements if has(e, "label") or has(e, "selector")]
                         for lstScreenElements in elements.values()]
    layoutElements = get_layout_blocks(lstElementScreens)

    root: dict = {
        "site": site,
        "generatedAt": now_offset(),
        "layout": "\n".join(layout),
        "layoutElements": [json.loads(strElement) for strElement in layoutElements],
    }

    screens: List[dict] = []
    root["screens"] = screens

    for strId, state in states.items():
        own = [b for b in blocks[strId] if b not in layout]
        screen: dict = {
            "id": strId,
            "title": as_text(jget(state, "title"), ""),
            "url": as_text(jget(state, "rawUrl"), ""),
            "structure": as_text(jget(state, "structure"), ""),
            "frame": get_body_frame(state),
            "menuPath": as_text(jget(jget(state, "menuPath"), 0), ""),
            "reach": copy.deepcopy(state["reach"]) if is_array(jget(state, "reach")) else [],
        }

        # 같은 구조의 다른 주소 · 입구(mergeSameStructure) — 같은 틀이라 테스트는 대표 화면 하나로 충분하다
        oVariants = jget(state, "variants")

        if is_array(oVariants) and not is_empty(oVariants):
            screen["variants"] = [{"url": as_text(jget(v, "url")), "menuPath": as_text(jget(v, "menuPath"))} for v in oVariants]

        screen["aria"] = "\n".join(own)
        screen["gridHeaders"] = copy.deepcopy(state["gridHeaders"]) if is_array(jget(state, "gridHeaders")) else []
        screen["elements"] = [el for el in elements[strId] if dumps_compact(el) not in layoutElements]
        screens.append(screen)

    root["screenCount"] = len(screens)
    root["skipped"] = skipped

    return root


def write(path, input_node: dict) -> None:
    write_json(path, input_node)


def get_body_frame(state: Any) -> str:
    """재현 경로를 따라갔을 때 본문이 뜨는 frame. 보통은 상태의 frameName 이지만,
    frame 안의 링크로 연 화면은 크롤러가 주소로 바로 열어 모았으므로 마지막 click 의 opensIn 이다."""
    strFrame = as_text(jget(state, "frameName"), "")
    reach = jget(state, "reach")

    if "" == strFrame and is_array(reach) and not is_empty(reach):
        return as_text(jget(reach[-1], "opensIn"), "")

    return strFrame


def get_body_aria(state: Any) -> str:
    """본문 frame 의 aria — 상태의 frameName · rawUrl 과 맞는 frame, 없으면 main frame"""
    main = None
    strStateFrameName = as_text(jget(state, "frameName"), "")
    strStateRawUrl = as_text(jget(state, "rawUrl"), "")

    for f in items(jget(state, "frames")):
        if as_text(jget(f, "frameName"), "") == strStateFrameName and as_text(jget(f, "frameUrl"), "") == strStateRawUrl:
            return as_text(jget(f, "ariaSnapshot"), "")

        if main is None and as_bool(jget(f, "isMainFrame")):
            main = f

    if main is None:
        return ""

    return as_text(jget(main, "ariaSnapshot"), "")


def get_top_blocks(aria: str) -> List[str]:
    """맨 위(들여쓰기 0) 항목마다 하위 줄까지 한 덩어리"""
    result: List[str] = []
    sb: Optional[List[str]] = None

    for strLine in aria.split("\n"):
        if strLine.startswith("- "):
            if sb is not None:
                result.append("\n".join(sb))

            sb = [strLine]
        elif sb is not None and not jblank(strLine):
            sb.append(strLine)

    if sb is not None:
        result.append("\n".join(sb))

    return result


def get_layout_blocks(screens: List[List[str]]) -> List[str]:
    """화면이 둘 이상이고, 절반이 넘는 화면에 똑같이 나오는 덩어리(처음 나온 차례)"""
    if 2 > len(screens):
        return []

    count: Dict[str, int] = {}

    for blocks in screens:
        for b in dict.fromkeys(blocks):
            count[b] = count.get(b, 0) + 1

    return [strBlock for strBlock, nCount in count.items() if nCount > len(screens) * _LAYOUT_RATIO]


def compact_elements(elements: Any) -> List[dict]:
    """요소를 짧게 — 빈 값은 빼고, class 는 앞 두 개만, onclick 은 true 일 때만.
    id · name 이 있으면 바로 쓸 수 있는 CSS selector 를 붙인다."""
    out: List[dict] = []

    for el in items(elements):
        e: dict = {}

        for strKey in ("tag", "id", "name", "type", "role", "label"):
            if has_non_null(el, strKey):
                strValue = as_text(el[strKey])

                if "" != strValue:
                    e[strKey] = strValue

        strCls = jtrim(as_text(jget(el, "cls"), ""))

        if "" != strCls:
            e["cls"] = " ".join(jsplit(r"\s+", strCls)[:2])

        if as_bool(jget(el, "onclick")):
            e["onclick"] = True

        # 수집할 때 브라우저에서 유일한지 확인한 selector 가 있으면 그것을 쓴다
        strSelector = as_text(el["selector"]) if has_non_null(el, "selector") else get_selector(e)

        if strSelector is not None:
            e["selector"] = strSelector

        out.append(e)

    return out


def get_selector(e: Any) -> Optional[str]:
    """#id(글자 · 숫자 · - · _ 만일 때) → [id="..."] → tag[name="..."] → 없음"""
    strId = as_text(jget(e, "id"), "")

    if "" != strId:
        return "#" + strId if re.fullmatch(r"[A-Za-z_][\w-]*", strId, re.ASCII) else '[id="' + strId.replace('"', '\\"') + '"]'

    strName = as_text(jget(e, "name"), "")

    if "" != strName:
        return as_text(jget(e, "tag"), "").lower() + '[name="' + strName.replace('"', '\\"') + '"]'

    return None
