"""콘솔과 crawl.log 에 같이 남기는 간단한 로그(명세 §8.2) — Java 판 CrawlLog."""

from __future__ import annotations

import os
import threading
from datetime import datetime
from typing import Callable, List, Optional, TextIO


class CrawlLog:
    """프로세스 하나에 하나 — 클래스 메서드로만 쓴다"""

    _lock = threading.RLock()
    _file: Optional[TextIO] = None
    _console = True
    # 에이전트 화면 등 — 로그 한 줄씩 받는다
    _listeners: List[Callable[[str], None]] = []

    @classmethod
    def open(cls, directory) -> None:
        with cls._lock:
            os.makedirs(directory, exist_ok=True)
            cls._file = open(os.path.join(directory, "crawl.log"), "a", encoding="utf-8", newline="")

    @classmethod
    def info(cls, fmt: str, *args) -> None:
        cls._write("INFO", fmt % args if args else fmt)

    @classmethod
    def warn(cls, fmt: str, *args) -> None:
        cls._write("WARN", fmt % args if args else fmt)

    @classmethod
    def _write(cls, level: str, message: str) -> None:
        with cls._lock:
            strLine = datetime.now().strftime("%H:%M:%S") + " " + level + " " + message

            if cls._console:
                try:
                    print(strLine, flush=True)
                except UnicodeEncodeError:
                    print(strLine.encode("ascii", "replace").decode("ascii"), flush=True)

            if cls._file is not None:
                # PrintWriter.println — 시스템 줄바꿈(Windows 는 \r\n)
                cls._file.write(strLine + os.linesep)
                cls._file.flush()

            for listener in list(cls._listeners):
                try:
                    listener(strLine)
                except Exception:
                    # 받는 쪽 오류로 크롤링이 멈추면 안 된다
                    pass

    @classmethod
    def set_console(cls, on: bool) -> None:
        """콘솔 출력을 켜고 끈다 — 에이전트 안에서는 끄고 리스너(add_listener)로 받는다"""
        cls._console = bool(on)

    @classmethod
    def add_listener(cls, listener: Callable[[str], None]) -> None:
        with cls._lock:
            cls._listeners.append(listener)

    @classmethod
    def remove_listener(cls, listener: Callable[[str], None]) -> None:
        with cls._lock:
            if listener in cls._listeners:
                cls._listeners.remove(listener)

    @classmethod
    def close(cls) -> None:
        with cls._lock:
            if cls._file is not None:
                cls._file.close()
                cls._file = None
