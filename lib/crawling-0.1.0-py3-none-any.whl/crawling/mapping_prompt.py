"""업무 테스트 ② — 1차 LLM 에 보낼 글 — Java 판 MappingPrompt.

고정 프롬프트(resources/prompt/mapping.md)에 업무(scenario.json)와 사이트 지도(site-map.json)를 채운다.
LLM 은 연결안(mapping.json)을 낸다(doc/업무테스트_입력양식.md §4).

명령줄::

    python -m crawling.mapping_prompt scenario.json site-map.json mapping-prompt.md
"""

from __future__ import annotations

import copy
import sys
from typing import Any

from ._jutil import dumps_pretty, items, jget, read_json, write_text
from .smoke_prompt import get_template

_TEMPLATE = get_template("mapping.md")


def build(scenario: Any, site_map: Any) -> str:
    # 사이트 지도의 스크린샷 경로는 LLM 에 쓸모가 없다 — ③ 화면이 쓴다
    oMap = copy.deepcopy(site_map)

    for s in items(jget(oMap, "screens")):
        if isinstance(s, dict):
            s.pop("screenshot", None)

    strPrompt = _TEMPLATE.replace("{{SCENARIO}}", dumps_pretty(scenario))

    return strPrompt.replace("{{SITE_MAP}}", dumps_pretty(oMap))


def main(args=None) -> None:
    args = sys.argv[1:] if args is None else args

    if 3 != len(args):
        print("쓰는 법: python -m crawling.mapping_prompt scenario.json site-map.json 내보낼.md")
        return

    strPrompt = build(read_json(args[0]), read_json(args[1]))

    write_text(args[2], strPrompt)

    print(args[2] + " — " + str(len(strPrompt)) + "자")


if __name__ == "__main__":
    main()
