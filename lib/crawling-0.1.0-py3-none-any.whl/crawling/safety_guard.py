"""탐색 중 실데이터가 바뀌지 않게 막는다(명세 §4) — Java 판 SafetyGuard.

- blockPost=true 일 때만 GET 외 요청을 abort — allowPostPattern 에 맞는 URL 은 통과. 막은 요청은 blocked-requests.log 에 남긴다.
  기본은 허용이다 — 대신 삭제 · 저장 같은 위험 버튼을 누르지 않는 것으로 막는다.
- allowedHost 밖으로의 이동(navigation) 은 abort.
- blockResources=true 일 때만 image · font · media 를 속도를 위해 abort(로그 없음).
- alert 는 accept, confirm · prompt 는 dismiss(clickButtons=true 면 confirm 도 accept). 메시지는 상태에 기록한다.
- 다운로드는 취소한다.

로그인이 끝난 뒤의 컨텍스트에만 건다. 로그인 POST 가 막히면 안 된다.
"""

from __future__ import annotations

import os
import re
from typing import Dict, List, Optional

from ._jutil import Uri, get_host as _uri_get_host, now_local, parse_uri
from .config import CrawlerConfig

_SKIP_RESOURCES = {"image", "font", "media"}

# URL 에 이것이 들어 있으면 링크를 따라가지 않는다
_DANGER_URL_WORDS = ["logout", "logoff", "signout", "sign_out", "delete", "remove"]
# 글자에 이것이 들어 있으면 dangerWords 와 상관없이 누르지 않는다 — 세션이 끊기면 크롤링이 멈춘다
_LOGOUT_WORDS = ["로그아웃", "logout", "log out", "logoff", "sign out", "signout"]


def get_host(uri: Uri) -> str:
    """host 또는 host:port — 기본 포트는 붙이지 않는다"""
    return _uri_get_host(uri)


def is_logout_text(text: Optional[str]) -> bool:
    strLower = "" if text is None else text.lower()

    return _contains_any(strLower, _LOGOUT_WORDS)


def _contains_any(text: str, words: List[str]) -> bool:
    for strWord in words:
        if strWord in text:
            return True

    return False


class SafetyGuard:
    def __init__(self, config: CrawlerConfig, allowed_host: str, output_dir):
        self._allowed_host = allowed_host.lower()
        self._block_post = config.is_block_post()
        strAllowPostPattern = config.get_allow_post_pattern()
        self._allow_post = None if "" == strAllowPostPattern else re.compile(strAllowPostPattern)
        self._danger_words = config.get_danger_words()
        # clickButtons=true 면 confirm 을 수락한다 — 주문 취소처럼 확인을 거쳐야 끝나는 동작을 실제로 해 본다
        self._accept_confirm = config.is_click_buttons()
        # blockResources=true 일 때만 image · font · media 를 끊는다 — 기본은 사람이 볼 때처럼 다 받는다
        self._block_resources = config.is_block_resources()
        self._blocked_count: Dict[str, int] = {}
        self._dialogs: List[str] = []

        os.makedirs(output_dir, exist_ok=True)
        # PrintWriter.println — 시스템 줄바꿈(Windows 는 \r\n)
        self._blocked_log = open(os.path.join(output_dir, "blocked-requests.log"), "a", encoding="utf-8", newline="")

    def install(self, context) -> None:
        context.route("**/*", self._handle)
        context.on("page", self._watch)

    def _handle(self, route) -> None:
        request = route.request
        strUrl = request.url

        if self._block_resources and request.resource_type in _SKIP_RESOURCES:
            route.abort()
            return

        if request.is_navigation_request() and not self.is_allowed_host(strUrl):
            self._block(route, "HOST", request.method, strUrl)
            return

        strMethod = request.method.upper()

        if self._block_post and strMethod not in ("GET", "HEAD", "OPTIONS") and not self._is_allowed_post(strUrl):
            self._block(route, strMethod, strMethod, strUrl)
            return

        route.continue_()

    def _is_allowed_post(self, url: str) -> bool:
        """allowPostPattern 에 맞는 URL 인가 — 패턴이 없으면 False"""
        if self._allow_post is None:
            return False

        return None is not self._allow_post.fullmatch(url)

    def _count(self, key: str) -> None:
        self._blocked_count[key] = self._blocked_count.get(key, 0) + 1

    def _block(self, route, count_key: str, method: str, url: str) -> None:
        route.abort()
        self._count(count_key)
        self._blocked_log.write(now_local() + "\t" + count_key + "\t" + method + "\t" + url + os.linesep)
        self._blocked_log.flush()

    def _watch(self, page) -> None:
        page.on("dialog", self._handle_dialog)
        page.on("download", self._handle_download)

    def _handle_dialog(self, dialog) -> None:
        strType = dialog.type

        self._dialogs.append(strType + ": " + dialog.message)

        # beforeunload 를 취소하면 이동이 멈추므로 받아 준다
        if "alert" == strType or "beforeunload" == strType or (self._accept_confirm and "confirm" == strType):
            dialog.accept()
        else:
            dialog.dismiss()

    def _handle_download(self, download) -> None:
        self._count("DOWNLOAD")
        self._blocked_log.write(now_local() + "\tDOWNLOAD\t" + download.suggested_filename + "\t" + download.url + os.linesep)
        self._blocked_log.flush()
        download.cancel()

    def is_allowed_host(self, url: str) -> bool:
        try:
            uri = parse_uri(url)
        except ValueError:
            return False

        strScheme = "" if uri.scheme is None else uri.scheme.lower()

        # about:blank · data: · blob: 같은 것은 밖으로 나가는 이동이 아니다
        if strScheme not in ("http", "https"):
            return True

        return self._allowed_host == get_host(uri)

    def is_dangerous_text(self, text: Optional[str]) -> bool:
        if text is None:
            return False

        return _contains_any(text, self._danger_words)

    @staticmethod
    def is_logout_text(text: Optional[str]) -> bool:
        return is_logout_text(text)

    def is_dangerous_url(self, url: str) -> bool:
        return _contains_any(url.lower(), _DANGER_URL_WORDS)

    def drain_dialogs(self) -> List[str]:
        """지금까지 뜬 다이얼로그 메시지를 꺼내고 비운다"""
        drained = list(self._dialogs)
        self._dialogs.clear()
        return drained

    def get_blocked_count(self) -> Dict[str, int]:
        """막은 요청 수 — 키 이름 차례(TreeMap)"""
        return dict(sorted(self._blocked_count.items()))

    def close(self) -> None:
        self._blocked_log.close()
