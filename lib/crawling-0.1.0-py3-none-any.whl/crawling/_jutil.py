"""Java 판과 똑같이 동작하게 맞추는 도우미.

Java 판(com.pefer.crawler)의 로직을 그대로 옮기면서, 결과가 달라질 수 있는 자리를 여기서 Java 규칙대로 맞춘다.

- Jackson JsonNode 의 asText · asInt · asBoolean · path · hasNonNull — 없는 키(MISSING)와 JSON null(None)을 가른다
- Java String 의 trim · strip · isBlank · split — 파이썬 str 메서드와 공백 기준이 다르다
- java.net.URI — 주소를 읽는 규칙(호스트 · 포트 · 못 쓰는 글자)
- 정규식 — Java 의 \\s · \\d · \\w 는 ASCII 만 본다 → re.ASCII
"""

from __future__ import annotations

import json
import os
import re
import unicodedata
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Iterable, Optional


# ---------------------------------------------------------------- JSON (Jackson 규칙)


class _Missing:
    """Jackson MissingNode — 없는 키 · 범위 밖 차례. JSON null(None)과 다르다."""

    _instance: Optional["_Missing"] = None

    def __new__(cls) -> "_Missing":
        if cls._instance is None:
            cls._instance = super().__new__(cls)

        return cls._instance

    def __repr__(self) -> str:
        return "MISSING"

    def __bool__(self) -> bool:
        return False


MISSING: Any = _Missing()
_NO_DEFAULT: Any = object()


def jget(node: Any, key: Any) -> Any:
    """node.path(key) — dict 면 키, list 면 차례. 없으면 MISSING"""
    if isinstance(node, dict):
        return node.get(key, MISSING) if isinstance(key, str) else MISSING

    if isinstance(node, list) and isinstance(key, int) and not isinstance(key, bool):
        return node[key] if 0 <= key < len(node) else MISSING

    return MISSING


def has(node: Any, key: str) -> bool:
    """node.has(key) — 값이 null 이어도 키가 있으면 true"""
    return isinstance(node, dict) and key in node


def has_non_null(node: Any, key: str) -> bool:
    """node.hasNonNull(key)"""
    return isinstance(node, dict) and node.get(key, None) is not None


def is_array(node: Any) -> bool:
    return isinstance(node, list)


def size(node: Any) -> int:
    """node.size() — 배열 · 객체만 길이가 있다"""
    return len(node) if isinstance(node, (list, dict)) else 0


def is_empty(node: Any) -> bool:
    """node.isEmpty() — size() == 0"""
    return 0 == size(node)


def items(node: Any) -> list:
    """for (JsonNode x : node) — 배열은 원소, 객체는 값, 그 밖은 빈 목록"""
    if isinstance(node, list):
        return list(node)

    if isinstance(node, dict):
        return list(node.values())

    return []


def _number_text(value: Any) -> str:
    if isinstance(value, float):
        if value != value:
            return "NaN"

        if value in (float("inf"), float("-inf")):
            return "Infinity" if value > 0 else "-Infinity"

        # Java Double.toString — 정수 값도 .0 을 붙인다
        return repr(value)

    return str(value)


def as_text(node: Any, default: Any = _NO_DEFAULT) -> Any:
    """node.asText() · node.asText(default)

    - 글자는 그대로, 숫자는 글자로, 참거짓은 true · false
    - 배열 · 객체는 ""
    - 없는 키(MISSING) — asText() 는 "", asText(default) 는 default
    - JSON null — asText() 는 "null", asText(default) 는 default
    """
    if node is MISSING:
        return "" if default is _NO_DEFAULT else default

    if node is None:
        return "null" if default is _NO_DEFAULT else default

    if isinstance(node, bool):
        return "true" if node else "false"

    if isinstance(node, str):
        return node

    if isinstance(node, (int, float)):
        return _number_text(node)

    return ""


def as_int(node: Any, default: int = 0) -> int:
    """node.asInt() · node.asInt(default)"""
    if isinstance(node, bool):
        return 1 if node else 0

    if isinstance(node, int):
        return node

    if isinstance(node, float):
        return int(node)

    if isinstance(node, str):
        try:
            return int(jtrim(node))
        except ValueError:
            try:
                return int(float(jtrim(node)))
            except ValueError:
                return default

    return default


def as_double(node: Any, default: float = 0.0) -> float:
    """node.asDouble(default)"""
    if isinstance(node, bool):
        return 1.0 if node else 0.0

    if isinstance(node, (int, float)):
        return float(node)

    if isinstance(node, str):
        try:
            return float(jtrim(node))
        except ValueError:
            return default

    return default


def as_bool(node: Any, default: bool = False) -> bool:
    """node.asBoolean() · node.asBoolean(default)"""
    if isinstance(node, bool):
        return node

    if isinstance(node, (int, float)):
        return 0 != node

    if isinstance(node, str):
        strTrimmed = jtrim(node)

        if "true" == strTrimmed:
            return True

        if "false" == strTrimmed:
            return False

        return default

    return default


def is_number(node: Any) -> bool:
    return isinstance(node, (int, float)) and not isinstance(node, bool)


# Jackson 의 줄바꿈 — System.lineSeparator() (Windows 는 \r\n)
LINE_SEPARATOR = os.linesep
_SHORT_ESCAPES = {'"': '\\"', "\\": "\\\\", "\n": "\\n", "\r": "\\r", "\t": "\\t", "\b": "\\b", "\f": "\\f"}


def _json_string(text: str) -> str:
    """Jackson 글자 쓰기 — \\" \\\\ \\n \\r \\t \\b \\f, 그 밖의 제어 문자는 \\u00XX(대문자). 한글 등은 그대로"""
    out = ['"']

    for ch in text:
        strEscape = _SHORT_ESCAPES.get(ch)

        if strEscape is not None:
            out.append(strEscape)
        elif ch < " ":
            out.append("\\u%04X" % ord(ch))
        else:
            out.append(ch)

    out.append('"')
    return "".join(out)


def _json_scalar(node: Any) -> str:
    if node is None or node is MISSING:
        return "null"

    if isinstance(node, bool):
        return "true" if node else "false"

    if isinstance(node, str):
        return _json_string(node)

    if isinstance(node, float):
        return _number_text(node)

    if isinstance(node, int):
        return str(node)

    return _json_string(str(node))


def dumps_pretty(node: Any) -> str:
    """ObjectMapper + INDENT_OUTPUT(DefaultPrettyPrinter)와 같은 글.

    - 객체는 한 줄에 키 하나, 들여쓰기 2칸, 키와 값 사이는 " : ", 빈 객체는 "{ }"
    - 배열은 한 줄로 "[ a, b ]", 객체 원소는 "[ {" … "}, {" … "} ]", 빈 배열은 "[ ]"
    - 줄바꿈은 System.lineSeparator() 와 같다(Windows 는 \\r\\n). 끝에 줄바꿈을 붙이지 않는다
    """
    out: list = []
    _pretty(node, 0, out)

    return "".join(out)


def _pretty(node: Any, nesting: int, out: list) -> None:
    if isinstance(node, dict):
        if not node:
            out.append("{ }")
            return

        nInner = nesting + 1
        strIndent = LINE_SEPARATOR + "  " * nInner
        out.append("{")
        bFirst = True

        for key, value in node.items():
            out.append(strIndent if bFirst else "," + strIndent)
            bFirst = False
            out.append(_json_string(str(key)))
            out.append(" : ")
            _pretty(value, nInner, out)

        out.append(LINE_SEPARATOR + "  " * nesting + "}")
        return

    if isinstance(node, (list, tuple)):
        if not node:
            out.append("[ ]")
            return

        # 배열은 한 줄로 쓰므로 들여쓰기 단계가 늘지 않는다(FixedSpaceIndenter)
        out.append("[ ")
        bFirst = True

        for value in node:
            if not bFirst:
                out.append(", ")

            bFirst = False
            _pretty(value, nesting, out)

        out.append(" ]")
        return

    out.append(_json_scalar(node))


def dumps_compact(node: Any) -> str:
    """JsonNode.toString() — 한 줄, 빈칸 없이"""
    if node is MISSING:
        return ""

    if isinstance(node, dict):
        return "{" + ",".join(_json_string(str(k)) + ":" + dumps_compact(v) for k, v in node.items()) + "}"

    if isinstance(node, (list, tuple)):
        return "[" + ",".join(dumps_compact(v) for v in node) + "]"

    return _json_scalar(node)


def read_json(path) -> Any:
    with open(path, "r", encoding="utf-8") as oFile:
        return json.load(oFile)


def write_text(path, text: str) -> None:
    """Files.writeString — 글자를 그대로(줄바꿈을 바꾸지 않고) UTF-8 로"""
    with open(path, "w", encoding="utf-8", newline="") as oFile:
        oFile.write(text)


def write_json(path, node: Any) -> None:
    write_text(path, dumps_pretty(node))


# ---------------------------------------------------------------- 문자열 (Java String 규칙)

# Character.isWhitespace — 유니코드 빈칸이지만 줄바꿈 없는 빈칸(NBSP 등)은 아니다
_NON_BREAKING = {" ", " ", " "}
_JAVA_WS_CONTROL = set(" \t\n\x0b\f\r\x1c\x1d\x1e\x1f")


def is_java_whitespace(ch: str) -> bool:
    if ch in _JAVA_WS_CONTROL:
        return True

    if ch in _NON_BREAKING:
        return False

    return unicodedata.category(ch) in ("Zs", "Zl", "Zp")


def jtrim(text: str) -> str:
    """String.trim() — 앞뒤의 '\\u0020' 이하 글자를 뗀다"""
    nStart = 0
    nEnd = len(text)

    while nStart < nEnd and text[nStart] <= " ":
        nStart += 1

    while nEnd > nStart and text[nEnd - 1] <= " ":
        nEnd -= 1

    return text[nStart:nEnd]


def jstrip(text: str) -> str:
    """String.strip() — 앞뒤의 Character.isWhitespace 글자를 뗀다"""
    nStart = 0
    nEnd = len(text)

    while nStart < nEnd and is_java_whitespace(text[nStart]):
        nStart += 1

    while nEnd > nStart and is_java_whitespace(text[nEnd - 1]):
        nEnd -= 1

    return text[nStart:nEnd]


def jblank(text: Optional[str]) -> bool:
    """String.isBlank() — 비었거나 Character.isWhitespace 뿐"""
    return all(is_java_whitespace(ch) for ch in text)


def jsplit(pattern: str, text: str, limit: int = 0) -> list:
    """String.split(regex[, limit]) — limit 0 이면 끝의 빈 글자를 버린다. 맨 앞에서 0 길이로 맞으면 빈 글자를 넣지 않는다"""
    if "" == text:
        return [""]

    oPattern = re.compile(pattern, re.ASCII)
    lstParts = []
    nPos = 0

    for m in oPattern.finditer(text):
        if 0 < limit and len(lstParts) == limit - 1:
            break

        if 0 == m.end() - m.start() and 0 == m.start():
            continue

        if 0 == m.end() - m.start() and m.start() == len(text):
            continue

        lstParts.append(text[nPos:m.start()])
        nPos = m.end()

    lstParts.append(text[nPos:])

    if 0 == limit:
        while lstParts and "" == lstParts[-1]:
            lstParts.pop()

    return lstParts


def split_lines_keep(text: str) -> list:
    """split("\\n", -1) — 끝의 빈 줄도 남긴다"""
    return text.split("\n")


def java_lines(text: str) -> list:
    """String.lines() — \\n · \\r · \\r\\n 으로 나누고 끝의 빈 줄은 하나 버린다"""
    return text.splitlines() if text else []


def jmatches(pattern: str, text: str, flags: int = 0) -> bool:
    """String.matches(regex) — 글자 전체가 맞아야 한다"""
    return None is not re.fullmatch(pattern, text, re.ASCII | flags)


def java_str(value: Any) -> str:
    """Java 의 toString — Map 은 {k=v, …}, List 는 [a, b], boolean 은 true · false"""
    if isinstance(value, bool):
        return "true" if value else "false"

    if isinstance(value, dict):
        return "{" + ", ".join(java_str(k) + "=" + java_str(v) for k, v in value.items()) + "}"

    if isinstance(value, (list, tuple)):
        return "[" + ", ".join(java_str(v) for v in value) + "]"

    if value is None:
        return "null"

    return str(value)


def now_offset() -> str:
    """OffsetDateTime.now().toString() — 시간대가 붙은 ISO 시각"""
    return datetime.now().astimezone().isoformat()


def now_local() -> str:
    """LocalDateTime.now().toString()"""
    return datetime.now().isoformat()


# ---------------------------------------------------------------- 주소 (java.net.URI 규칙)

_SCHEME = re.compile(r"^([A-Za-z][A-Za-z0-9+.\-]*):", re.ASCII)
# URI 에 그대로 쓸 수 없는 글자 — 빈칸 · 제어 문자 · " < > \ ^ ` { | }
_ILLEGAL = re.compile(r'[\x00-\x20\x7f"<>\\^`{|}]')
_BAD_ESCAPE = re.compile(r"%(?![0-9A-Fa-f]{2})")
_IPV4 = re.compile(r"^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$", re.ASCII)
_LABEL = r"[A-Za-z0-9](?:[A-Za-z0-9\-]*[A-Za-z0-9])?"
_HOSTNAME = re.compile(r"^(?:" + _LABEL + r"\.)*" + r"[A-Za-z](?:[A-Za-z0-9\-]*[A-Za-z0-9])?\.?$", re.ASCII)


@dataclass(frozen=True)
class Uri:
    """java.net.URI 에서 쓰는 것만 — scheme · host · port(-1 이면 없음) · rawPath · rawQuery"""

    scheme: Optional[str]
    host: Optional[str]
    port: int
    raw_path: Optional[str]
    raw_query: Optional[str]


def parse_uri(text: str) -> Uri:
    """URI.create(text) — 주소로 읽을 수 없으면 ValueError.

    Java 처럼 빈칸 · 제어 문자 · " < > \\ ^ ` { | } 가 있으면 읽지 못한다. 한글 같은 글자는 된다.
    호스트가 이름 규칙(글자 · 숫자 · - 마디, 마지막 마디는 글자로 시작)에 안 맞으면(밑줄 등) host 는 None 이다.
    """
    if text is None:
        raise ValueError("null")

    if _ILLEGAL.search(text) or _BAD_ESCAPE.search(text):
        raise ValueError("Illegal character in URI: " + text)

    strRest = text
    strFragmentLess = strRest.split("#", 1)[0]
    oScheme = _SCHEME.match(strFragmentLess)
    strScheme = None

    if oScheme:
        strScheme = oScheme.group(1)
        strRest = strFragmentLess[oScheme.end():]
    else:
        strRest = strFragmentLess

    # 스킴이 있는데 / 로 시작하지 않으면 불투명 URI(mailto: · about:blank · localhost:8080) — 호스트 · 경로가 없다
    if strScheme is not None and not strRest.startswith("/"):
        if "" == strRest:
            raise ValueError("Expected scheme-specific part: " + text)

        return Uri(strScheme, None, -1, None, None)

    strQuery = None

    if "?" in strRest:
        strRest, strQuery = strRest.split("?", 1)

    strHost = None
    nPort = -1

    if strRest.startswith("//"):
        strAfter = strRest[2:]
        nSlash = strAfter.find("/")
        strAuthority = strAfter if 0 > nSlash else strAfter[:nSlash]
        strPath = "" if 0 > nSlash else strAfter[nSlash:]
        strHost, nPort = _parse_authority(strAuthority)

        if "" == strAuthority and strScheme is not None and "" == strPath and strQuery is None:
            raise ValueError("Expected authority: " + text)
    else:
        strPath = strRest

    return Uri(strScheme, strHost, nPort, strPath, strQuery)


def _parse_authority(strAuthority: str):
    """서버 방식 authority(사용자@호스트:포트) — 맞지 않으면 (None, -1)"""
    if "" == strAuthority:
        return None, -1

    strHostPort = strAuthority.rsplit("@", 1)[-1]

    if strHostPort.startswith("["):
        nClose = strHostPort.find("]")

        if 0 > nClose:
            raise ValueError("Malformed IPv6 address: " + strAuthority)

        strHost = strHostPort[:nClose + 1]
        strPortPart = strHostPort[nClose + 1:]

        if "" != strPortPart and not strPortPart.startswith(":"):
            return None, -1

        return strHost, _parse_port(strPortPart[1:] if strPortPart else "")

    if ":" in strHostPort:
        strHost, strPort = strHostPort.rsplit(":", 1)
    else:
        strHost, strPort = strHostPort, ""

    if not _is_host(strHost):
        return None, -1

    try:
        return strHost, _parse_port(strPort)
    except ValueError:
        return None, -1


def _parse_port(strPort: str) -> int:
    if "" == strPort:
        return -1

    if not re.fullmatch(r"[0-9]+", strPort, re.ASCII):
        raise ValueError("bad port")

    return int(strPort)


def _is_host(strHost: str) -> bool:
    if "" == strHost:
        return False

    oIpv4 = _IPV4.match(strHost)

    if oIpv4:
        return all(int(g) <= 255 for g in oIpv4.groups())

    return None is not _HOSTNAME.match(strHost)


def get_host(uri: Uri) -> str:
    """SafetyGuard.getHost — host 또는 host:port. 기본 포트는 붙이지 않는다"""
    strHost = "" if uri.host is None else uri.host.lower()

    return strHost if -1 == uri.port else strHost + ":" + str(uri.port)


def iter_nodes(node: Any) -> Iterable:
    return items(node)
