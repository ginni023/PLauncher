// 클릭 후보 수집(명세 §6.1) — 한 frame 안에서 돈다.
// href 가 없는 JS 메뉴도 넣는다. 보이고, 글자가 있고, 눌릴 만한 것만.
(menuSelector) => {
  const root = menuSelector ? document.querySelector(menuSelector) : document.body;
  if (!root) return [];
  const vis = el => el.offsetParent !== null || el.getClientRects().length > 0;
  // 자리는 차지하지만 안 보이는 것(visibility:hidden · opacity:0 — 마우스를 올려야 보이는 메뉴 레이어 등)은 누를 수 없다
  const shown = el => {
    if (getComputedStyle(el).visibility !== 'visible') return false;
    for (let node = el; node && node.nodeType === 1; node = node.parentElement) {
      if (getComputedStyle(node).opacity === '0') return false;
    }
    return true;
  };
  const ROLES = ['menuitem', 'button', 'link', 'tab', 'treeitem'];
  const clickable = el => (el.tagName === 'A' && el.hasAttribute('href'))
      || el.hasAttribute('onclick')
      || ROLES.includes(el.getAttribute('role'))
      || getComputedStyle(el).cursor === 'pointer';
  const tables = [...document.querySelectorAll('table')].filter(vis);
  // 표의 데이터 칸(thead 밖 td) 안이면 데이터 값 — 재현할 때 글자 대신 위치로 찾게 한다.
  // 머리글 행 없이 첫 행부터 데이터인 표도 있어서 행 차례로는 가르지 않는다
  const rowOf = el => {
    const td = el.closest('td'), table = el.closest('table');
    if (!td || !table || el.closest('thead')) return null;
    return tables.indexOf(table);
  };
  const out = [];
  const seen = new Set();
  for (const el of root.querySelectorAll('a, li, span, div, button')) {
    if (!vis(el) || !shown(el) || !clickable(el)) continue;
    const text = (el.innerText || '').trim();
    // 줄바꿈이 있으면 여러 항목을 감싼 덩어리다
    if (!text || text.length > 40 || text.includes('\n') || seen.has(text)) continue;
    seen.add(text);
    const rawHref = el.tagName === 'A' ? (el.getAttribute('href') || '') : '';
    const jsHref = !rawHref || rawHref.startsWith('#') || rawHref.toLowerCase().startsWith('javascript:');
    out.push({ text, tag: el.tagName, href: jsHref ? null : el.href,
               target: el.tagName === 'A' ? el.getAttribute('target') : null, tableIndex: rowOf(el),
               outerHTML: el.outerHTML.slice(0, 300) });
  }
  return out;
}
