// 따라갈 링크 수집 — 한 frame 안에서 돈다. 실제 주소가 있는 a[href] 만.
() => {
  const vis = el => el.offsetParent !== null || el.getClientRects().length > 0;
  // 자리는 차지하지만 안 보이는 링크(visibility:hidden · opacity:0 — 마우스를 올려야 보이는 메뉴 레이어 안) — 눌러서는 못 간다
  const shown = el => {
    if (getComputedStyle(el).visibility !== 'visible') return false;
    for (let node = el; node && node.nodeType === 1; node = node.parentElement) {
      if (getComputedStyle(node).opacity === '0') return false;
    }
    return true;
  };
  const tables = [...document.querySelectorAll('table')].filter(vis);
  // 표의 데이터 칸(thead 밖 td) 안이면 데이터 값 — 재현할 때 글자 대신 위치로 찾게 한다.
  // 머리글 행 없이 첫 행부터 데이터인 표도 있어서 행 차례로는 가르지 않는다
  const rowOf = el => {
    const td = el.closest('td'), table = el.closest('table');
    if (!td || !table || el.closest('thead')) return null;
    return tables.indexOf(table);
  };
  return [...document.querySelectorAll('a[href]')]
    .filter(a => {
      const raw = (a.getAttribute('href') || '').trim().toLowerCase();
      return vis(a) && raw && !raw.startsWith('#') && !raw.startsWith('javascript:') && !raw.startsWith('mailto:');
    })
    .map(a => ({ href: a.href, text: (a.innerText || (a.textContent || '').replace(/\s+/g, ' ') || a.title || '').trim().slice(0, 50), tableIndex: rowOf(a),
                 target: a.getAttribute('target'), hidden: !shown(a) }));
}
