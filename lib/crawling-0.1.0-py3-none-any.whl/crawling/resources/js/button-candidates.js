// 화면 안의 버튼 · 탭 후보(명세 §6.4, clickButtons=true 일 때) — 한 frame 안에서 돈다.
// 머리 · 메뉴 · 바닥(header · nav · footer)은 메뉴 탐색이, 주소가 있는 링크는 링크 탐색이 맡으므로 뺀다.
// 같은 글자의 버튼은 한 번만(상품마다 있는 "장바구니 담기" 등). 누를 때 쓸, 페이지 안에서 하나만 가리키는 selector 를 붙인다.
() => {
  const vis = el => el.offsetParent !== null || el.getClientRects().length > 0;
  // 자리는 차지하지만 안 보이는 것(visibility:hidden · opacity:0 — 마우스를 올려야 보이는 메뉴 레이어 등)은 누를 수 없다
  const shown = el => {
    if (getComputedStyle(el).visibility !== 'visible') return false;
    for (let node = el; node && node.nodeType === 1; node = node.parentElement) {
      if (getComputedStyle(node).opacity === '0') return false;
    }
    return true;
  };
  const LAYOUT = 'header, nav, footer, [role=banner], [role=navigation], [role=contentinfo], [aria-hidden=true]';
  const unique = sel => { try { return document.querySelectorAll(sel).length === 1; } catch (e) { return false; } };
  const quote = v => '"' + v.replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '"';
  const own = el => {
    if (el.id && unique('#' + CSS.escape(el.id))) return '#' + CSS.escape(el.id);
    for (const a of ['data-testid', 'data-test', 'data-qa', 'name']) {
      const v = el.getAttribute(a);
      if (v) { const s = el.tagName.toLowerCase() + '[' + a + '=' + quote(v) + ']'; if (unique(s)) return s; }
    }
    return null;
  };
  const selectorOf = el => {
    const parts = [];
    for (let cur = el; cur && cur.nodeType === 1 && cur !== document.documentElement; cur = cur.parentElement) {
      const mine = own(cur);
      if (mine) { parts.unshift(mine); break; }
      let p = cur.tagName.toLowerCase();
      const same = cur.parentElement ? [...cur.parentElement.children].filter(c => c.tagName === cur.tagName) : [];
      if (1 < same.length) p += ':nth-of-type(' + (same.indexOf(cur) + 1) + ')';
      parts.unshift(p);
    }
    const s = parts.join(' > ');
    return unique(s) ? s : null;
  };
  const textOf = el => (el.tagName === 'INPUT' ? (el.value || el.getAttribute('aria-label') || '')
      : (el.innerText || el.getAttribute('aria-label') || el.title || '')).trim();
  const disabled = el => el.disabled || el.getAttribute('aria-disabled') === 'true' || el.classList.contains('disabled');
  const out = [];
  const seen = new Set();
  const SEL = 'button, input[type=submit], input[type=button], [role=button], [role=tab], a[href="#"], a[href^="javascript:"], a:not([href])[onclick], [onclick]';
  for (const el of document.querySelectorAll(SEL)) {
    if (!vis(el) || !shown(el) || el.closest(LAYOUT) || disabled(el)) continue;
    const text = textOf(el);
    if (!text || text.length > 40 || text.includes('\n') || seen.has(text)) continue;
    seen.add(text);
    out.push({ text, tag: el.tagName, role: el.getAttribute('role'), selector: selectorOf(el), outerHTML: el.outerHTML.slice(0, 300) });
  }
  return out;
}
