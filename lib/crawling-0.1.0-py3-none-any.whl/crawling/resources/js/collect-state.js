// 화면 구조 추출(명세 §7) — 한 frame 안에서 돈다.
// 입력값(value)과 표의 데이터 행은 남기지 않는다(개인정보 방지). value 는 버튼 글자로만 쓴다.
() => {
  const vis = el => el.offsetParent !== null || el.getClientRects().length > 0;
  const BUTTON_TYPES = ['button', 'submit', 'reset', 'image'];
  const isButtonLike = el => el.tagName === 'BUTTON'
      || (el.tagName === 'INPUT' && BUTTON_TYPES.includes((el.type || '').toLowerCase()));
  const isField = el => ['INPUT', 'TEXTAREA', 'SELECT'].includes(el.tagName);
  const CONTROL = 'input, select, textarea, button';
  const squash = s => (s || '').replace(/\s+/g, ' ').trim();
  // 입력칸 이름 — 오래된 화면은 <label for> 없이 글자 옆에 칸을 둔다. 찾는 차례:
  // label[for] → 감싼 <label> → aria-labelledby · aria-label → 같은 줄 앞쪽의 <label> → 표 배치의 앞 칸 → 바로 앞 글자
  // (칸 뒤의 단위 글자 "초" 같은 것은 앞 칸의 것이라 쓰지 않는다)
  const fieldLabel = el => {
    if (el.id) {
      const l = document.querySelector(`label[for="${CSS.escape(el.id)}"]`);
      if (l) return squash(l.innerText);
    }
    const wrap = el.closest('label');
    if (wrap) {
      const t = squash([...wrap.childNodes].filter(n => !(n.nodeType === 1 && n.matches(CONTROL)))
          .map(n => n.textContent).join(' '));
      if (t) return t;
    }
    const by = el.getAttribute('aria-labelledby');
    if (by) {
      const t = squash(by.split(/\s+/).map(id => document.getElementById(id)?.innerText || '').join(' '));
      if (t) return t;
    }
    if (el.getAttribute('aria-label')) return squash(el.getAttribute('aria-label'));
    // for 가 다른 칸을 가리키는 라벨은 그 칸의 것이다 — for 없는 라벨만 한 줄의 칸들이 함께 쓴다
    for (let p = el.previousElementSibling; p; p = p.previousElementSibling) {
      if (p.tagName === 'LABEL' && !p.htmlFor && squash(p.innerText)) return squash(p.innerText);
    }
    const cell = el.closest('td');
    const prevCell = cell && cell.previousElementSibling;
    if (prevCell && !prevCell.querySelector(CONTROL) && squash(prevCell.innerText)) return squash(prevCell.innerText);
    for (let p = el.previousSibling; p; p = p.previousSibling) {
      if (p.nodeType === 1 && (p.matches(CONTROL) || p.querySelector(CONTROL))) break;
      const t = squash(p.nodeType === 3 ? p.textContent : p.innerText);
      if (t) return t;
    }
    return squash(el.placeholder || el.title);
  };
  // visibility:hidden 인 요소(마우스를 올려야 보이는 메뉴 레이어 안 링크 등)는 innerText 가 비므로 textContent 로 읽는다
  const textOf = el => (getComputedStyle(el).visibility === 'visible' ? el.innerText : el.textContent);
  const label = el => (isField(el) ? fieldLabel(el)
      : squash(textOf(el) || (isButtonLike(el) ? el.value : '') || el.title || el.getAttribute('aria-label'))).slice(0, 50);
  // 페이지 안에서 하나만 가리키는 CSS selector — #id → [name] → id · data-* 가 있는 가장 가까운 조상에서 내려오는 짧은 경로
  const unique = sel => { try { return document.querySelectorAll(sel).length === 1; } catch (e) { return false; } };
  const quote = v => '"' + String(v).replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '"';
  const segment = node => {
    if (node.id && unique('#' + CSS.escape(node.id))) return '#' + CSS.escape(node.id);
    const tag = node.tagName.toLowerCase();
    const data = [...node.attributes].find(a => a.name.startsWith('data-') && a.value && a.value.length <= 40);
    if (data) return `${tag}[${data.name}=${quote(data.value)}]`;
    const same = node.parentElement ? [...node.parentElement.children].filter(c => c.tagName === node.tagName) : [node];
    return same.length > 1 ? `${tag}:nth-of-type(${same.indexOf(node) + 1})` : tag;
  };
  const selectorOf = el => {
    if (el.id && unique('#' + CSS.escape(el.id))) return '#' + CSS.escape(el.id);
    const name = el.getAttribute('name');
    if (name && unique(`${el.tagName.toLowerCase()}[name=${quote(name)}]`)) return `${el.tagName.toLowerCase()}[name=${quote(name)}]`;
    const parts = [];
    for (let node = el, i = 0; node && node.nodeType === 1 && node !== document.body && i < 6; node = node.parentElement, i++) {
      parts.unshift(segment(node));
      const sel = parts.join(' > ');
      if (unique(sel)) return sel;
    }
    return null;
  };
  // tbody 의 두 번째 행부터는 데이터로 보고 버린다(데이터 건수 차이 무시).
  // 단 입력칸이 든 표는 입력 양식(오래된 화면의 표 배치 폼: <th>고객명</th><td><input></td>)이다 — 버리지 않는다
  const isFormTable = table => !!table && [...table.querySelectorAll('input, select, textarea')]
      .some(c => (c.type || '').toLowerCase() !== 'hidden');
  const inDataRow = el => {
    const tr = el.closest('tbody > tr');
    return !!tr && tr.parentElement.querySelector(':scope > tr') !== tr && !isFormTable(tr.closest('table'));
  };
  // 반복 목록(상품 카드 · 장바구니 줄 · 주문 카드)의 둘째 항목부터 — 구조 해시에서 뺀다(항목 수 차이 무시, 요소 목록에는 남긴다).
  // 같은 부모 · 같은 태그 · 같은 class 의 형제이고, 안의 입력 · 버튼 구성(태그 · type · role · 숫자를 지운 name)이 첫 항목과 같을 때만.
  // 칸 이름이 서로 다른 입력 양식 줄(div.field 여럿)은 접히지 않는다
  const PARTS = 'input, select, textarea, button, a[href], [onclick], [role=button], [role=tab], [role=menuitem]';
  const sigs = new Map();
  const sig = node => {
    if (!sigs.has(node)) {
      sigs.set(node, [...node.querySelectorAll(PARTS)].filter(e => (e.type || '').toLowerCase() !== 'hidden')
          .map(e => [e.tagName, typeof e.type === 'string' ? e.type : '', e.getAttribute('role') || '',
                     (e.getAttribute('name') || '').replace(/\d+/g, '#')].join(':')).join('|'));
    }
    return sigs.get(node);
  };
  const isRepeat = el => {
    for (let node = el; node && node.parentElement && node !== document.body; node = node.parentElement) {
      const s = sig(node);
      if (!s) continue;
      const first = [...node.parentElement.children].find(c => c.tagName === node.tagName && c.className === node.className);
      if (first && first !== node && sig(first) === s) return true;
    }
    return false;
  };
  return {
    title: document.title,
    heading: (document.querySelector('h1,h2,h3,.title,.page-title')?.innerText || '').trim().slice(0, 100),
    forms: [...document.forms].map(f => ({ id: f.id || null, name: f.getAttribute('name'),
             action: f.getAttribute('action'), method: f.method })),
    elements: [...document.querySelectorAll(
        'input, select, textarea, button, a[href], [onclick], [role=button], [role=tab], [role=menuitem]')]
      .filter(el => vis(el) && !inDataRow(el) && (el.type || '').toLowerCase() !== 'hidden')
      .map(el => ({ tag: el.tagName, id: el.id || null, name: el.getAttribute('name'),
                    type: typeof el.type === 'string' ? el.type : null, role: el.getAttribute('role'),
                    cls: el.getAttribute('class'), label: label(el),
                    // div · li · span 처럼 역할이 없는 요소가 눌리는지 — 오래된 JSP 화면의 메뉴 · 버튼
                    onclick: el.hasAttribute('onclick'),
                    // 이 요소 하나만 가리키는 selector(페이지 안에서 하나인지 확인했다) — 없으면 null
                    selector: selectorOf(el),
                    // 반복 목록의 둘째 항목부터 — 구조 해시에 넣지 않는다
                    rep: isRepeat(el) })),
    // th 가 없는 표는 첫 행의 칸 글자를 머리글로 본다.
    // 단 첫 행에 링크 · 버튼 · 입력칸이 있으면 머리글 없이 첫 행부터 데이터인 표다 — 머리글로 보지 않는다
    gridHeaders: [...document.querySelectorAll('table')].filter(vis).flatMap(t => {
      const th = [...t.querySelectorAll('th')].filter(vis);
      const first = t.rows.length > 1 ? t.rows[0] : null;
      const plain = first && !first.querySelector('a, button, input, select, textarea');
      const cells = th.length ? th : (plain ? [...first.cells] : []);
      return cells.map(c => c.innerText.trim()).filter(s => s);
    }),
    iframes: [...document.querySelectorAll('iframe, frame')].map(f => ({ id: f.id || null, name: f.name || null,
               src: f.getAttribute('src') })),
    hasPassword: [...document.querySelectorAll('input[type=password]')].some(vis)
  };
}
