너는 업무 테스트를 쓰는 테스트 엔지니어다.
아래 "업무"를 **Playwright Test(TypeScript)** 테스트 파일 하나로 써라. 이 파일은 **초안**이다 — 테스트 사이트에서 한 번 시험 실행해
기록을 남기고, 그 기록으로 다음 단계에서 단언을 완성한다. 그래서 모르는 것은 지어내지 말고 기록으로 남기게 쓴다.

## 입력 읽는 법

- `업무` — 사용자가 업무 용어로 쓴 것. `steps` 차례, `data.rows`(경우마다 값 · 기대), `expected`, `cleanup`, `allowedActions`, `notes`.
- `연결안` — 사람이 확인한 연결. 업무 단계마다 `screen`(화면 id) · `button` · `group`, 데이터 열마다 `field`(입력칸). `unknown` 은 아직 모르는 것.
  입력칸 · 버튼에 **`selector` 가 있으면 크롤러가 그 칸 이름과 HTML 요소를 이어 확정한 것이다 — 그대로 `page.locator(selector)` 로 쓴다.**
  `selector` 가 `null` 일 때만 아래 `elements` 에서 찾는다.
- `화면` — 연결안이 가리키는 화면들의 상세(크롤러가 모은 것).
  - `reach` — 그 화면에 닿는 단계. `goto` 는 주소로 연다. `click` 은 `frame`(빈 글자면 맨 위 페이지) 안에서 `role` · `text` 로 누른다. `hover` 는 같은 방법으로 찾아 마우스만 올린다(하위 메뉴가 펼쳐지는 메뉴 — `hover()` 뒤 다음 단계를 누른다).
    `dataRow: true` 면 표 데이터 행의 링크라 글자 대신 `tableIndex` 번째 표의 첫 링크로 누른다. `opensIn` 이 있으면 그 frame 안에 화면이 뜬다.
  - `aria` — 본문 aria 스냅샷(입력칸 값 · 표 데이터 행은 지워져 있다). `layout` 은 모든 화면 공통인 머리 · 메뉴.
  - `elements` — 본문 요소 차례대로. `selector`(`#id`, `input[name="q"]`)가 있으면 그것으로 잡는다.
    같은 글자의 버튼이 여러 벌이면 **연결안의 입력칸 바로 뒤에 오는 버튼의 selector** 를 쓴다(예: `#page-size` 뒤의 `#save-page-size`).

## 쓰는 법

1. `import { test, expect } from '../fixtures';` — `@playwright/test` 에서 가져오지 않는다. fixtures 가 주는 것:
   - `record(이름)` — 그 순간의 화면(aria · URL · 스크린샷 · 그사이 뜬 대화상자)을 시험 실행 기록에 남긴다.
   - `dialogs()` — 지금까지 뜬 대화상자 글(`"alert: ..."`). 대화상자는 fixtures 가 받아 준다 — **스크립트에서 dialog 를 직접 다루지 않는다.**
2. `data.rows` 한 줄에 `test` 하나 — `for (const row of ROWS) test(\`${이름} — ${row.case}\`, async ({ page, record, dialogs }) => { ... })`.
3. 업무 `steps` 마다 그 일을 하고 바로 `await record('단계 N — 업무 단계 글')` 을 부른다. 화면에 들어간 직후 · 버튼을 누른 직후에도 부른다.
4. 화면에는 `reach` 를 따라 들어간다(메뉴 · 링크를 눌러서). 사이트 주소는 `const BASE = process.env.TARGET_URL ?? '사이트 주소';`.
5. 값을 넣는 칸 · 누르는 버튼은 연결안의 `selector` 로 잡는다(없으면 `field` → `elements` 의 selector). 숫자 칸은 `fill(String(값))`.
   자리표시 `{{now}}`(yyyyMMddHHmmss) · `{{today}}`(yyyy-MM-dd) · `{{rand:N}}` 은 실행할 때 값으로 바꾸는 도우미를 써서 넣는다.
6. **바꾸기 전에 원래 값을 읽어 두고**(화면이 값을 서버에서 받아 오는 중일 수 있다 — 빈 값이 아닐 때까지 기다린 뒤 읽는다.
   빈 값으로 되돌리면 설정이 망가진다), `cleanup` 은 `try { ... } finally { ... }` 의 `finally` 에서 한다 — 테스트가 실패해도 되돌린다. 정리 뒤에도 `record`.
7. 단언(expect)은 **확실한 것만** — 업무의 `expect` · `expected` 가운데 입력에 근거가 있는 것(URL, 값이 남아 있는가, 표의 데이터 행 수 등).
   결과 문구 · 확인 창처럼 연결안 `unknown` 에 있는 것은 단언하지 말고 `record` 로 남기고, 그 자리에 `// ⑥: 무엇을 확인할지` 주석을 단다.
   표의 데이터 행 수는 머리글 행을 빼고 센다.
8. **누르지 않는다**: `allowedActions` 에 없는 위험 버튼, 연결안에 없는 버튼. `notes` 가 건드리지 말라는 것.
9. 테스트 사이 3000ms 쉰다 — `test.afterEach(async ({ page }) => { await page.waitForTimeout(3000); });`. `mode: 'serial'` 은 쓰지 않는다.
10. 입력에 없는 요소 · 문구를 지어내지 않는다.

## 출력

```ts 코드 블록 하나만 낸다. 설명은 쓰지 않는다.

## 업무

```json
{{SCENARIO}}
```

## 연결안

```json
{{MAPPING}}
```

## 화면

```json
{{SCREENS}}
```
