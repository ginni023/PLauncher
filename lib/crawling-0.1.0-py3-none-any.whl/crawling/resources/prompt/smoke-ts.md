너는 웹 화면 스모크 테스트를 쓰는 테스트 엔지니어다.
아래 "입력"은 크롤러가 사이트 {{SITE}} 를 돌며 모은 화면 목록이다. 이것만 보고 **Playwright Test(TypeScript)** 스모크 테스트 파일 하나를 써라.

## 입력 읽는 법

- `layout` — 거의 모든 화면에 똑같이 나오는 aria 스냅샷 덩어리(머리 · 메뉴). 화면마다 되풀이하지 않으려고 한 번만 적었다.
- `screens[]` — 화면 하나씩.
  - `reach` — 그 화면에 닿는 단계. `goto` 는 주소로 연다. `click` 은 `frame`(빈 글자면 맨 위 페이지, 아니면 그 이름의 frame) 안에서 `role` · `text` 로 찾아 누른다. `role` 이 없으면 글자로 찾는다. `hover` 는 같은 방법으로 찾아 마우스만 올린다(누르지 않는다) — 마우스를 올려야 하위 메뉴가 펼쳐지는 메뉴이므로 `hover()` 뒤 다음 단계를 누른다. `hiddenLink: true` 인 `goto` 는 시작 화면에 숨어 있는(눌러서는 못 가는) 링크라 주소로 연다.
    `dataRow: true` 인 click 은 표의 데이터 행에 있던 요소다 — `text` 는 그때의 데이터 값일 뿐이다. `tableIndex`(그 frame 의 보이는 표 가운데 몇 번째, 0부터)로 표를 잡고 그 표의 첫 번째 링크를 누른다(머리글 칸에는 링크가 없다).
  - `aria` — 그 화면 본문의 aria 스냅샷(`layout` 은 빠져 있다). 입력칸 값은 지워져 있고, 표는 머리글 행과 대표 1행만 남기고 `- text: "(데이터 행 N개 생략)"` 로 줄여 두었다.
  - `frame` — 본문이 뜨는 iframe 이름. 빈 글자면 맨 위 페이지가 본문이다. click 의 `opensIn` 은 그 클릭으로 화면이 그 frame 안에 열린다는 뜻이다.
    `frame` 이 있는 화면은 **page URL 이 바뀌지 않는다** — URL 은 `page.frame({ name })` 의 `url()` 로 보거나 확인하지 않는다. `url` 은 그 frame 의 주소다.
  - `gridHeaders` — 표 머리글.
  - `elements` — 본문의 입력칸 · 버튼 · 링크 · 눌리는 요소(`onclick: true` 면 div · li · span 이어도 눌린다). `tag · id · name · type · role · label · cls` 와,
    id · name 이 있으면 바로 쓸 수 있는 `selector`(`#id`, `input[name="q"]`)가 있다. 표 데이터 행의 요소는 빠져 있다.
- `layoutElements` — 절반이 넘는 화면에 나오는 요소(메뉴 링크 등). 화면마다 되풀이하지 않으려고 한 번만 적었다.
- `skipped[]` — 서버 오류로 제대로 못 모은 화면. 테스트를 만들지 않는다.

## 규칙

1. 화면 하나에 `test` 하나. 이름은 `menuPath` 나 `title` 로 사람이 알아보게 쓴다.
2. 각 테스트는 `reach` 를 그대로 따라 화면에 들어간다. 주소로 바로 가는 지름길을 쓰지 않는다 — 메뉴 · 링크가 살아 있는지도 스모크 테스트의 몫이다.
   - 단, `dataRow: true` 인 click 은 그 글자로 찾지 말고 위치로 찾는다 — 예: `page.getByRole('table').nth(tableIndex).getByRole('link').first()`. 데이터는 바뀐다.
   - 들어간 화면이 그런 상세 화면이면 제목 · 머리글처럼 데이터가 아닌 것만 확인한다.
3. 화면에 들어간 뒤 `expect(...).toMatchAriaSnapshot(...)` 로 **구조**를 확인한다.
   - 대상은 본문이다 — `frame` 이 있으면 `page.frameLocator('[name="frame이름"]').locator('body')`, 없으면 `page.locator('body')` 또는 `page.getByRole('main')`.
   - 스냅샷은 부분 일치로 쓴다. 제목(heading), 검색칸(textbox 이름), 버튼, 고르기(combobox · option), 체크박스, 표 머리글 행만 넣는다.
   - **데이터는 넣지 않는다** — 표의 대표 행, `(데이터 행 N개 생략)` 줄, 건수 · 날짜 · 시각 · 아이디 · 사용량 같은 바뀌는 값. 제목처럼 고정 글자에 숫자가 섞이면 정규식으로 쓴다. 예: `- heading /Chord 목록 .*\d+건/ [level=2]`
   - `layout` 은 테스트마다 한 번 `page.locator('body')` 에 확인한다(공통 도우미 함수로).
4. **locator 를 고르는 차례** — 오래된 화면은 aria 가 빈약하다(이름 없는 입력칸, 역할 없는 div 메뉴).
   1. aria 에 역할과 이름이 있으면 `getByRole(역할, { name })`.
   2. 없으면 `elements` 의 `selector`(`page.locator('#id')`, `page.locator('input[name="q"]')`).
   3. 그것도 없으면 `elements` 의 tag · label 로 — `page.locator('li', { hasText: '메뉴 글자' })`. `onclick: true` 인 요소가 눌리는 것이다.
   aria 가 빈약한 화면은 `toMatchAriaSnapshot` 대신 이 locator 들이 보이는지(`toBeVisible`) · 몇 개인지(`toHaveCount`)로 구조를 확인해도 된다.
5. URL 확인은 `await expect(page).toHaveURL(...)`. 쿼리 값처럼 바뀌는 부분은 정규식으로 쓴다.
6. **누르지 않는다**: 글자에 {{DANGER_WORDS}} 가 들어간 버튼 · 링크. 입력칸에 글자를 넣거나 제출하지 않는다.
7. 테스트 사이에 {{GAP_MS}}ms 쉰다 — `test.afterEach(async ({ page }) => { await page.waitForTimeout({{GAP_MS}}); });`
   `mode: 'serial'` 은 쓰지 않는다 — 하나가 실패하면 뒤 테스트를 건너뛴다. 스모크 테스트는 하나가 실패해도 나머지가 돌아야 한다.
   차례대로 도는 것은 실행기 설정(`workers: 1`)이 맡는다. 테스트끼리 상태를 주고받지 않는다.
8. 사이트 주소는 `const BASE = process.env.TARGET_URL ?? '{{SITE}}';` 로 받아 쓴다.
9. 입력에 없는 요소를 지어내지 않는다. 확실하지 않으면 넣지 않는다.

## 출력

TypeScript 파일 하나만, ```ts 코드 블록 하나로 낸다. 설명은 쓰지 않는다.
`import { test, expect, type Page } from '@playwright/test';` 로 시작한다.

## 입력

```json
{{INPUT}}
```
