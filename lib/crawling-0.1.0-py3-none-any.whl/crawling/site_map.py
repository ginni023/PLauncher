"""site-map.json — 업무와 화면을 잇는 데 쓰는 작은 화면 목록 — Java 판 SiteMap.

업무 테스트를 만들 때 1차 LLM 에 사용자의 업무 설명과 함께 통째로 넘겨 "이 업무가 거치는 화면 · 입력칸"을 고르게 한다.
그래서 화면마다 업무 용어와 맞춰 볼 거리(메뉴 경로 · 제목 · 버튼 · 입력칸 이름 · 표 머리글)만 짧게 담는다.

::

    { "site", "generatedAt", "screens": [ {
        "id", "menuPath": [...], "url", "how": "메인 › 설정", "structure", "serverError",
        "headings": [...], "buttons": [...], "links": [...],
        "fields": [ { "label", "section", "group", "kind", "selector", "anchor", "options": [...], "buttons": [ { "text", "selector", "anchor" } ] } ],
        "tables": [...], "screenshot": "screenshots/s0002.png" } ] }

- 제목 · 버튼 · 링크 글자에서 데이터(시각 · 날짜 · 건수 · 사용량 등 숫자가 든 낱말)를 지운다 — "Chord 목록 2026-10 기준 14건" → "Chord 목록 기준".
  입력칸 이름은 그대로 둔다("주소 2" 같은 이름이 있다).
- 입력칸 이름은 aria 이름, 없으면 바로 앞의 글자(오래된 화면은 라벨 없이 글자 옆에 칸이 있다).
- selector — 칸(aria)과 요소(elements)를 같은 이름 · 맞는 종류 · 차례로 이어 붙여, 그 칸 하나만 가리키는 selector 를 단다.
  칸 바로 뒤의 버튼도 selector 와 함께. 사용자 말 → 칸 이름은 LLM 과 사람이, 칸 이름 → HTML 요소는 크롤러가 확정한다.
- section 은 가장 가까운 소제목. group 은 버튼이 딸린 가장 가까운 앞 입력칸으로, 같은 소제목 아래 같은 이름의 칸이
  여러 벌일 때만 적는다("데이터소스 › 지켜보는 대상 · 실행 기록 › Host").
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field as dc_field
from typing import Any, Dict, List, Optional

from ._jutil import (as_bool, as_int, as_text, has_non_null, is_array, is_empty, items, jget, jsplit, jtrim, now_offset,
                     write_json)
from .repository import StateRepository
from .smoke_input import get_body_aria

# aria 한 줄 — 들여쓰기, 역할, "이름", 나머지
_LINE = re.compile(r'^(\s*)- \'?([a-z]+)(?: "((?:[^"\\]|\\.)*)")?(.*)$', re.ASCII)
_TEXT = re.compile(r'^\s*- text: "?(.*?)"?$', re.ASCII)
_INPUTS = {"textbox", "searchbox", "spinbutton", "combobox", "checkbox", "radio", "slider"}
_MAX_OPTIONS = 12
_BUTTON_TYPES = {"button", "submit", "reset", "image"}


@dataclass
class Field:
    """입력칸 하나. buttons — 칸 바로 뒤에 딸린 버튼(같은 글자의 버튼이 여러 벌일 때 어느 칸의 것인지 가른다)"""

    label: str
    section: str
    group: str
    kind: str
    options: List[str]
    buttons: List[str] = dc_field(default_factory=list)


@dataclass(frozen=True)
class Parsed:
    """aria 에서 뽑은 것"""

    headings: List[str]
    buttons: List[str]
    links: List[str]
    fields: List[Field]


@dataclass(frozen=True)
class Joined:
    """칸 하나에 이어 붙인 요소 — selector 와 칸 바로 뒤 버튼들({text, selector}).
    label 은 요소 쪽 이름으로 바로잡은 칸 이름 — 이름으로 못 찾고 차례로 이었을 때만, 아니면 None"""

    selector: Optional[str]
    buttons: List[Dict[str, str]]
    label: Optional[str]


def build(site: str, repository: StateRepository, this_run: Dict[str, dict]) -> dict:
    root: dict = {"site": site, "generatedAt": now_offset()}
    screens: List[dict] = []
    root["screens"] = screens

    for s in repository.get_summaries():
        state = this_run[s.state_id] if s.state_id in this_run else repository.load(s.state_id)

        if state is None:
            continue

        parsed = parse(get_body_aria(state))
        lstFields = parsed.fields
        joined = join(lstFields, jget(state, "elements"))
        screen: dict = {
            "id": s.state_id,
            "menuPath": list(s.menu_paths),
            "url": s.normalized_url,
            "how": get_how(jget(state, "reach")),
            "structure": s.structure,
        }

        # 같은 구조의 다른 주소 · 입구(mergeSameStructure) — 같은 틀이므로 이 화면의 칸 · 버튼이 그대로 쓰인다
        oVariants = jget(state, "variants")

        if is_array(oVariants) and not is_empty(oVariants):
            screen["variants"] = [{"url": as_text(jget(v, "normalizedUrl")), "how": get_how(jget(v, "reach"))} for v in oVariants]

        if s.server_error:
            screen["serverError"] = True

        screen["headings"] = list(parsed.headings)
        screen["buttons"] = list(parsed.buttons)
        screen["links"] = list(parsed.links)

        fields: List[dict] = []
        screen["fields"] = fields
        # group 은 같은 이름의 칸이 여러 벌일 때만 — 줄마다 저장 버튼이 붙은 화면에서는 엉뚱하게 엮이므로
        labelCount: Dict[str, int] = {}

        for oField in lstFields:
            strCountKey = oField.section + "\u0001" + oField.label
            labelCount[strCountKey] = labelCount.get(strCountKey, 0) + 1

        for f, j in zip(lstFields, joined):
            n: dict = {"label": f.label if j.label is None else j.label}

            if "" != f.section:
                n["section"] = f.section

            if 1 < labelCount[f.section + "\u0001" + f.label] and "" != f.group and f.group != f.label:
                n["group"] = f.group

            n["kind"] = f.kind

            if j.selector is not None:
                n["selector"] = j.selector

            n["anchor"] = get_anchor(j.selector)

            if f.options:
                n["options"] = list(f.options)

            if j.buttons:
                bs = []

                for b in j.buttons:
                    bn = dict(b)
                    bn["anchor"] = get_anchor(b.get("selector"))
                    bs.append(bn)

                n["buttons"] = bs

            fields.append(n)

        # 글자가 없는 버튼 · 눌리는 요소(아이콘 버튼 등) — 무엇을 하는지 알 수 없어 업무와 이을 수 없다
        unnamed: List[dict] = []
        screen["unnamed"] = unnamed

        for el in items(jget(state, "elements")):
            strTag = as_text(jget(el, "tag"))

            if ((_is_button_element(el) or as_bool(jget(el, "onclick")) or "A" == strTag)
                    and "" == squash(as_text(jget(el, "label"), ""))):
                strSelector = as_text(jget(el, "selector"), None)
                unnamed.append({"tag": strTag, "selector": strSelector, "anchor": get_anchor(strSelector)})

        screen["tables"] = [as_text(h) for h in items(jget(state, "gridHeaders"))]
        screen["screenshot"] = "screenshots/" + s.state_id + ".png"
        screens.append(screen)

    root["screenCount"] = len(screens)

    return root


def write(path, map_node: dict) -> None:
    write_json(path, map_node)


def join(fields: List[Field], elements: Any) -> List[Joined]:
    """aria 에서 뽑은 칸과 elements(DOM 차례)를 잇는다 — 이름이 같고 종류가 맞는 요소를 차례로 찾는다.
    이름으로 못 찾으면 바로 다음의 같은 종류 요소로 잇고, 칸 이름은 요소 쪽 이름으로 바로잡는다.
    그래도 없으면 selector 없이(버튼은 글자만) 둔다. 같은 이름의 칸(Host 두 벌)은 차례로 하나씩 가져간다."""
    els = items(elements)
    out: List[Joined] = []
    nFrom = 0

    for f in fields:
        nAt = -1

        for k in range(nFrom, len(els)):
            oCandidate = els[k]

            if is_compatible(f.kind, oCandidate) and f.label == squash(as_text(jget(oCandidate, "label"), "")):
                nAt = k
                break

        strLabel = None

        if 0 > nAt:
            # 이름이 안 맞으면 바로 다음 칸 요소가 같은 종류일 때만 차례로 잇는다
            for k in range(nFrom, len(els)):
                if _is_field_element(els[k]):
                    if is_compatible(f.kind, els[k]):
                        nAt = k
                        # 요소 쪽에 이름이 있으면 그것으로 바로잡는다 — 둘 다 없으면 aria 쪽 이름 그대로
                        strElementLabel = squash(as_text(jget(els[k], "label"), ""))
                        strLabel = None if "" == strElementLabel else strElementLabel

                    break

        if 0 > nAt:
            out.append(Joined(None, [{"text": b} for b in f.buttons], None))
            continue

        buttons: List[Dict[str, str]] = []

        # 칸 바로 뒤, 다음 칸이 나오기 전까지의 버튼
        k = nAt + 1

        while k < len(els) and not _is_field_element(els[k]):
            b = els[k]

            if _is_button_element(b):
                strButtonText = clean_or_raw(as_text(jget(b, "label"), ""))

                if strButtonText in f.buttons:
                    m = {"text": clean_or_raw(as_text(jget(b, "label"), ""))}

                    if has_non_null(b, "selector"):
                        m["selector"] = as_text(b["selector"])

                    buttons.append(m)

            k += 1

        oAtElement = els[nAt]
        strSelector = as_text(oAtElement["selector"]) if has_non_null(oAtElement, "selector") else None

        out.append(Joined(strSelector, buttons, strLabel))
        nFrom = nAt + 1

    return out


def _is_field_element(el: Any) -> bool:
    strTag = as_text(jget(el, "tag"))

    return "SELECT" == strTag or "TEXTAREA" == strTag or ("INPUT" == strTag and not _is_button_element(el))


def _is_button_element(el: Any) -> bool:
    strTag = as_text(jget(el, "tag"))
    strType = as_text(jget(el, "type"), "").lower()
    strRole = as_text(jget(el, "role"), "")

    return "BUTTON" == strTag or ("INPUT" == strTag and strType in _BUTTON_TYPES) or "button" == strRole


def is_compatible(kind: str, el: Any) -> bool:
    """aria 의 칸 종류와 HTML 요소가 맞는가"""
    strTag = as_text(jget(el, "tag"))
    strType = as_text(jget(el, "type"), "").lower()

    if "combobox" == kind:
        return "SELECT" == strTag or ("INPUT" == strTag and strType in ("text", "search", ""))

    if "spinbutton" == kind:
        return "INPUT" == strTag and "number" == strType

    if "checkbox" == kind:
        return "INPUT" == strTag and "checkbox" == strType

    if "radio" == kind:
        return "INPUT" == strTag and "radio" == strType

    if "slider" == kind:
        return "INPUT" == strTag and "range" == strType

    return "TEXTAREA" == strTag or ("INPUT" == strTag and strType in (
        "text", "password", "email", "search", "tel", "url", "", "date", "datetime-local", "month", "week", "time"))


def get_anchor(selector: Optional[str]) -> str:
    """테스트 단서의 세기 — selector 의 마지막 마디가 무엇에 기대는가.

    - attribute — #id · [name] · [data-*] 로 잡힌다. 배치가 바뀌어도 버틴다
    - position — 마지막이 nth-of-type 같은 차례 · 태그뿐. 배치가 바뀌면 깨지기 쉽다
    - none — selector 가 없다. 테스트로 잡을 단서가 없다 — 개발 쪽에 data-testid 를 요청할 칸
    """
    from ._jutil import jblank

    if selector is None or jblank(selector):
        return "none"

    nAt = selector.rfind(">")
    strLast = jtrim(selector if 0 > nAt else selector[nAt + 1:])

    return "attribute" if strLast.startswith("#") or "[" in strLast else "position"


def get_weak_report(map_node: dict) -> str:
    """리포트에 붙일 "테스트 단서가 약한 칸" 절 — 없으면 한 줄로 그렇다고 적는다"""
    sb: List[str] = []
    nNone = 0
    nPosition = 0

    for s in items(jget(map_node, "screens")):
        lines: List[str] = []

        for f in items(jget(s, "fields")):
            strFieldLabel = as_text(jget(f, "label"))
            strName = strFieldLabel + " [" + as_text(jget(f, "kind")) + "]"
            strFieldAnchor = as_text(jget(f, "anchor"))
            nNone += _weak_line(lines, strFieldAnchor, "칸 " + strName, as_text(jget(f, "selector"), ""))
            nPosition += 1 if "position" == strFieldAnchor else 0

            for b in items(jget(f, "buttons")):
                strButtonAnchor = as_text(jget(b, "anchor"))
                nNone += _weak_line(lines, strButtonAnchor, "버튼 '" + as_text(jget(b, "text")) + "' (" + strFieldLabel + " 칸 뒤)",
                                    as_text(jget(b, "selector"), ""))
                nPosition += 1 if "position" == strButtonAnchor else 0

        for u in items(jget(s, "unnamed")):
            lines.append("✗ 이름 없는 " + ("링크" if "A" == as_text(jget(u, "tag")) else "버튼") + " ("
                         + as_text(jget(u, "selector"), "selector 없음") + ") — 글자가 없어 무엇을 하는지 알 수 없다. title · aria-label 필요")
            nNone += 1

        if lines:
            sb.append("  " + as_text(jget(s, "id")) + " " + as_text(jget(jget(s, "menuPath"), 0)) + "\n")

            for strLine in lines:
                sb.append("    " + strLine + "\n")

    strHead = "테스트 단서가 약한 칸: 단서 없음 " + str(nNone) + "개 · 위치에만 기댐 " + str(nPosition) + "개\n"

    return strHead if 0 == nNone + nPosition else strHead + "".join(sb)


def _weak_line(lines: List[str], anchor: str, what: str, selector: str) -> int:
    """단서 없음이면 1"""
    if "none" == anchor:
        lines.append("✗ " + what + " — 테스트로 잡을 단서가 없다. data-testid 필요")
        return 1

    if "position" == anchor:
        lines.append("△ " + what + " — 위치에만 기댄다(" + selector + "). 배치가 바뀌면 깨지기 쉽다")

    return 0


def get_how(reach: Any) -> str:
    """재현 경로의 click 글자를 이어 붙인다 — 데이터 칸은 "(표 N 첫 링크)" 로"""
    steps = ["시작"]

    for step in items(reach):
        strAction = as_text(jget(step, "action"))

        if "hover" == strAction:
            steps.append(as_text(jget(step, "text")) + "(마우스 올림)")
        elif "goto" == strAction and as_bool(jget(step, "hiddenLink"), False):
            # 시작 화면에 숨어 있는 링크(마우스를 올려야 보이는 메뉴 등) — 눌러서는 못 가 주소로 연다
            steps[0] = "주소로 열기 " + as_text(jget(step, "url")) + "(안 보이는 링크)"
        elif "click" == strAction:
            if as_bool(jget(step, "dataRow")):
                steps.append("(표 " + str(as_int(jget(step, "tableIndex"))) + " 첫 링크)")
            else:
                steps.append(as_text(jget(step, "text")))

    return " › ".join(steps)


def parse(aria: str) -> Parsed:
    """aria 에서 제목 · 버튼 · 링크 · 입력칸을 뽑는다"""
    headings: Dict[str, None] = {}
    buttons: Dict[str, None] = {}
    links: Dict[str, None] = {}
    fields: List[Field] = []

    strSection = ""
    strGroup = ""
    strLastText = ""
    strLastFieldLabel: Optional[str] = None
    open_field: Optional[Field] = None
    nOpenIndent = -1
    options: List[str] = []
    # 버튼을 붙일 칸(fields 의 차례) — 칸 바로 뒤의 버튼만 그 칸의 것이다
    nAttach = -1

    for strLine in jsplit("\n", aria):
        m = _LINE.fullmatch(strLine)

        if not m:
            continue

        nIndent = len(m.group(1))
        strRole = m.group(2)
        strName = "" if m.group(3) is None else _unescape(m.group(3))

        # 고르기(combobox)의 option 모으기
        if open_field is not None:
            if nIndent > nOpenIndent and "option" == strRole:
                if len(options) < _MAX_OPTIONS:
                    options.append(strName)

                continue

            fields.append(Field(open_field.label, open_field.section, open_field.group, open_field.kind, list(options), []))
            nAttach = len(fields) - 1
            open_field = None

        if "heading" == strRole:
            strHeading = clean(strName)

            if "" != strHeading:
                headings[strHeading] = None
                strSection = strHeading
                strGroup = ""
                nAttach = -1
        elif "button" == strRole:
            # 글자가 기호뿐인 버튼(‹ › ✎)은 지우면 사라진다 — 그대로 둔다
            strButton = clean_or_raw(strName)

            if "" != strButton:
                buttons[strButton] = None

                if 0 <= nAttach:
                    fields[nAttach].buttons.append(strButton)

            # 버튼이 딸린 입력칸 — 뒤따르는 칸들의 묶음 이름
            if strLastFieldLabel is not None:
                strGroup = strLastFieldLabel
                strLastFieldLabel = None
        elif "link" == strRole:
            strLink = clean_or_raw(strName)

            if "" != strLink:
                links[strLink] = None
        elif "text" == strRole:
            t = _TEXT.fullmatch(strLine)
            # 입력칸 이름 후보 — 숫자를 지우지 않는다("주소 2" 같은 칸 이름이 있다)
            strLastText = squash(_unescape(t.group(1))) if t else ""
        elif strRole in _INPUTS:
            if "" != strName:
                strLabel = squash(strName)
            elif "" != strLastText:
                strLabel = strLastText
            else:
                strLabel = "(이름 없음)"

            oField = Field(strLabel, strSection, strGroup, strRole, [], [])

            if "combobox" == strRole:
                open_field = oField
                nOpenIndent = nIndent
                options = []
                nAttach = -1
            else:
                fields.append(oField)
                nAttach = len(fields) - 1

            strLastFieldLabel = strLabel
            strLastText = ""

    if open_field is not None:
        fields.append(Field(open_field.label, open_field.section, open_field.group, open_field.kind, list(options), []))

    return Parsed(list(headings), list(buttons), list(links), fields)


def clean(text: str) -> str:
    """글자에서 데이터를 지운다 — 숫자가 든 낱말(시각 · 날짜 · 건수 · 사용량 · 아이디)과 오전 · 오후, 남은 가운뎃점.
    "시스템 사용량 오후 1:52:42" → "시스템 사용량", "Chord 목록 2026-10 기준 14건" → "Chord 목록 기준" """
    words = []

    for strWord in jsplit(r"\s+", text.replace("\n", " ")):
        if "" == strWord or re.search(r"\d", strWord, re.ASCII) or "오전" == strWord or "오후" == strWord:
            continue

        words.append(strWord)

    strCleaned = " ".join(words)
    strCleaned = re.sub(r"(^[·›,\s]+)|([·›,\s]+$)", "", strCleaned, flags=re.ASCII)
    strCleaned = re.sub(r"\s*·\s*·\s*", " · ", strCleaned, flags=re.ASCII)

    return jtrim(strCleaned)


def clean_or_raw(text: str) -> str:
    """clean 하고 남는 게 없으면(기호뿐인 글자) 원래 글자"""
    strClean = clean(text)

    return squash(text) if "" == strClean else strClean


def squash(text: str) -> str:
    """줄바꿈 · 겹친 빈칸만 하나로"""
    return jtrim(re.sub(r"\s+", " ", text, flags=re.ASCII))


def _unescape(text: str) -> str:
    return text.replace('\\"', '"').replace("\\\\", "\\")
