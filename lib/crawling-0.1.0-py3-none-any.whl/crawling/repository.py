"""상태 · 이동 기록 저장소(명세 §8.2) — Java 판 StateRepository · FileStateRepository.

지금은 파일, 이후 RDB(STATE · TRANSIT) 구현으로 바꾼다 — StateRepository 를 이어받아 만든다.

파일 저장소::

    crawl-output/
      states/{stateId}.json
      screenshots/{stateId}.png
      transitions.json
      index.json

시작할 때 index.json · transitions.json 이 있으면 읽어 들여, 다시 돌려도 같은 상태를 또 만들지 않고 처리한 메뉴는 건너뛴다.
"""

from __future__ import annotations

import copy
import os
from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional

from ._jutil import as_bool, as_int, as_text, items, jget, is_empty, read_json, write_json
from .state_key import StateKey


@dataclass(frozen=True)
class Summary:
    """인덱스 한 줄 — 리포트용 요약. server_error 는 다시 해도 서버 오류(5xx)였던 화면"""

    state_id: str
    normalized_url: str
    title: str
    structure: str
    element_count: int
    menu_paths: List[str]
    server_error: bool


class StateRepository(ABC):
    @abstractmethod
    def find(self, key: StateKey) -> Optional[str]:
        """같은 키의 상태 stateId — 없으면 None"""

    @abstractmethod
    def save(self, key: StateKey, state: dict) -> str:
        """새 상태를 저장하고 stateId 를 돌려준다"""

    @abstractmethod
    def add_menu_path(self, state_id: str, menu_path: str) -> None:
        """이미 있는 상태에 도달 경로만 더한다"""

    def load(self, state_id: str) -> Optional[dict]:
        """저장된 상태 하나. 구현하지 않으면 이번 실행에서 모은 상태만 smoke-input.json 에 들어간다"""
        return None

    def set_reach(self, state_id: str, reach: list) -> None:
        """같은 화면에 더 짧은 경로로 닿았을 때 재현 경로(reach)를 바꾼다"""

    def find_by_hash(self, merge_hash: str) -> Optional[str]:
        """묶기 해시(get_merge_hash)가 같은 상태(mergeSameStructure) — 같은 코드로 그린 화면으로 본다"""
        return None

    def add_variant(self, state_id: str, variant: dict) -> None:
        """같은 구조의 다른 주소 · 경로를 대표 상태에 변형(variants)으로 남긴다 — {url, normalizedUrl, menuPath, reach}"""

    @abstractmethod
    def add_transition(self, from_state_id: Optional[str], to_state_id: str, action: Optional[str],
                       selector: Optional[str]) -> None:
        pass

    @abstractmethod
    def is_menu_done(self, menu_path: str) -> bool:
        """이미 처리한 메뉴 경로 — 다시 돌릴 때 건너뛴다(명세 §10)"""

    @abstractmethod
    def mark_menu_done(self, menu_path: str) -> None:
        pass

    @abstractmethod
    def has_normalized_url(self, normalized_url: str) -> bool:
        pass

    @abstractmethod
    def get_screenshot_path(self, state_id: str) -> Path:
        pass

    @abstractmethod
    def get_size(self) -> int:
        pass

    @abstractmethod
    def get_summaries(self) -> List[Summary]:
        pass

    @abstractmethod
    def flush(self) -> None:
        """index.json · transitions.json 을 내려 쓴다"""


def _get_key(key: StateKey) -> str:
    return key.normalized_url + "|" + key.struct_hash


def _contains(array: list, value: str) -> bool:
    for n in array:
        if value == as_text(n):
            return True

    return False


def _with_array(node: dict, key: str) -> list:
    """ObjectNode.withArray(key) — 없거나 배열이 아니면 새 배열을 단다"""
    value = node.get(key)

    if not isinstance(value, list):
        value = []
        node[key] = value

    return value


class FileStateRepository(StateRepository):
    def __init__(self, directory):
        self._dir = Path(directory)
        self._states_dir = self._dir / "states"
        self._screenshots_dir = self._dir / "screenshots"
        # "정규화 URL|구조 해시" → 인덱스 한 줄
        self._index: dict = {}
        self._done_menus: dict = {}

        os.makedirs(self._states_dir, exist_ok=True)
        os.makedirs(self._screenshots_dir, exist_ok=True)

        oIndexFile = self._dir / "index.json"

        if oIndexFile.exists():
            root = read_json(oIndexFile)

            for state in items(jget(root, "states")):
                self._index[as_text(jget(state, "normalizedUrl")) + "|" + as_text(jget(state, "structHash"))] = state

            for n in items(jget(root, "doneMenus")):
                self._done_menus[as_text(n)] = True

        oTransitionsFile = self._dir / "transitions.json"
        self._transitions: list = read_json(oTransitionsFile) if oTransitionsFile.exists() else []

    def find(self, key: StateKey) -> Optional[str]:
        oEntry = self._index.get(_get_key(key))

        return None if oEntry is None else as_text(jget(oEntry, "stateId"))

    def save(self, key: StateKey, state: dict) -> str:
        stateId = "s%04d" % (len(self._index) + 1)

        state["stateId"] = stateId
        state["normalizedUrl"] = key.normalized_url
        state["structHash"] = key.struct_hash

        self._write(self._states_dir / (stateId + ".json"), state)

        entry = {
            "stateId": stateId,
            "normalizedUrl": key.normalized_url,
            "structHash": key.struct_hash,
            "mergeHash": as_text(jget(state, "mergeHash"), ""),
            "title": as_text(jget(state, "title"), ""),
            "structure": as_text(jget(state, "structure"), ""),
            "elementCount": as_int(jget(state, "elementCount")),
            "serverError": not is_empty(jget(state, "serverErrors")),
            "menuPath": copy.deepcopy(jget(state, "menuPath")) if isinstance(jget(state, "menuPath"), (list, dict)) else [],
        }

        self._index[_get_key(key)] = entry
        self.flush()

        return stateId

    def find_by_hash(self, merge_hash: str) -> Optional[str]:
        for n in self._index.values():
            if merge_hash == as_text(jget(n, "mergeHash")):
                return as_text(jget(n, "stateId"))

        return None

    def add_variant(self, state_id: str, variant: dict) -> None:
        oFile = self._states_dir / (state_id + ".json")
        state = read_json(oFile)
        variants = _with_array(state, "variants")
        strUrl = as_text(jget(variant, "normalizedUrl"))
        strPath = as_text(jget(variant, "menuPath"))

        for v in variants:
            if strUrl == as_text(jget(v, "normalizedUrl")) and strPath == as_text(jget(v, "menuPath")):
                return

        variants.append(variant)
        self._write(oFile, state)

    def add_menu_path(self, state_id: str, menu_path: str) -> None:
        oFile = self._states_dir / (state_id + ".json")
        state = read_json(oFile)
        paths = _with_array(state, "menuPath")

        if not _contains(paths, menu_path):
            paths.append(menu_path)
            self._write(oFile, state)

        for n in self._index.values():
            if state_id == as_text(jget(n, "stateId")):
                paths = _with_array(n, "menuPath")

                if not _contains(paths, menu_path):
                    paths.append(menu_path)

                break

    def load(self, state_id: str) -> Optional[dict]:
        oFile = self._states_dir / (state_id + ".json")

        return read_json(oFile) if oFile.exists() else None

    def set_reach(self, state_id: str, reach: list) -> None:
        state = self.load(state_id)

        if state is not None:
            state["reach"] = copy.deepcopy(reach)
            self._write(self._states_dir / (state_id + ".json"), state)

    def add_transition(self, from_state_id, to_state_id, action, selector) -> None:
        for t in self._transitions:
            if (as_text(jget(t, "fromStateId")) == ("null" if from_state_id is None else from_state_id)
                    and as_text(jget(t, "toStateId")) == to_state_id
                    and as_text(jget(t, "action")) == action):
                return

        self._transitions.append({"fromStateId": from_state_id, "toStateId": to_state_id, "action": action, "selector": selector})

    def is_menu_done(self, menu_path: str) -> bool:
        return menu_path in self._done_menus

    def mark_menu_done(self, menu_path: str) -> None:
        self._done_menus[menu_path] = True
        self.flush()

    def has_normalized_url(self, normalized_url: str) -> bool:
        for n in self._index.values():
            if normalized_url == as_text(jget(n, "normalizedUrl")):
                return True

        return False

    def get_screenshot_path(self, state_id: str) -> Path:
        return self._screenshots_dir / (state_id + ".png")

    def get_size(self) -> int:
        return len(self._index)

    def get_summaries(self) -> List[Summary]:
        result = []

        for n in self._index.values():
            paths = [as_text(p) for p in items(jget(n, "menuPath"))]
            result.append(Summary(as_text(jget(n, "stateId")), as_text(jget(n, "normalizedUrl")), as_text(jget(n, "title")),
                                  as_text(jget(n, "structure")), as_int(jget(n, "elementCount")), paths,
                                  as_bool(jget(n, "serverError"))))

        return result

    def flush(self) -> None:
        root = {"states": list(self._index.values()), "doneMenus": list(self._done_menus.keys())}

        self._write(self._dir / "index.json", root)
        self._write(self._dir / "transitions.json", self._transitions)

    @staticmethod
    def _write(path: Path, node) -> None:
        write_json(path, node)
