"""aria 스냅샷에서 데이터를 걸러낸다 — Java 판 AriaFilter. filter() 가 입구다.

입력칸 값
    textbox · searchbox · spinbutton · combobox · slider 줄의 값을 지운다.
    ``- textbox "Password": bchord`` → ``- textbox "Password"``. 여러 줄 값(``|-`` 블록)도 지운다.

표 데이터 행
    표(table · grid · treegrid)마다 앞의 두 행 — 머리글과 대표 1행 — 만 남기고, 나머지 행은 하위 줄까지 지운 뒤
    ``- text: "(데이터 행 N개 생략)"`` 한 줄로 바꾼다. 스모크 테스트가 데이터 값에 기대지 않게 하고,
    LLM 에 넘길 글을 줄이고, 데이터가 서버 · LLM 으로 넘어가지 않게 한다.
"""

from __future__ import annotations

import re
from typing import List, Optional

from ._jutil import jblank, jtrim

# 머리글 + 대표 1행
KEEP_ROWS = 2

# 글자에 특수문자가 있으면 줄 전체가 작은따옴표로 싸인다 — - 'row "a: b"':
_TABLE = re.compile(r"^\s*- '?(table|grid|treegrid)\b.*", re.ASCII)
_ROW = re.compile(r"^\s*- '?row\b.*", re.ASCII)

# 값을 지울 입력칸 — "- 역할 "이름" [속성]: 값" 의 값. 이름 안의 \" 도 받는다
_INPUT_VALUE = re.compile(
    r"^(\s*- '?(?:textbox|searchbox|spinbutton|combobox|slider)(?: \"(?:[^\"\\]|\\.)*\")?(?: \[[^\]]*\])*'?):[ \t]+(\S.*)$",
    re.ASCII)
# YAML 여러 줄 값의 시작
_BLOCK_SCALAR = re.compile(r"^[|>][-+]?$")
# 입력칸 줄 — 이것이 든 표는 데이터 표가 아니라 입력 양식이다
_INPUT_ROLE = re.compile(r"^\s*- '?(textbox|searchbox|spinbutton|combobox|checkbox|radio|slider)\b.*", re.ASCII)


def filter(aria: Optional[str]) -> Optional[str]:  # noqa: A001 — Java 판 이름 그대로
    """입력칸 값과 표 데이터 행을 걸러낸다 — 저장 전에 부른다"""
    return compact_tables(strip_input_values(aria))


def strip_input_values(aria: Optional[str]) -> Optional[str]:
    if aria is None or "" == aria:
        return aria

    out: List[str] = []
    nBlockIndent = -1

    for strLine in aria.split("\n"):
        # 여러 줄 값의 뒷줄
        if 0 <= nBlockIndent:
            if jblank(strLine) or _get_indent(strLine) > nBlockIndent:
                continue

            nBlockIndent = -1

        m = _INPUT_VALUE.fullmatch(strLine)

        if m:
            strValue = jtrim(m.group(2))

            if _BLOCK_SCALAR.fullmatch(strValue):
                nBlockIndent = _get_indent(strLine)

            out.append(m.group(1))
            continue

        out.append(strLine)

    return "\n".join(out)


def compact_tables(aria: Optional[str]) -> Optional[str]:
    if aria is None or "" == aria:
        return aria

    out: List[str] = []
    nTableIndent = -1
    nRows = 0
    nDropIndent = -1
    nDropped = 0
    nPlaceholder = -1
    strPad = ""
    lines = aria.split("\n")

    for i, strLine in enumerate(lines):
        bBlank = jblank(strLine)
        nIndent = _get_indent(strLine)

        # 지우는 행의 하위 줄
        if 0 <= nDropIndent:
            if not bBlank and nIndent > nDropIndent:
                continue

            nDropIndent = -1

        # 표가 끝났다
        if 0 <= nTableIndent and not bBlank and nIndent <= nTableIndent:
            _fill(out, nPlaceholder, strPad, nDropped)
            nTableIndent = -1

        if 0 > nTableIndent:
            # 입력칸이 든 표는 입력 양식(오래된 화면의 표 배치 폼)이다 — 줄이지 않는다
            if _TABLE.fullmatch(strLine) and not _is_form_table(lines, i, nIndent):
                nTableIndent = nIndent
                nRows = 0
                nDropped = 0
                nPlaceholder = -1
        elif _ROW.fullmatch(strLine):
            nRows += 1

            if KEEP_ROWS < nRows:
                nDropped += 1
                nDropIndent = nIndent

                if 0 > nPlaceholder:
                    nPlaceholder = len(out)
                    strPad = strLine[:nIndent]
                    out.append("")

                continue

        out.append(strLine)

    _fill(out, nPlaceholder, strPad, nDropped)

    return "\n".join(out)


def _is_form_table(lines: List[str], i: int, nIndent: int) -> bool:
    """i 줄의 표(들여쓰기 nIndent)가 끝날 때까지 입력칸 줄이 있는가"""
    for k in range(i + 1, len(lines)):
        if not jblank(lines[k]) and _get_indent(lines[k]) <= nIndent:
            return False

        if _INPUT_ROLE.fullmatch(lines[k]):
            return True

    return False


def _fill(out: List[str], nPlaceholder: int, strPad: str, nDropped: int) -> None:
    if 0 <= nPlaceholder and 0 < nDropped:
        out[nPlaceholder] = strPad + '- text: "(데이터 행 ' + str(nDropped) + '개 생략)"'


def _get_indent(strLine: str) -> int:
    i = 0

    while i < len(strLine) and " " == strLine[i]:
        i += 1

    return i
