"""업무 테스트 ④ · ⑥ 에 LLM 으로 보낼 글(doc/업무테스트_입력양식.md) — Java 판 BusinessPrompt.

- draft — ④ 초안: 업무 + 확인된 연결안 + 연결안이 가리키는 화면의 상세(smoke-input.json 에서) → Playwright Test 초안
- fix — ⑥ 완성: 업무 + 연결안 + 초안 + 시험 실행 기록(runner/test-results 의 run-record.json 들) → 완성본 + fixes · findings

명령줄::

    python -m crawling.business_prompt draft scenario.json mapping.json smoke-input.json out.md
    python -m crawling.business_prompt fix scenario.json mapping.json draft.spec.ts test-results out.md
"""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Any

from ._jutil import as_text, dumps_pretty, has_non_null, items, jget, read_json, write_text
from .smoke_prompt import get_template


def get_draft_prompt(scenario: Any, mapping: Any, smoke_input: Any) -> str:
    """④ — 연결안이 가리키는 화면만 smoke-input 에서 골라 넣는다"""
    ids = {}

    for oGroup in (jget(mapping, "steps"), jget(mapping, "fields")):
        for n in items(oGroup):
            if has_non_null(n, "screen"):
                ids[as_text(n["screen"])] = None

    screens = {
        "layout": as_text(jget(smoke_input, "layout"), ""),
        "screens": [s for s in items(jget(smoke_input, "screens")) if as_text(jget(s, "id")) in ids],
    }

    strPrompt = get_template("business-ts.md")
    strPrompt = strPrompt.replace("{{SCENARIO}}", dumps_pretty(scenario))
    strPrompt = strPrompt.replace("{{MAPPING}}", dumps_pretty(mapping))

    return strPrompt.replace("{{SCREENS}}", dumps_pretty(screens))


def get_fix_prompt(scenario: Any, mapping: Any, draft: str, test_results) -> str:
    """⑥ — 시험 실행 기록은 run-record.json 들을 모으고, 스크린샷 경로는 뺀다"""
    lstRecords = []

    # Files.walk 처럼 없는 폴더는 오류다
    if not os.path.exists(test_results):
        raise FileNotFoundError(str(test_results))

    for strRoot, _dirs, files in os.walk(test_results):
        for strFile in files:
            if "run-record.json" == strFile:
                lstRecords.append(Path(strRoot) / strFile)

    runs = []

    for oFile in sorted(lstRecords):
        run = read_json(oFile)

        for s in items(jget(run, "steps")):
            if isinstance(s, dict):
                s.pop("screenshot", None)

        runs.append(run)

    strPrompt = get_template("business-fix-ts.md")
    strPrompt = strPrompt.replace("{{SCENARIO}}", dumps_pretty(scenario))
    strPrompt = strPrompt.replace("{{MAPPING}}", dumps_pretty(mapping))
    strPrompt = strPrompt.replace("{{DRAFT}}", draft)

    return strPrompt.replace("{{RUN}}", dumps_pretty(runs))


def main(args=None) -> None:
    args = sys.argv[1:] if args is None else args

    if 5 == len(args) and "draft" == args[0]:
        strPrompt = get_draft_prompt(read_json(args[1]), read_json(args[2]), read_json(args[3]))
    elif 6 == len(args) and "fix" == args[0]:
        # Files.readString — 줄바꿈을 바꾸지 않고 읽는다
        with open(args[3], "r", encoding="utf-8", newline="") as oFile:
            strDraft = oFile.read()

        strPrompt = get_fix_prompt(read_json(args[1]), read_json(args[2]), strDraft, args[4])
    else:
        print("쓰는 법: python -m crawling.business_prompt draft scenario.json mapping.json smoke-input.json 내보낼.md")
        print("        python -m crawling.business_prompt fix scenario.json mapping.json draft.spec.ts test-results 내보낼.md")
        return

    strOut = args[-1]

    write_text(strOut, strPrompt)

    print(strOut + " — " + str(len(strPrompt)) + "자")


if __name__ == "__main__":
    main()
