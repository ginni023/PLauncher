"""입력값 리스트(inputs.json, 명세 §8.5) — Java 판 InputList. 크롤링이 모은 화면의 입력칸을 key 하나씩으로 모은다.

WAS 화면이 key 마다 value 를 받아, LLM 요청마다 함께 보내고 P.S 실행 때 variableMap 으로 넘긴다.
**크롤링 자체에는 값을 넣지 않는다** — 크롤링은 구조만 모은다(2026-10-27 결정).

- key — 요소 id → name → 칸 이름 차례. id · name 은 다시 크롤링해도 잘 바뀌지 않고 스크립트 변수 이름으로도 쓸 수 있다.
- 같은 key 의 칸이 여러 화면에 있으면(머리의 검색칸 등) 하나로 묶고 screens 에 화면을 모은다.
- 라디오는 name 하나에 선택지(options) 여럿. 비밀번호 칸은 kind=password — 화면에서 값을 가린다.
- 다시 만들 때 이전 inputs.json 의 value 를 같은 key 에 이어 붙인다 — 사용자가 채운 값이 날아가지 않는다.
"""

from __future__ import annotations

import copy
import re
from pathlib import Path
from typing import Any, Dict, Optional

from ._jutil import as_text, has_non_null, is_array, items, jget, jtrim, now_offset, read_json, write_json
from .log import CrawlLog
from .repository import StateRepository


def build(site_map: dict, repository: StateRepository, this_run: Dict[str, dict], previous: Any) -> dict:
    """
    :param site_map: site_map.build 결과 — 화면마다 fields(칸 이름 · 종류 · selector · options)
    :param repository: 화면 상세(요소의 id · name · type)를 다시 읽을 곳
    :param this_run: 이번 실행에서 저장한 상태 — 있으면 다시 읽지 않는다
    :param previous: 이전 inputs.json(없으면 None) — 같은 key 의 value 를 이어 붙인다
    """
    previousValues: Dict[str, str] = {}

    if previous is not None:
        for item in items(jget(previous, "inputs")):
            previousValues[as_text(jget(item, "key"))] = as_text(jget(item, "value"), "")

    byKey: Dict[str, dict] = {}
    # 칸 이름으로 만든 key 가 다른 칸과 겹쳤는지 가리려고 — key → 그 key 를 처음 만든 selector
    labelKeySelector: Dict[str, str] = {}

    for screen in items(jget(site_map, "screens")):
        strScreenId = as_text(jget(screen, "id"))
        state = this_run[strScreenId] if strScreenId in this_run else repository.load(strScreenId)
        elements = [] if state is None else jget(state, "elements")

        for field in items(jget(screen, "fields")):
            strSelector = as_text(jget(field, "selector"), "")
            element = _get_element(elements, strSelector)
            strId = _get_text(element, "id")
            strName = _get_text(element, "name")
            bRadio = "radio" == as_text(jget(field, "kind"))
            bPassword = "password" == _get_text(element, "type").lower()
            strKeySelector = strSelector

            if bRadio and "" != strName:
                # 라디오 한 무리 — name 하나에 선택지 여럿
                strKey = strName
                strKeySelector = 'input[name="' + strName + '"]'
            elif "" != strId:
                strKey = strId
            elif "" != strName:
                strKey = strName
            else:
                strKey = _get_label_key(field)
                # Map.putIfAbsent — 처음이면 넣고 None, 있으면 먼저 넣은 selector
                strOwner = labelKeySelector.get(strKey)

                if strOwner is None:
                    labelKeySelector[strKey] = strSelector
                elif strOwner != strSelector:
                    strKey = _get_label_key(field) + "_" + strScreenId

            if strKey not in byKey:
                byKey[strKey] = _new_item(strKey, field, bRadio, bPassword)

            item = byKey[strKey]

            if "selector" not in item and "" != strKeySelector:
                item["selector"] = strKeySelector

            if bRadio:
                _add_unique(_with_array(item, "options"), as_text(jget(field, "label")))

            _add_unique(_with_array(item, "screens"), strScreenId)

    inputs = []

    for item in byKey.values():
        item["value"] = previousValues.get(as_text(jget(item, "key")), "")
        inputs.append(item)

    return {"site": as_text(jget(site_map, "site"), ""), "generatedAt": now_offset(), "inputs": inputs, "inputCount": len(inputs)}


def _with_array(node: dict, key: str) -> list:
    value = node.get(key)

    if not isinstance(value, list):
        value = []
        node[key] = value

    return value


def _new_item(key: str, field: Any, radio: bool, password: bool) -> dict:
    item: dict = {"key": key}
    # 라디오는 선택지 하나하나가 칸으로 잡힌다 — 무리의 이름은 소제목(결제 수단)
    item["label"] = as_text(jget(field, "section")) if radio and has_non_null(field, "section") else as_text(jget(field, "label"))

    if has_non_null(field, "section"):
        item["section"] = as_text(jget(field, "section"))

    item["kind"] = "password" if password else as_text(jget(field, "kind"), "")

    if is_array(jget(field, "options")) and not radio:
        item["options"] = copy.deepcopy(field["options"])

    return item


def _get_label_key(field: Any) -> str:
    """칸 이름으로 만든 key — 빈칸은 _ 로. 이름이 없으면 종류"""
    strLabel = jtrim(as_text(jget(field, "label"), ""))
    strBase = as_text(jget(field, "kind"), "input") if "" == strLabel else strLabel

    return re.sub(r"\s+", "_", strBase, flags=re.ASCII)


def _get_element(elements: Any, selector: str) -> Optional[dict]:
    if "" != selector:
        for el in items(elements):
            if selector == as_text(jget(el, "selector")):
                return el

    return None


def _get_text(node: Any, field: str) -> str:
    if node is None:
        return ""

    value = jget(node, field)

    return "" if value is None else as_text(value, "")


def _add_unique(array: list, value: str) -> None:
    for n in array:
        if value == as_text(n):
            return

    array.append(value)


def read(path) -> Optional[Any]:
    """이전 inputs.json — 없거나 못 읽으면 None"""
    oPath = Path(path)

    try:
        return read_json(oPath) if oPath.exists() else None
    except (OSError, ValueError) as e:
        CrawlLog.warn("이전 입력값 리스트를 못 읽었습니다 — %s (%s)", oPath, e)
        return None


def write(path, input_list: dict) -> None:
    write_json(path, input_list)


def to_text(input_list: Any) -> str:
    """LLM 요청에 붙일 글 — key=value 한 줄씩. 비밀번호 칸의 값은 보내지 않는다::

        search_input=헤드폰
        detail_quantity=2
        login_password=(가림)
    """
    lines = []

    for item in items(jget(input_list, "inputs")):
        strValue = as_text(jget(item, "value"), "")
        bHide = "password" == as_text(jget(item, "kind")) and "" != strValue
        lines.append(as_text(jget(item, "key")) + "=" + ("(가림)" if bHide else strValue) + "\n")

    return "".join(lines)
