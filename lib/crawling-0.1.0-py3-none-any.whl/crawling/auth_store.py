"""사이트별 로그인 정보(Playwright storageState JSON) — Java 판 AuthStore.

auth/{host}.json 에 둔다 — 시스템 이름을 주면 auth/{이름}.json.
쿠키가 "있다"는 것은 그 파일에 대상 호스트에 붙는, 아직 만료되지 않은 쿠키가 하나 이상 있다는 뜻이다.
서버 쪽 세션이 살아 있는지는 알 수 없으므로, 크롤링 중 로그인 화면이 다시 보이면 만료로 본다.
"""

from __future__ import annotations

import json
import os
import re
import time
from pathlib import Path
from typing import Optional

from ._jutil import Uri, as_double, as_text, items, jget
from .log import CrawlLog


class AuthStore:
    def __init__(self, directory, target: Uri, file_name: Optional[str] = None):
        """
        :param file_name: 파일 이름(.json 앞) — None 이면 host 또는 host_port. 쿠키는 이름과 상관없이 target 의 호스트로 본다
        """
        self._host = target.host.lower()
        strName = (self._host + ("" if -1 == target.port else "_" + str(target.port))) if file_name is None else file_name
        self._file = Path(directory) / (strName + ".json")

    def get_file(self) -> Path:
        return self._file

    def has_cookies(self) -> bool:
        if not self._file.exists():
            return False

        try:
            with open(self._file, "r", encoding="utf-8") as oFile:
                root = json.load(oFile)
        except (OSError, ValueError) as e:
            CrawlLog.warn("로그인 정보 파일을 읽지 못했습니다 — %s (%s)", self._file, e)
            return False

        dNow = time.time()

        for cookie in items(jget(root, "cookies")):
            dExpires = as_double(jget(cookie, "expires"), -1)

            if self._matches_host(as_text(jget(cookie, "domain"), "")) and (0 > dExpires or dNow < dExpires):
                return True

        return False

    def _matches_host(self, domain: str) -> bool:
        strBare = re.sub(r"^\.", "", domain.lower(), count=1)

        return self._host == strBare or self._host.endswith("." + strBare)

    def delete(self) -> None:
        try:
            os.remove(self._file)
        except FileNotFoundError:
            pass
