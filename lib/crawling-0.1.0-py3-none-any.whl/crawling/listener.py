"""크롤링 진행 알림 — Java 판 CrawlListener. 에이전트 화면이나 서버로 진행 상황을 넘길 때 쓴다.

모두 **크롤링 작업 스레드**에서 불린다. GUI 를 고칠 때는 그 GUI 의 스레드로 넘긴다(예: Tk 의 after, Qt 의 signal).
여기서 시간이 오래 걸리는 일을 하면 크롤링이 그만큼 늦어진다.

필요한 것만 고쳐 쓴다::

    class MyListener(CrawlListener):
        def on_log(self, line):
            print(line)
"""

from __future__ import annotations


class CrawlListener:
    def on_log(self, line: str) -> None:
        """로그 한 줄 — "HH:MM:SS INFO ..." """

    def on_state(self, state_id: str, menu_path: str, normalized_url: str, structure: str, element_count: int,
                 is_new: bool) -> None:
        """화면(상태) 하나를 모았다. is_new 가 False 면 이미 있던 상태에 도달 경로만 더해졌다"""

    def on_failure(self, what: str, reason: str) -> None:
        """메뉴 · 링크 하나가 실패했다 — 크롤링은 계속된다"""


# 알리지 않는 리스너
CrawlListener.NONE = CrawlListener()  # type: ignore[attr-defined]
NONE = CrawlListener.NONE  # type: ignore[attr-defined]
