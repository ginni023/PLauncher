"""크롤링 옵션(명세 §2) — Java 판 CrawlerConfig.

두 가지로 만든다.

- 파이썬 코드 — 생성자와 set 메서드. 시작 URL · 로그인 여부까지 담아 CrawlerEngine.crawl() 로 넘긴다::

    config = CrawlerConfig("http://localhost:8080/", True)
    config.set_danger_words("삭제", "저장")
    config.set_full_scan(True)
    config.set_max_depth(3)

- 설정 파일 crawler.properties — CrawlerConfig.load(path). 파일이 없으면 모두 기본값으로 돈다.
  키와 설명은 crawler.properties.example. 시작 URL · 로그인 여부는 설정 파일 키가 아니다.

값은 문자열로 들고 있다가 get · is 를 부를 때 기본값을 채우고 바꾼다 — **빈 값(공백뿐인 값 포함)은 기본값**이다.
set 메서드에 None 을 주면 그 키를 지워 기본값으로 돌린다.
"""

from __future__ import annotations

import os
from typing import Iterable, List, Mapping, Optional, Union

from ._jutil import jblank, jtrim

DEFAULT_FILE = "crawler.properties"

# 위험 버튼 — 텍스트에 이것이 들어 있으면 누르지 않는다(명세 §4). 설정 dangerWords 로 바꿀 수 있다
_DEFAULT_DANGER_WORDS = "삭제,저장"
# dangerWords 를 "하나도 없음" 으로 둘 때의 값 — 빈 값은 기본값으로 돌아가므로 쉼표 하나로 둔다
_NO_DANGER_WORDS = ","
# retryWaitStepsMs 를 "재시도 없음" 으로 둘 때의 값 — 빈 값은 기본값으로 돌아가므로
_NO_RETRY = "none"


def _bool_text(bValue: bool) -> str:
    return "true" if bValue else "false"


def _parse_bool(strValue: str) -> bool:
    """Boolean.parseBoolean — "true"(대소문자 무시)만 참"""
    return "true" == strValue.lower()


class CrawlerConfig:
    def __init__(self, start_url: Optional[str] = None, login_required: bool = False):
        """모두 기본값 — 시작 URL · 로그인 여부를 주면 그것도 담는다(설정 파일 키가 아니다).

        :param start_url: 로그인 후 첫 화면 주소 — http · https 와 호스트가 있어야 한다
        :param login_required: 로그인이 필요한 사이트인가
        """
        self._props: dict = {}
        self._start_url = start_url
        self._login_required = bool(login_required)

    # ================================================================ 시작 · 로그인 (설정 파일 키가 아니다)

    def set_start_url(self, start_url: Optional[str]) -> None:
        """시작 URL — 로그인 후 첫 화면. 크롤러는 여기서 메뉴를 모으고, 탐색 허용 호스트는 이 URL 의 host:port 다"""
        self._start_url = start_url

    def get_start_url(self) -> Optional[str]:
        """시작 URL — 코드로 주지 않았으면 None. 설정 파일로 만든 설정은 늘 None 이다"""
        return self._start_url

    def set_login_required(self, login_required: bool) -> None:
        """로그인이 필요한 사이트인가. True 면 저장된 쿠키(authDir)로 크롤링하고, 쿠키가 없으면 crawl 이 LOGIN_REQUIRED 를 돌려준다"""
        self._login_required = bool(login_required)

    def is_login_required(self) -> bool:
        return self._login_required

    # ================================================================ 브라우저 · 폴더

    def set_auth_dir(self, auth_dir: Optional[str]) -> None:
        """사이트별 로그인 정보(쿠키 · storageState) 파일 폴더 — 키 authDir, 기본 ./auth"""
        self.set("authDir", auth_dir)

    def get_auth_dir(self) -> str:
        return self._get("authDir", "./auth")

    def set_output_dir(self, output_dir: Optional[str]) -> None:
        """결과 폴더 — 키 outputDir, 기본 ./crawl-output. 그 아래 사이트(host_port)별 폴더에 상태 · 스크린샷 · 사이트 지도 등이 쌓인다"""
        self.set("outputDir", output_dir)

    def get_output_dir(self) -> str:
        return self._get("outputDir", "./crawl-output")

    def set_browser_channel(self, channel: Optional[str]) -> None:
        """크롤링에 쓸 브라우저 — 키 browserChannel, 기본 msedge. PC 에 깔린 Chromium 계열만 된다(msedge · chrome …)"""
        self.set("browserChannel", channel)

    def get_browser_channel(self) -> str:
        return self._get("browserChannel", "msedge")

    def set_headless(self, headless: bool) -> None:
        """크롤링 때 브라우저 창을 숨길지 — 키 headless, 기본 false. 로그인 때는 이 값과 상관없이 늘 창을 띄운다"""
        self.set("headless", _bool_text(headless))

    def is_headless(self) -> bool:
        return _parse_bool(self._get("headless", "false"))

    def set_block_resources(self, block: bool) -> None:
        """이미지 · 폰트 · 미디어 요청을 끊을지 — 키 blockResources, 기본 false(사람이 볼 때처럼 다 받는다)"""
        self.set("blockResources", _bool_text(block))

    def is_block_resources(self) -> bool:
        return _parse_bool(self._get("blockResources", "false"))

    def set_ignore_https_errors(self, ignore: bool) -> None:
        """https 인증서 오류(사설 · 만료 · 이름 불일치)를 무시할지 — 키 ignoreHttpsErrors, 기본 false"""
        self.set("ignoreHttpsErrors", _bool_text(ignore))

    def is_ignore_https_errors(self) -> bool:
        return _parse_bool(self._get("ignoreHttpsErrors", "false"))

    # ================================================================ 안전장치 (명세 §4)

    def set_danger_words(self, *words: Union[str, Iterable[str]]) -> None:
        """위험 단어 — 키 dangerWords, 기본 삭제 · 저장. 글자에 이것이 들어 있는 메뉴 · 버튼 · 링크는 누르지 않는다.

        set_danger_words("삭제", "저장") 또는 set_danger_words(["삭제", "저장"]). 아무것도 안 주면 하나도 막지 않는다.
        """
        if 1 == len(words) and not isinstance(words[0], str):
            lstWords = list(words[0])
        else:
            lstWords = list(words)

        lstTrimmed = [jtrim(w) for w in lstWords if "" != jtrim(w)]
        strJoined = ",".join(lstTrimmed)

        self.set("dangerWords", _NO_DANGER_WORDS if "" == strJoined else strJoined)

    def get_danger_words(self) -> List[str]:
        """위험 단어 목록 — 기본 [삭제, 저장]. 설정 파일에 dangerWords=, 로 적으면 빈 목록"""
        strWords = self._get("dangerWords", _DEFAULT_DANGER_WORDS)

        return [jtrim(w) for w in strWords.split(",") if "" != jtrim(w)]

    def set_block_post(self, block_post: bool) -> None:
        """GET 외 요청(POST · PUT · DELETE · PATCH)을 막을지 — 키 blockPost, 기본 false. True 면 막은 요청을 blocked-requests.log 에 남긴다"""
        self.set("blockPost", _bool_text(block_post))

    def is_block_post(self) -> bool:
        return _parse_bool(self._get("blockPost", "false"))

    def set_allow_post_pattern(self, pattern: Optional[str]) -> None:
        """blockPost=true 일 때도 통과시킬 POST 의 URL 정규식 — 키 allowPostPattern, 기본 없음. URL 전체와 맞아야 한다"""
        self.set("allowPostPattern", pattern)

    def get_allow_post_pattern(self) -> str:
        return self._get("allowPostPattern", "")

    # ================================================================ 탐색 범위 (명세 §6)

    def set_menu_selector(self, selector: Optional[str]) -> None:
        """메뉴 영역 CSS selector — 키 menuSelector, 기본 없음(자동 탐지)"""
        self.set("menuSelector", selector)

    def get_menu_selector(self) -> str:
        return self._get("menuSelector", "")

    def set_max_depth(self, max_depth: int) -> None:
        """메뉴로 연 화면에서 링크를 몇 단계까지 따라갈지 — 키 maxDepth, 기본 3"""
        self.set("maxDepth", str(int(max_depth)))

    def get_max_depth(self) -> int:
        return int(self._get("maxDepth", "3"))

    def set_max_states(self, max_states: int) -> None:
        """최대 수집 상태(화면) 수 — 키 maxStates, 기본 500. 닿으면 정상 종료(MAX_STATES)"""
        self.set("maxStates", str(int(max_states)))

    def get_max_states(self) -> int:
        return int(self._get("maxStates", "500"))

    def set_full_scan(self, full_scan: bool) -> None:
        """Full 스캔 — 화면 안의 버튼 · 탭까지 실제로 누른다(테스트 사이트 전용). set_click_buttons 와 같다"""
        self.set_click_buttons(full_scan)

    def is_full_scan(self) -> bool:
        return self.is_click_buttons()

    def set_click_buttons(self, click_buttons: bool) -> None:
        """화면 안의 버튼 · 탭을 실제로 누를지 — 키 clickButtons, 기본 false. 켜면 confirm 을 수락한다"""
        self.set("clickButtons", _bool_text(click_buttons))

    def is_click_buttons(self) -> bool:
        return _parse_bool(self._get("clickButtons", "false"))

    def set_click_depth(self, click_depth: int) -> None:
        """버튼으로 연 화면에서 몇 단계까지 더 누를지 — 키 clickDepth, 기본 2"""
        self.set("clickDepth", str(int(click_depth)))

    def get_click_depth(self) -> int:
        return int(self._get("clickDepth", "2"))

    def set_merge_same_structure(self, merge: bool) -> None:
        """주소가 달라도 구조가 같으면 같은 화면의 변형으로 묶을지 — 키 mergeSameStructure, 기본 true"""
        self.set("mergeSameStructure", _bool_text(merge))

    def is_merge_same_structure(self) -> bool:
        return _parse_bool(self._get("mergeSameStructure", "true"))

    def set_hover_menus(self, hover_menus: bool) -> None:
        """마우스를 올려야 펼쳐지는 메뉴를 찾을지 — 키 hoverMenus, 기본 true"""
        self.set("hoverMenus", _bool_text(hover_menus))

    def is_hover_menus(self) -> bool:
        return _parse_bool(self._get("hoverMenus", "true"))

    # ================================================================ 기다리는 시간 · 재시도 (단위 ms)

    def set_hover_wait_ms(self, ms: int) -> None:
        """메뉴에 마우스를 올린 뒤 기다리는 시간 — 키 hoverWaitMs, 기본 500"""
        self.set("hoverWaitMs", str(int(ms)))

    def get_hover_wait_ms(self) -> int:
        return int(self._get("hoverWaitMs", "500"))

    def set_click_wait_ms(self, ms: int) -> None:
        """클릭 · 이동 뒤 기다리는 상한 — 키 clickWaitMs, 기본 5000. 각 단계 상한이고 클릭 · 요소 찾기의 상한이기도 하다"""
        self.set("clickWaitMs", str(int(ms)))

    def get_click_wait_ms(self) -> int:
        return int(self._get("clickWaitMs", "5000"))

    def set_settle_pause_ms(self, ms: int) -> None:
        """클릭 · 이동 직후 무조건 쉬는 시간 — 키 settlePauseMs, 기본 500"""
        self.set("settlePauseMs", str(int(ms)))

    def get_settle_pause_ms(self) -> int:
        return int(self._get("settlePauseMs", "500"))

    def set_stable_interval_ms(self, ms: int) -> None:
        """화면 안정 판정 간격 — 키 stableIntervalMs, 기본 700"""
        self.set("stableIntervalMs", str(int(ms)))

    def get_stable_interval_ms(self) -> int:
        return int(self._get("stableIntervalMs", "700"))

    def set_aria_timeout_ms(self, ms: int) -> None:
        """frame 마다 aria 스냅샷을 뜨는 상한 — 키 ariaTimeoutMs, 기본 3000"""
        self.set("ariaTimeoutMs", str(int(ms)))

    def get_aria_timeout_ms(self) -> int:
        return int(self._get("ariaTimeoutMs", "3000"))

    def set_navigate_timeout_ms(self, ms: int) -> None:
        """주소로 페이지를 여는 상한 — 키 navigateTimeoutMs, 기본 30000. 크롤링 때만 쓰고 로그인 창은 Playwright 기본"""
        self.set("navigateTimeoutMs", str(int(ms)))

    def get_navigate_timeout_ms(self) -> int:
        return int(self._get("navigateTimeoutMs", "30000"))

    def set_login_poll_ms(self, ms: int) -> None:
        """로그인 창에서 완료 신호 · 창 닫힘 · 중단을 확인하는 주기 — 키 loginPollMs, 기본 500"""
        self.set("loginPollMs", str(int(ms)))

    def get_login_poll_ms(self) -> int:
        return int(self._get("loginPollMs", "500"))

    def set_retry_wait_steps_ms(self, *steps: int) -> None:
        """오류가 나면 기다리는 시간마다 더해 다시 할 값들 — 키 retryWaitStepsMs, 기본 1000,5000. 아무것도 안 주면 재시도 없음"""
        if 1 == len(steps) and not isinstance(steps[0], int):
            lstSteps = [int(s) for s in steps[0]]
        else:
            lstSteps = [int(s) for s in steps]

        self.set("retryWaitStepsMs", _NO_RETRY if not lstSteps else ",".join(str(s) for s in lstSteps))

    def get_retry_wait_steps_ms(self) -> List[int]:
        """재시도 때 더할 값들 — 기본 [1000, 5000]. none 이면 빈 목록(재시도 없음)"""
        strSteps = self._get("retryWaitStepsMs", "1000,5000")

        if _NO_RETRY == strSteps.lower():
            return []

        return [int(jtrim(s)) for s in strSteps.split(",") if "" != jtrim(s)]

    # ================================================================ LLM 재료 (명세 §8.3)

    def set_smoke_gap_ms(self, ms: int) -> None:
        """smoke-prompt.md 가 LLM 에 시키는 스모크 테스트 사이 쉬는 시간 — 키 smokeGapMs, 기본 3000"""
        self.set("smokeGapMs", str(int(ms)))

    def get_smoke_gap_ms(self) -> int:
        return int(self._get("smokeGapMs", "3000"))

    # ================================================================ 문자열 키 · 설정 파일

    @staticmethod
    def set_defaults() -> "CrawlerConfig":
        """모두 기본값인 설정 — CrawlerConfig() 와 같다"""
        return CrawlerConfig()

    @staticmethod
    def of(values: Mapping[str, str]) -> "CrawlerConfig":
        """에이전트 설정 등에서 받은 값 — 키는 crawler.properties 와 같고, 값은 문자열이어야 한다"""
        config = CrawlerConfig()
        config._props.update({str(k): str(v) for k, v in values.items()})
        return config

    def set(self, key: str, value: Optional[str]) -> None:
        """값 하나를 문자열 키로 바꾼다 — 예: config.set("headless", "true"). None 이면 지워서 기본값으로 돌린다"""
        if value is None:
            self._props.pop(key, None)
        else:
            self._props[key] = str(value)

    @staticmethod
    def load(path: Optional[Union[str, os.PathLike]] = None) -> "CrawlerConfig":
        """설정 파일을 읽는다 — path 가 None · 공백이면 작업 폴더의 crawler.properties. 파일이 없으면 모두 기본값. UTF-8"""
        config = CrawlerConfig()
        strPath = DEFAULT_FILE if path is None or jblank(str(path)) else str(path)

        if not os.path.exists(strPath):
            return config

        with open(strPath, "r", encoding="utf-8") as oFile:
            config._props.update(parse_properties(oFile.read()))

        return config

    def _get(self, key: str, default: str) -> str:
        """키의 값 — 없거나 공백뿐이면 기본값, 있으면 앞뒤 공백을 뗀 값"""
        strValue = self._props.get(key)

        return default if strValue is None or jblank(strValue) else jtrim(strValue)


def parse_properties(text: str) -> dict:
    """java.util.Properties.load 규칙 — # · ! 주석, key=value · key:value · key value, 끝의 \\ 로 줄 잇기, \\uXXXX"""
    result: dict = {}
    lstLines = text.splitlines()
    i = 0

    while i < len(lstLines):
        strLine = lstLines[i].lstrip(" \t\f")
        i += 1

        if "" == strLine or strLine[0] in "#!":
            continue

        # 줄 잇기 — 끝의 \ 가 홀수 개
        while _ends_with_continuation(strLine) and i < len(lstLines):
            strLine = strLine[:-1] + lstLines[i].lstrip(" \t\f")
            i += 1

        if _ends_with_continuation(strLine):
            strLine = strLine[:-1]

        strKey, strValue = _split_key_value(strLine)
        result[_unescape(strKey)] = _unescape(strValue)

    return result


def _ends_with_continuation(strLine: str) -> bool:
    nCount = 0

    for ch in reversed(strLine):
        if "\\" != ch:
            break

        nCount += 1

    return 1 == nCount % 2


def _split_key_value(strLine: str):
    i = 0
    nLength = len(strLine)

    while i < nLength:
        ch = strLine[i]

        if "\\" == ch:
            i += 2
            continue

        if ch in "=: \t\f":
            break

        i += 1

    strKey = strLine[:i]
    j = i

    while j < nLength and strLine[j] in " \t\f":
        j += 1

    if j < nLength and strLine[j] in "=:":
        j += 1

        while j < nLength and strLine[j] in " \t\f":
            j += 1

    return strKey, strLine[j:]


def _unescape(text: str) -> str:
    out = []
    i = 0

    while i < len(text):
        ch = text[i]

        if "\\" != ch or i + 1 >= len(text):
            out.append(ch)
            i += 1
            continue

        strNext = text[i + 1]

        if "u" == strNext and i + 6 <= len(text):
            try:
                out.append(chr(int(text[i + 2:i + 6], 16)))
                i += 6
                continue
            except ValueError:
                pass

        out.append({"t": "\t", "n": "\n", "r": "\r", "f": "\f"}.get(strNext, strNext))
        i += 2

    return "".join(out)
