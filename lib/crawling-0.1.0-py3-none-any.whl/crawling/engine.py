"""다른 파이썬 프로그램(에이전트 · 서버 등)이 부르는 크롤러 입구 — Java 판 CrawlerEngine.

스레드 규칙 — Playwright(sync API) 객체는 만든 스레드에서만 쓸 수 있다. login · crawl 은 GUI 스레드가 아닌
**작업 스레드 하나**에서 부르고, 끝날 때까지 그 스레드를 붙잡는다. 다른 스레드에서는 다음만 한다.

- 로그인 완료 알림 — login 에 넘긴 login_done 을 완료시킨다(threading.Event.set() · Future.set_result(None)).
- 중단 — cancel(). 지금 누르는 메뉴 하나를 마치고 멈춘다.

한 프로세스에서 한 번에 하나만 돈다(로그 · 결과 폴더를 같이 쓴다). asyncio 이벤트 루프 안에서는 부르지 않는다
(Playwright sync API 의 제약 — asyncio 프로그램이면 스레드에서 부른다).

::

    config = CrawlerConfig("http://localhost:8080/", True)
    config.set_danger_words("삭제", "저장")
    config.set_full_scan(False)
    config.set_max_depth(3)
    config.set_headless(True)
    engine = CrawlerEngine(config)

    if not engine.has_login():
        engine.login(login_done=done_event)        # 사용자가 로그인 후 버튼 → done_event.set()

    result = engine.crawl(listener=my_listener)
"""

from __future__ import annotations

import os
import threading
from concurrent.futures import Future
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Optional, Union

from playwright.sync_api import Error as PlaywrightError

from . import input_list, site_map, smoke_input, smoke_prompt
from ._jutil import as_int, items, jblank, jget, java_lines, jmatches, jstrip, jtrim, parse_uri, write_text
from .auth_store import AuthStore
from .browser_session import BrowserSession
from .config import CrawlerConfig
from .listener import CrawlListener
from .log import CrawlLog
from .report import CrawlReport
from .repository import FileStateRepository, StateRepository
from .safety_guard import SafetyGuard, get_host
from .site_crawler import Result, SiteCrawler
from .state_collector import error_message, get_first_line


class LoginResult(Enum):
    # 쿠키를 저장했다
    SAVED = "SAVED"
    # 저장은 했지만 이 사이트 쿠키가 없다 — 로그인이 안 끝났다
    NO_COOKIES = "NO_COOKIES"
    CANCELLED = "CANCELLED"
    FAILED = "FAILED"


class Status(Enum):
    COMPLETED = "COMPLETED"
    # maxStates 에 닿아 멈췄다 — 정상 종료다
    MAX_STATES = "MAX_STATES"
    CANCELLED = "CANCELLED"
    # 크롤링 중 로그인 화면이 보였다 — 저장된 쿠키를 지웠으니 login 부터 다시
    SESSION_EXPIRED = "SESSION_EXPIRED"
    # 오류가 기다리는 시간을 늘려 다시 해도 났다 — 멈췄다. 모은 데까지는 남는다. 다시 crawl 하면 이어서 한다
    HALTED = "HALTED"
    # 로그인이 필요한데 저장된 쿠키가 없다 — login 부터
    LOGIN_REQUIRED = "LOGIN_REQUIRED"
    # 브라우저를 못 띄웠거나 시작 화면을 못 열었다 — message 를 본다
    FAILED = "FAILED"


class ErrorCD(Enum):
    """마지막 login · crawl 이 실패한 이유 — error_cd · error_message. 성공(SAVED · COMPLETED · MAX_STATES)이면 NONE"""

    # 실패하지 않았다
    NONE = "NONE"
    # URL 이 http · https 가 아니거나 호스트가 없다
    INVALID_URL = "INVALID_URL"
    # 브라우저를 못 띄웠다 — Edge(browserChannel)가 없거나 Playwright driver 를 못 띄웠다
    BROWSER_LAUNCH_FAILED = "BROWSER_LAUNCH_FAILED"
    # https 인증서 오류(net::ERR_CERT_…) — 테스트 사이트면 ignoreHttpsErrors=true
    CERT_ERROR = "CERT_ERROR"
    # 페이지를 못 열었다 — 시간 초과 · 주소를 못 찾음 · 연결 거부 등(인증서 오류 말고)
    PAGE_OPEN_FAILED = "PAGE_OPEN_FAILED"
    # 로그인 창이 닫혔거나 완료를 받았는데 이 사이트 쿠키가 없다 — 로그인이 안 끝났다(LoginResult.NO_COOKIES)
    LOGIN_NOT_FINISHED = "LOGIN_NOT_FINISHED"
    # 로그인 정보 파일을 못 썼다
    LOGIN_SAVE_FAILED = "LOGIN_SAVE_FAILED"
    # cancel() · login_done 취소
    CANCELLED = "CANCELLED"
    # 로그인이 필요한데 저장된 쿠키가 없다(Status.LOGIN_REQUIRED)
    LOGIN_REQUIRED = "LOGIN_REQUIRED"
    # 크롤링 중 세션이 끊겼다(Status.SESSION_EXPIRED)
    SESSION_EXPIRED = "SESSION_EXPIRED"
    # 오류가 재시도해도 났다(Status.HALTED) — 인증서 오류면 CERT_ERROR
    HALTED = "HALTED"
    # 그 밖의 크롤링 오류 — 결과 파일을 못 씀 등
    CRAWL_FAILED = "CRAWL_FAILED"


@dataclass(frozen=True)
class CrawlResult:
    """
    - output_dir — 결과 폴더(파일 저장소일 때 states · screenshots 도 여기에)
    - report — 종료 리포트 글(report.txt 와 같다)
    - message — 실패 이유(error_message 와 같다). 성공이면 빈 글
    - smoke_input — LLM 에 넘길 묶음(smoke-input.json) — 못 만들었으면 None
    - smoke_prompt — smoke_input 에 고정 프롬프트를 붙인 글(smoke-prompt.md) — 그대로 LLM 에 보내면 된다. 못 만들었으면 None
    - site_map — 업무와 화면을 잇는 작은 화면 목록(site-map.json) — 업무 테스트의 1차 LLM 에 넘긴다. 못 만들었으면 None
    - inputs — 입력값 리스트(inputs.json) — 화면의 입력칸을 key 하나씩. WAS 가 value 를 받아 LLM · P.S 실행에 쓴다. 못 만들었으면 None
    """

    status: Status
    output_dir: Optional[Path]
    report: str
    message: str
    smoke_input: Optional[Path]
    smoke_prompt: Optional[Path]
    site_map: Optional[Path]
    inputs: Optional[Path]


# 로그인 · 크롤링이 돌고 있나 — 프로세스 전체에서 하나만 돈다
_running = False
_running_lock = threading.Lock()


def _mark_running() -> None:
    """돌고 있다고 표시한다 — 이미 돌고 있으면 예외. 검사와 표시를 한 잠금 안에서 해 두 스레드가 같이 통과하지 못한다"""
    global _running

    with _running_lock:
        if _running:
            raise RuntimeError("이미 로그인 · 크롤링이 돌고 있습니다")

        _running = True


def _clear_running() -> None:
    global _running

    with _running_lock:
        _running = False


LoginDone = Union[threading.Event, Future, Callable[[], bool], None]


def _poll_login_done(login_done: LoginDone) -> Optional[bool]:
    """완료 신호 — True 면 완료, False 면 취소, None 이면 아직"""
    if login_done is None:
        return None

    if isinstance(login_done, threading.Event):
        return True if login_done.is_set() else None

    if isinstance(login_done, Future):
        if not login_done.done():
            return None

        if login_done.cancelled():
            return False

        # 예외로 완료(set_exception)면 취소로 본다
        return None is login_done.exception()

    return True if login_done() else None


class CrawlerEngine:
    LoginResult = LoginResult
    Status = Status
    ErrorCD = ErrorCD
    CrawlResult = CrawlResult

    def __init__(self, config: CrawlerConfig):
        self._config = config
        self._cancel_requested = False
        # 마지막 login · crawl 이 실패한 이유 — _enter() 에서 NONE 으로 돌린다
        self._error_cd = ErrorCD.NONE
        self._error_message = ""

    # ---------------------------------------------------------------- 로그인 정보 · 결과 폴더

    def has_login(self, url: Optional[str] = None, system_name: Optional[str] = None) -> bool:
        """이 사이트의 쿠키가 저장돼 있는가 — authDir/{host_port}.json, 시스템 이름을 주면 authDir/{시스템 이름}.json.
        url 을 안 주면 설정의 시작 URL"""
        strUrl = self._get_start_url() if url is None else url

        return self._get_auth_store(strUrl, system_name).has_cookies()

    def clear_login(self, url: str, system_name: Optional[str] = None) -> None:
        """저장된 쿠키를 지운다 — 크롤링 자료는 남는다(다시 login → crawl 하면 이어서 한다)"""
        self._get_auth_store(url, system_name).delete()

    def clear_results(self, url: str, system_name: Optional[str] = None, keep_inputs: bool = True) -> None:
        """이 사이트의 크롤링 자료(결과 폴더)를 지운다 — 다음 crawl 은 처리한 메뉴 없이 처음부터 한다.
        사이트가 바뀌었거나 크롤링이 잘못됐을 때 쓴다. 로그인 정보는 지우지 않는다(clear_login).

        :param keep_inputs: True 면 inputs.json(입력해 둔 값)은 남긴다 — 다음 crawl 이 같은 key 에 이어 붙인다. False 면 폴더를 통째로
        :raises ValueError: URL 이 잘못됐을 때
        :raises RuntimeError: 로그인 · 크롤링이 돌고 있을 때 — 쓰는 중인 파일을 지우지 않는다
        """
        strInvalid = _get_invalid_reason(url)

        if strInvalid is not None:
            raise ValueError(strInvalid)

        _mark_running()

        try:
            oOutputDir = self.get_output_dir(url, system_name)

            if not oOutputDir.exists():
                return

            oInputs = oOutputDir / "inputs.json"
            lstPaths = [oOutputDir]

            for strRoot, lstDirs, lstFiles in os.walk(oOutputDir):
                lstPaths.extend(Path(strRoot) / d for d in lstDirs)
                lstPaths.extend(Path(strRoot) / f for f in lstFiles)

            # 안쪽부터 지운다 — 폴더는 비운 뒤에 지울 수 있다
            for oPath in sorted(lstPaths, key=lambda p: len(p.parts), reverse=True):
                if keep_inputs and (oPath == oInputs or oPath == oOutputDir):
                    continue

                if oPath.is_dir() and not oPath.is_symlink():
                    oPath.rmdir()
                else:
                    oPath.unlink()
        finally:
            _clear_running()

    def get_output_dir(self, url: str, system_name: Optional[str] = None) -> Path:
        """이 사이트의 결과 폴더 — outputDir/{host_port}, 시스템 이름을 주면 outputDir/{시스템 이름}. 폴더를 만들지는 않는다"""
        oBaseDir = Path(self._config.get_output_dir())
        strFolder = to_folder_name(system_name)

        if strFolder is None:
            strFolder = get_host(parse_uri(url)).replace(":", "_")

        return oBaseDir / strFolder

    # ---------------------------------------------------------------- 중단 · 실패 이유

    def cancel(self) -> None:
        """지금 도는 login · crawl 을 멈춘다. 아무 스레드에서나 불러도 된다"""
        self._cancel_requested = True

    @property
    def error_cd(self) -> ErrorCD:
        """마지막 login · crawl 이 실패한 이유. 성공했거나 아직 안 불렀으면 NONE"""
        return self._error_cd

    @property
    def error_message(self) -> str:
        """마지막 login · crawl 이 실패한 이유 글(오류 첫 줄 등). NONE 이면 빈 글"""
        return self._error_message

    def get_error_cd(self) -> ErrorCD:
        return self._error_cd

    def get_error_message(self) -> str:
        return self._error_message

    # ---------------------------------------------------------------- 로그인

    def login(self, url: Optional[str] = None, login_done: LoginDone = None, system_name: Optional[str] = None) -> LoginResult:
        """브라우저를 띄워 사용자가 로그인하게 하고, login_done 이 완료되면 쿠키를 저장한다.
        사용자가 로그인 창을 닫아도 완료로 본다. cancel() 이나 login_done 취소면 저장하지 않는다.

        :param url: 로그인 화면(또는 시작 화면) 주소 — 안 주면 설정의 시작 URL
        :param login_done: threading.Event · concurrent.futures.Future · 참을 돌려주는 함수. None 이면 창을 닫을 때까지 기다린다
        :param system_name: 로그인 정보 파일 이름 — authDir/{시스템 이름}.json. None · 빈 값이면 주소(host_port)
        """
        strUrl = self._get_start_url() if url is None else url

        self._enter()

        try:
            strInvalid = _get_invalid_reason(strUrl)

            if strInvalid is not None:
                self._set_error(ErrorCD.INVALID_URL, strInvalid)
                return LoginResult.FAILED

            auth = self._get_auth_store(strUrl, system_name)
            # 어디서 실패했는가 — 브라우저 띄우기 → 쿠키 저장
            eStage = ErrorCD.BROWSER_LAUNCH_FAILED
            # 첫 화면을 못 연 이유 — 끝내 로그인이 안 되면 이것을 실패 이유로 남긴다
            eOpenError = ErrorCD.NONE
            strOpenError = ""

            try:
                with BrowserSession.open(self._config, False, None) as session:
                    eStage = ErrorCD.LOGIN_SAVE_FAILED
                    page = session.get_context().new_page()

                    # 첫 화면을 못 열어도(시간 초과 · 이동이 끊김 등) 창은 닫지 않는다 — 사람이 그 창에서 다시 열어 로그인할 수 있다.
                    # 인증서 오류만은 바로 닫는다 — 경고를 넘겨 로그인해도 크롤링이 같은 오류로 못 연다
                    try:
                        page.goto(strUrl)
                    except PlaywrightError as e:
                        strReason = get_first_line(error_message(e))
                        eOpenError = _get_open_error(error_message(e))
                        strOpenError = strReason

                        if ErrorCD.CERT_ERROR == eOpenError:
                            CrawlLog.warn("로그인 화면을 열지 못했습니다 — %s", strReason)
                            CrawlLog.warn("https 인증서 오류입니다 — 테스트 사이트면 설정 ignoreHttpsErrors=true 로 두세요(크롤링도 같은 이유로 못 연다)")
                            self._set_error(ErrorCD.CERT_ERROR, strReason)
                            return LoginResult.FAILED

                        CrawlLog.warn("로그인 화면을 열지 못했습니다 — %s. 브라우저 창에서 직접 열어 로그인하세요", strReason)

                    if not self._wait_login(page, login_done):
                        self._set_error(ErrorCD.CANCELLED, "로그인을 취소했습니다")
                        return LoginResult.CANCELLED

                    session.save_storage_state(auth.get_file())
            except (PlaywrightError, OSError) as e:
                strReason = get_first_line(error_message(e))

                if ErrorCD.BROWSER_LAUNCH_FAILED == eStage:
                    CrawlLog.warn("브라우저를 띄우지 못했습니다 — %s", strReason)
                else:
                    CrawlLog.warn("로그인 정보를 저장하지 못했습니다 — %s", strReason)

                self._set_error(eStage, strReason)
                return LoginResult.FAILED

            if auth.has_cookies():
                CrawlLog.info("로그인 정보를 저장했습니다 → %s", auth.get_file().absolute())
                return LoginResult.SAVED

            CrawlLog.warn("이 사이트 쿠키가 저장되지 않았습니다 — 로그인이 끝났는지 확인하세요")
            _delete_quietly(auth)

            # 첫 화면을 못 열었으면 그것이 진짜 이유다
            if ErrorCD.NONE == eOpenError:
                self._set_error(ErrorCD.LOGIN_NOT_FINISHED, "이 사이트 쿠키가 저장되지 않았습니다 — 로그인이 끝나지 않았습니다")
            else:
                self._set_error(eOpenError, strOpenError)

            return LoginResult.NO_COOKIES
        finally:
            _clear_running()

    def _wait_login(self, page, login_done: LoginDone) -> bool:
        """False 면 취소. 기다리는 동안 page.wait_for_timeout 으로 Playwright 소식(창 닫힘 등)을 받는다"""
        nPollMs = self._config.get_login_poll_ms()

        while True:
            bDone = _poll_login_done(login_done)

            if bDone is not None:
                return bDone

            if self._cancel_requested:
                return False

            if page.is_closed():
                return True

            try:
                page.wait_for_timeout(nPollMs)
            except PlaywrightError:
                # 기다리는 사이 창이 닫혔다 — 다음 차례에 is_closed 로 본다
                pass

    # ---------------------------------------------------------------- 크롤링

    def crawl(self, url: Optional[str] = None, login_required: Optional[bool] = None, repository: Optional[StateRepository] = None,
              listener: Optional[CrawlListener] = None, system_name: Optional[str] = None) -> CrawlResult:
        """크롤링한다.

        :param url: 시작 화면(로그인 후 첫 화면) — 안 주면 설정의 시작 URL
        :param login_required: 로그인이 필요한 사이트인가 — 안 주면 설정의 로그인 여부
        :param repository: None 이면 결과 폴더에 파일로 저장한다(FileStateRepository). 서버로 올릴 때는 그 구현을 넘긴다
        :param listener: None 이면 알리지 않는다
        :param system_name: 로그인 정보 파일 authDir/{시스템 이름}.json 으로 열고 결과를 outputDir/{시스템 이름}/ 에 둔다.
                            login 에 넘긴 것과 같은 이름을 넘긴다. None · 빈 값이면 주소(host_port)
        """
        strUrl = self._get_start_url() if url is None else url
        bLoginRequired = self._config.is_login_required() if login_required is None else bool(login_required)

        self._enter()

        # 결과 폴더 · 쿠키 경로는 URL 로 정한다 — URL 이 잘못됐으면 잠금을 풀고 FAILED 로 돌려준다
        strInvalid = _get_invalid_reason(strUrl)

        if strInvalid is not None:
            self._set_error(ErrorCD.INVALID_URL, strInvalid)
            _clear_running()
            return CrawlResult(Status.FAILED, None, "", strInvalid, None, None, None, None)

        oListener = CrawlListener.NONE if listener is None else listener  # type: ignore[attr-defined]
        onLog = oListener.on_log
        oOutputDir = self.get_output_dir(strUrl, system_name)
        auth = self._get_auth_store(strUrl, system_name)
        # 브라우저를 띄웠는가 — 못 띄운 실패(BROWSER_LAUNCH_FAILED)와 그 뒤 실패(CRAWL_FAILED)를 가른다
        bBrowserOpened = False

        CrawlLog.add_listener(onLog)

        try:
            if bLoginRequired and not auth.has_cookies():
                self._set_error(ErrorCD.LOGIN_REQUIRED, "저장된 로그인 정보가 없습니다")
                return CrawlResult(Status.LOGIN_REQUIRED, oOutputDir, "", self._error_message, None, None, None, None)

            CrawlLog.open(oOutputDir)
            CrawlLog.info("크롤링 시작 — %s (로그인 %s, 결과 %s)", strUrl, "사용" if bLoginRequired else "없음", oOutputDir.absolute())

            guard = SafetyGuard(self._config, get_host(parse_uri(strUrl)), oOutputDir)
            repo = FileStateRepository(oOutputDir) if repository is None else repository
            report = CrawlReport()

            try:
                with BrowserSession.open(self._config, self._config.is_headless(),
                                         auth.get_file() if bLoginRequired else None) as session:
                    bBrowserOpened = True
                    guard.install(session.get_context())
                    crawler = SiteCrawler(self._config, strUrl, bLoginRequired, session.get_context(), guard, repo, report, oListener,
                                          lambda: self._cancel_requested)
                    result = crawler.run()
            finally:
                guard.close()

            strReport = report.render(repo, guard.get_blocked_count())

            # LLM 에 넘길 묶음 — 멈췄어도 모은 데까지 쓴다
            oSmokeInput = oOutputDir / "smoke-input.json"
            oSmokePrompt = oOutputDir / "smoke-prompt.md"
            oInput = smoke_input.build(strUrl, repo, crawler.get_saved_states())
            smoke_input.write(oSmokeInput, oInput)

            write_text(oSmokePrompt, smoke_prompt.build(oInput, self._config.get_danger_words(), self._config.get_smoke_gap_ms()))

            CrawlLog.info("smoke-input.json — 화면 %d개 (서버 오류로 뺀 화면 %d개)", as_int(jget(oInput, "screenCount")),
                          len(items(jget(oInput, "skipped"))))

            # 업무 테스트용 — 업무 설명과 화면을 잇는 작은 목록
            oSiteMap = oOutputDir / "site-map.json"
            oMap = site_map.build(strUrl, repo, crawler.get_saved_states())
            site_map.write(oSiteMap, oMap)
            CrawlLog.info("site-map.json — 화면 %d개", as_int(jget(oMap, "screenCount")))

            # 입력값 리스트 — 화면의 입력칸을 key 하나씩. 이전 파일의 value 는 같은 key 에 이어 붙인다
            oInputs = oOutputDir / "inputs.json"
            oList = input_list.build(oMap, repo, crawler.get_saved_states(), input_list.read(oInputs))
            input_list.write(oInputs, oList)
            CrawlLog.info("inputs.json — 입력값 %d개", as_int(jget(oList, "inputCount")))

            # 리포트 끝에 테스트 단서가 약한 칸 — 개발 쪽에 data-testid 를 요청할 근거
            strReport = strReport + site_map.get_weak_report(oMap)

            write_text(oOutputDir / "report.txt", strReport)

            if Result.SESSION_EXPIRED == result:
                _delete_quietly(auth)
                CrawlLog.warn("세션이 만료되었습니다. 저장된 로그인 정보를 지웠습니다 — 다시 로그인하세요.")
                self._set_error(ErrorCD.SESSION_EXPIRED, "크롤링 중 세션이 끊겼습니다 — 저장된 로그인 정보를 지웠습니다")
            else:
                CrawlLog.info("크롤링을 마쳤습니다 (%s)", result.value)

            if Result.HALTED == result:
                strHalt = crawler.get_halt_reason()

                # 시작 화면부터 인증서 오류면 재시도로는 안 된다 — 따로 알린다
                self._set_error(ErrorCD.CERT_ERROR if "ERR_CERT" in strHalt else ErrorCD.HALTED, strHalt)
            elif Result.CANCELLED == result:
                self._set_error(ErrorCD.CANCELLED, "크롤링을 멈췄습니다")

            return CrawlResult(Status[result.value], oOutputDir, strReport, self._error_message, oSmokeInput, oSmokePrompt, oSiteMap,
                               oInputs)
        except Exception as e:
            strDescription = _get_description(e)

            CrawlLog.warn("크롤링 실패 — %s", strDescription)

            if bBrowserOpened:
                self._set_error(ErrorCD.CRAWL_FAILED, strDescription)
            elif isinstance(e, PlaywrightError):
                self._set_error(ErrorCD.BROWSER_LAUNCH_FAILED, strDescription)
            else:
                self._set_error(ErrorCD.CRAWL_FAILED, strDescription)

            return CrawlResult(Status.FAILED, oOutputDir, "", strDescription, None, None, None, None)
        finally:
            CrawlLog.close()
            CrawlLog.remove_listener(onLog)
            _clear_running()

    # ---------------------------------------------------------------- 공통

    def _get_start_url(self) -> str:
        strStartUrl = self._config.get_start_url()

        if strStartUrl is None or jblank(strStartUrl):
            raise RuntimeError("시작 URL 이 없습니다 — CrawlerConfig(url, login_required) 또는 set_start_url 로 주세요")

        return strStartUrl

    def _enter(self) -> None:
        _mark_running()
        self._cancel_requested = False
        self._error_cd = ErrorCD.NONE
        self._error_message = ""

    def _set_error(self, code: ErrorCD, message: Optional[str]) -> None:
        self._error_cd = code
        self._error_message = "" if message is None else message

    def _get_auth_store(self, url: str, system_name: Optional[str]) -> AuthStore:
        return AuthStore(Path(self._config.get_auth_dir()), parse_uri(url), to_folder_name(system_name))


def to_folder_name(name: Optional[str]) -> Optional[str]:
    """폴더 · 파일 이름으로 쓸 수 있게 고친다 — 못 쓰는 글자(\\ / : * ? " < > | · 제어 문자)는 _, 앞뒤 공백 · 끝의 점은 뗀다.
    Windows 예약 이름(CON · PRN · AUX · NUL · COM1~9 · LPT1~9)이면 뒤에 _ 를 붙인다. None 이거나 고친 뒤 비면 None"""
    if name is None:
        return None

    strFolder = "".join("_" if ch < "\x20" or ch in '\\/:*?"<>|' else ch for ch in jtrim(name))

    # Windows 는 이름 끝의 점 · 공백을 떼어 버린다 — 미리 뗀다
    strFolder = strFolder.rstrip(". ")

    if "" == strFolder:
        return None

    strBase = strFolder.upper().split(".", 1)[0]

    if jmatches(r"CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9]", strBase):
        strFolder = strFolder + "_"

    return strFolder


def _get_description(e: BaseException) -> str:
    """예외 종류와 메시지 앞 몇 줄"""
    lstParts = []

    for strLine in java_lines(error_message(e) or ""):
        if 6 <= len(lstParts):
            break

        strStripped = jstrip(strLine)

        if "" != strStripped:
            lstParts.append(strStripped)

    return type(e).__name__ + ": " + " / ".join(lstParts)


def _get_open_error(message: Optional[str]) -> ErrorCD:
    """페이지를 못 연 이유 — 인증서 오류인가 그 밖인가"""
    return ErrorCD.CERT_ERROR if "ERR_CERT" in str(message) else ErrorCD.PAGE_OPEN_FAILED


def _get_invalid_reason(url: Optional[str]) -> Optional[str]:
    """크롤링할 수 없는 URL 이면 그 이유, 괜찮으면 None — http · https 이고 호스트가 있어야 한다"""
    if url is None or jblank(url):
        return "시작 URL 이 없습니다"

    try:
        oUri = parse_uri(url)
    except ValueError:
        return "시작 URL 을 읽을 수 없습니다 — " + url

    if oUri.scheme is None or oUri.host is None:
        return "시작 URL 에 http:// 와 호스트가 있어야 합니다 — " + url

    if oUri.scheme.lower() not in ("http", "https"):
        return "시작 URL 은 http · https 여야 합니다 — " + url

    return None


def _delete_quietly(auth: AuthStore) -> None:
    try:
        auth.delete()
    except OSError:
        CrawlLog.warn("로그인 정보 파일을 지우지 못했습니다 — %s", auth.get_file())
