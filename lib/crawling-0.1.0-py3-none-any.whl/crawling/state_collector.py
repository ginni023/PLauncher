"""frame 마다 화면 구조를 뽑는다(명세 §7) — Java 판 StateCollector. 텍스트(innerText · ariaSnapshot)만으로 모으지 않는다."""

from __future__ import annotations

import re
from dataclasses import dataclass
from importlib import resources
from typing import Any, List, Optional

from playwright.sync_api import Error as PlaywrightError

from . import aria_filter
from playwright.sync_api import Frame

from ._jutil import MISSING, as_bool, as_text, get_host, is_number, items, jblank, jget, jtrim
from .log import CrawlLog
from .state_key import get_struct_hash

_DEFAULT_ARIA_TIMEOUT_MS = 3000


def _get_script(name: str) -> str:
    """패키지의 resources/js 스크립트. 맨 앞의 // 주석 줄은 떼어 낸다(evaluate 가 함수로 알아보게)"""
    oFile = resources.files("crawling").joinpath("resources", "js", name)

    if not oFile.is_file():
        raise RuntimeError("스크립트가 없습니다: js/" + name)

    strContent = oFile.read_text(encoding="utf-8")
    lstKept = []
    bDropping = True

    for strLine in strContent.splitlines():
        if bDropping:
            if jblank(strLine):
                continue

            if jtrim(strLine).startswith("//"):
                continue

            bDropping = False

        lstKept.append(strLine)

    return "\n".join(lstKept)


_COLLECT_JS = _get_script("collect-state.js")
_CANDIDATES_JS = _get_script("click-candidates.js")
_LINKS_JS = _get_script("links.js")
_BUTTONS_JS = _get_script("button-candidates.js")

_LOGIN_JS = "() => [...document.querySelectorAll('input[type=password]')].some(e => e.offsetParent !== null)"


@dataclass(frozen=True)
class Candidate:
    """클릭 후보 하나 — 어느 frame 에서 어떤 글자로 다시 찾을지.

    table_index — 표의 데이터 행(첫 행 밖)에 있으면 frame 안에서 그 표의 차례(0부터), 아니면 None.
    selector — 버튼 후보만. 메뉴 후보는 글자로 다시 찾는다(None).
    """

    frame_name: str
    frame_url: str
    text: str
    tag: str
    href: Optional[str]
    target: Optional[str]
    outer_html: str
    table_index: Optional[int]
    selector: Optional[str] = None


@dataclass(frozen=True)
class Link:
    """따라갈 링크 하나 — hidden 은 자리는 있지만 안 보이는 링크(마우스를 올려야 보이는 메뉴 레이어 안)다"""

    href: str
    text: str
    frame_name: str
    table_index: Optional[int]
    target: Optional[str]
    hidden: bool


@dataclass(frozen=True)
class Shape:
    """클릭 전후 비교용 — 구조 해시와 입력칸(input · select · textarea) 수"""

    hash: str
    field_count: int


# Playwright 오류 첫 줄 — 파이썬 판은 "Page.goto: net::ERR_…" 처럼 앞에 호출 이름이 붙는다(Java 판에는 없다)
_API_PREFIX = re.compile(r"^[A-Z][A-Za-z]*\.[A-Za-z_]+: ", re.ASCII)
# Java 판 Playwright 오류 "Error {\n  message='…'" — 같은 규칙을 그대로 둔다
_PLAYWRIGHT_MESSAGE = re.compile(r"message='([^\n]*?)'?\s*$", re.MULTILINE)


def get_first_line(message: Optional[str]) -> str:
    if message is None:
        return ""

    if message.startswith("Error {"):
        m = _PLAYWRIGHT_MESSAGE.search(message)

        if m:
            return jtrim(m.group(1))

    message = _API_PREFIX.sub("", message, count=1)
    nIndex = message.find("\n")

    return message if 0 > nIndex else message[:nIndex]


def error_message(e: BaseException) -> str:
    """예외의 메시지 — Playwright 오류는 .message, 그 밖은 str(e)"""
    strMessage = getattr(e, "message", None)

    return str(e) if not isinstance(strMessage, str) else strMessage


class StateCollector:
    def __init__(self, aria_timeout_ms: int = _DEFAULT_ARIA_TIMEOUT_MS):
        # frame 마다 aria 스냅샷을 뜨는 상한 — 설정 ariaTimeoutMs. 다시 할 때 늘린다
        self._aria_timeout_ms = aria_timeout_ms

    def set_aria_timeout_ms(self, aria_timeout_ms: int) -> None:
        self._aria_timeout_ms = aria_timeout_ms

    def collect_frames(self, page, with_aria: bool) -> list:
        """페이지의 모든 frame 구조. 항목마다 frameName · frameUrl 이 붙는다"""
        return [self.collect_frame(f, with_aria) for f in page.frames]

    def collect_frame(self, frame, with_aria: bool) -> dict:
        try:
            node = frame.evaluate(_COLLECT_JS)

            if not isinstance(node, dict):
                raise TypeError("collect-state.js 가 객체를 돌려주지 않았습니다")
        except (PlaywrightError, TypeError) as e:
            node = {"error": get_first_line(error_message(e)), "elements": []}

        node["frameName"] = frame.name
        node["frameUrl"] = frame.url
        node["isMainFrame"] = frame.parent_frame is None

        if with_aria:
            try:
                # 입력칸 값 · 표 데이터 행은 저장 전에 걸러낸다 — 원본은 남기지 않는다
                strAria = frame.locator("body").aria_snapshot(timeout=self._aria_timeout_ms)
                node["ariaSnapshot"] = aria_filter.filter(strAria)
            except PlaywrightError:
                node["ariaSnapshot"] = None

        return node

    def get_shape(self, frame) -> Shape:
        elements = jget(self.collect_frame(frame, False), "elements")
        nFields = 0

        for el in items(elements):
            if as_text(jget(el, "tag")) in ("INPUT", "SELECT", "TEXTAREA"):
                nFields += 1

        return Shape(get_struct_hash(elements), nFields)

    def is_login_screen(self, page) -> bool:
        """화면에 로그인 입력칸(비밀번호)이 보이는가 — 세션 만료 판정용"""
        for frame in page.frames:
            try:
                if True is frame.evaluate(_LOGIN_JS):
                    return True
            except PlaywrightError:
                # 떨어져 나간 frame — 무시
                pass

        return False

    def get_click_candidates(self, page_or_frame, menu_selector: str) -> List[Candidate]:
        """클릭 후보 목록(명세 §6.1). page 를 주면 모든 frame, frame 을 주면 그 frame 만.

        :param menu_selector: 비우면 frame 전체에서 찾는다
        """
        if isinstance(page_or_frame, Frame):
            return self._get_frame_click_candidates(page_or_frame, menu_selector)

        candidates: List[Candidate] = []

        for frame in page_or_frame.frames:
            candidates.extend(self._get_frame_click_candidates(frame, menu_selector))

        return candidates

    def _get_frame_click_candidates(self, frame, menu_selector: str) -> List[Candidate]:
        candidates: List[Candidate] = []

        try:
            for item in items(frame.evaluate(_CANDIDATES_JS, menu_selector)):
                candidates.append(Candidate(frame.name, frame.url, as_text(jget(item, "text")), as_text(jget(item, "tag")),
                                            _get_text_or_none(item, "href"), _get_text_or_none(item, "target"),
                                            as_text(jget(item, "outerHTML")), _get_int_or_none(item, "tableIndex")))
        except PlaywrightError as e:
            CrawlLog.warn("클릭 후보를 못 모았습니다 — frame %s (%s)", frame.url, get_first_line(error_message(e)))

        return candidates

    def get_button_candidates(self, page) -> List[Candidate]:
        """화면 안의 버튼 · 탭 후보(명세 §6.4) — 머리 · 메뉴 · 바닥과 주소 있는 링크는 뺀다. 누를 때 쓸 selector 가 붙는다"""
        candidates: List[Candidate] = []

        for frame in page.frames:
            try:
                for item in items(frame.evaluate(_BUTTONS_JS)):
                    candidates.append(Candidate(frame.name, frame.url, as_text(jget(item, "text")), as_text(jget(item, "tag")),
                                                None, None, as_text(jget(item, "outerHTML")), None,
                                                _get_text_or_none(item, "selector")))
            except PlaywrightError:
                # 떨어져 나간 frame — 무시
                pass

        return candidates

    def get_links(self, page) -> List[Link]:
        links: List[Link] = []

        for frame in page.frames:
            try:
                for item in items(frame.evaluate(_LINKS_JS)):
                    links.append(Link(as_text(jget(item, "href")), as_text(jget(item, "text")), frame.name,
                                      _get_int_or_none(item, "tableIndex"), _get_text_or_none(item, "target"),
                                      as_bool(jget(item, "hidden"), False)))
            except PlaywrightError:
                # 떨어져 나간 frame — 무시
                pass

        return links

    def screenshot(self, page, path) -> None:
        try:
            page.screenshot(path=str(path), full_page=True)
        except PlaywrightError as e:
            CrawlLog.warn("스크린샷 실패 — %s (%s)", _file_name(path), get_first_line(error_message(e)))


def _file_name(path) -> str:
    return str(path).replace("\\", "/").rsplit("/", 1)[-1]


def _get_int_or_none(item: Any, field: str) -> Optional[int]:
    value = jget(item, field)

    return int(value) if is_number(value) else None


def _get_text_or_none(item: Any, field: str) -> Optional[str]:
    value = jget(item, field)

    return None if value is None or value is MISSING else as_text(value)


__all__ = ["StateCollector", "Candidate", "Link", "Shape", "get_first_line", "error_message", "get_host"]
