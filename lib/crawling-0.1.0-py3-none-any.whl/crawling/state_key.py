"""상태 키 = 정규화 URL + 구조 해시(명세 §8.1) — Java 판 StateKey.

- 정규화 URL — 쿼리 값은 버리고 이름만 정렬해 남긴다. view.do?id=123&t=9 → view.do?id=*&t=*.
  ;jsessionid 와 #fragment 도 버린다.
- 구조 해시 — elements 의 tag#id[name:type] 를 이어 붙인 SHA-256. 텍스트 · label · value 는 넣지 않는다.
  표 데이터 행(tbody 두 번째 행부터)은 수집 단계에서 이미 빠져 있다. 반복 목록(카드 · 줄)의 둘째 항목부터(rep)는 넣지 않는다.
"""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass
from typing import Any

from ._jutil import as_bool, as_text, get_host, items, jget, jsplit, jtrim, parse_uri


@dataclass(frozen=True)
class StateKey:
    normalized_url: str
    struct_hash: str

    @staticmethod
    def of(raw_url: str, elements: Any) -> "StateKey":
        return StateKey(normalize_url(raw_url), get_struct_hash(elements))


def normalize_url(raw_url: str) -> str:
    try:
        uri = parse_uri(raw_url)
    except ValueError:
        return raw_url

    if uri.scheme is None or uri.host is None:
        return raw_url

    strPath = uri.raw_path

    if strPath is None or "" == strPath:
        strPath = "/"

    strPath = re.sub(r"(?i);jsessionid=[^/?#]*", "", strPath, count=1)
    strRawQuery = uri.raw_query

    if strRawQuery is None:
        strQuery = ""
    else:
        setNames = set()

        for strParam in strRawQuery.split("&"):
            if "" == strParam:
                continue

            setNames.add(strParam.split("=", 1)[0] + "=*")

        strQuery = "&".join(sorted(setNames))

    return uri.scheme.lower() + "://" + get_host(uri) + strPath + ("" if "" == strQuery else "?" + strQuery)


def get_merge_hash(elements: Any) -> str:
    """주소가 다른 화면을 같은 틀로 묶을 때(mergeSameStructure) 쓰는 더 촘촘한 해시 — 구조 해시에 class 를 더한다(숫자는 지운다)"""
    parts = []

    for el in items(elements):
        if as_bool(jget(el, "rep"), False):
            continue

        parts.append(as_text(jget(el, "tag")))
        parts.append("#")
        parts.append(as_text(jget(el, "id"), ""))
        parts.append("[")
        parts.append(as_text(jget(el, "name"), ""))
        parts.append(":")
        parts.append(as_text(jget(el, "type"), ""))
        parts.append("]")
        parts.append(".")

        strCls = as_text(jget(el, "cls"), "")
        strCls = re.sub(r"\d+", "", strCls, flags=re.ASCII)
        strCls = jtrim(strCls)
        lstCls = sorted(c for c in jsplit(r"\s+", strCls) if "" != c)
        parts.append(".".join(lstCls))
        parts.append("|")

    return _sha256("".join(parts))


def get_struct_hash(elements: Any) -> str:
    parts = []

    for el in items(elements):
        # 반복 목록(카드 · 줄)의 둘째 항목부터 — 항목 수가 달라도 같은 화면이다
        if as_bool(jget(el, "rep"), False):
            continue

        parts.append(as_text(jget(el, "tag")))
        parts.append("#")
        parts.append(as_text(jget(el, "id"), ""))
        parts.append("[")
        parts.append(as_text(jget(el, "name"), ""))
        parts.append(":")
        parts.append(as_text(jget(el, "type"), ""))
        parts.append("]")
        parts.append("|")

    return _sha256("".join(parts))


def _sha256(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()
