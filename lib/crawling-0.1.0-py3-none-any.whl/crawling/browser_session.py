"""Playwright · 브라우저 · 컨텍스트 하나를 묶는다(명세 §1.1 · §9) — Java 판 BrowserSession.

Playwright 전용 Chromium 을 내려받지 않고 PC 에 깔린 Edge(또는 Chrome)를 쓴다.
이미 깔려 있는 다른 버전의 Chromium 을 지우지 않도록 GC 도 끈다.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

from playwright.sync_api import sync_playwright

from .config import CrawlerConfig


class BrowserSession:
    def __init__(self, manager, playwright, browser, context):
        self._manager = manager
        self._playwright = playwright
        self._browser = browser
        self._context = context

    @staticmethod
    def open(config: CrawlerConfig, headless: bool, storage_state: Optional[os.PathLike] = None) -> "BrowserSession":
        """
        :param storage_state: 로그인 정보 파일. None 이면 빈 컨텍스트로 연다.
        """
        # Playwright driver 는 이 프로세스의 환경 변수를 물려받는다
        os.environ["PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD"] = "1"
        os.environ["PLAYWRIGHT_SKIP_BROWSER_GC"] = "1"

        manager = sync_playwright()
        playwright = manager.start()

        try:
            browser = playwright.chromium.launch(channel=config.get_browser_channel(), headless=headless)
            options = {
                "accept_downloads": True,
                "viewport": {"width": 1600, "height": 900},
                "ignore_https_errors": config.is_ignore_https_errors(),
            }

            if storage_state is not None and Path(storage_state).exists():
                options["storage_state"] = str(storage_state)

            return BrowserSession(manager, playwright, browser, browser.new_context(**options))
        except BaseException:
            playwright.stop()
            raise

    def get_context(self):
        return self._context

    def save_storage_state(self, path) -> None:
        """쿠키 · localStorage 를 파일로 남긴다"""
        oAbsolute = Path(path).absolute()
        oAbsolute.parent.mkdir(parents=True, exist_ok=True)

        self._context.storage_state(path=str(path))

    def close(self) -> None:
        try:
            try:
                self._context.close()
            finally:
                self._browser.close()
        finally:
            self._playwright.stop()

    def __enter__(self) -> "BrowserSession":
        return self

    def __exit__(self, *exc) -> None:
        self.close()
